"""단일 DTC 코드만 보고 가장 흔한 고장 부품을 고르는 1차 Baseline 매핑 알고리즘을 구현해 정확도와 한계를 확인하고, 탐색적 분석(EDA 차트 8종, 고장 건수와 피처의 상관계수·p-value, 파레토 ABC 분류)으로 1000가동시간당 고장률이 높은 다빈도 고장품목을 식별한다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import pearsonr

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

fleet, ev, log = make_data()
ev["first"] = ev["codes"].str[0]
train, test = ev[ev["month"] < 12], ev[ev["month"] >= 12]

# 1) Baseline: 첫 번째로 기록된 코드 -> 학습 기간에 그 코드와 가장 자주 함께 나온 부품
mp = train.groupby("first")["part"].agg(lambda s: s.value_counts().index[0])
pred = test["first"].map(mp)
acc = (pred == test["part"]).mean()
sys_acc = (pred.map(PSYS) == test["part"].map(PSYS)).mean()
print(f"[교육용가상자료] 정비 건 {len(ev)}건, DTC 로그 {len(log)}행, 차량 {len(fleet)}대, 18개월")
print(f"Baseline 부품 정확도 {acc:.1%}, 고장 계통 정확도 {sys_acc:.1%} (검증 {len(test)}건)")
amb = test["first"].isin(list(SHARED.values()) + list(SYMP.values()))
print(f"  모호한 코드(공유·증상) 첫 기록 건 정확도 {(pred[amb] == test['part'][amb]).mean():.1%} vs 고유 코드 {(pred[~amb] == test['part'][~amb]).mean():.1%}")

# 2) 부품별 고장률(1000가동시간당)과 파레토(ABC)
tot_h = fleet["hours"].sum()
cnt = ev["part"].value_counts().reindex(PID)
rate = (cnt / tot_h * 1000).round(3)
par = pd.DataFrame({"부품": [PNAME[p] for p in PID], "건수": cnt.values, "고장률": rate.values}, index=PID).sort_values("건수", ascending=False)
par["누적비율"] = par["건수"].cumsum() / par["건수"].sum()
par["등급"] = np.where(par["누적비율"] <= 0.80, "A", np.where(par["누적비율"] <= 0.95, "B", "C"))
par.loc[par.index[0], "등급"] = "A"
print(f"\n[파레토] 총 가동 {tot_h:,.0f}시간, 전체 고장률 {cnt.sum() / tot_h * 1000:.1f}건/1000h")
print(par.head(7).assign(누적비율=lambda d: d["누적비율"].map("{:.0%}".format)).to_string())
top20 = par.head(int(np.ceil(len(par) * 0.2)))
print(f"상위 20% 품목({len(top20)}종: {', '.join(top20['부품'])})이 전체 고장의 {top20['건수'].sum() / cnt.sum():.0%}, A등급 {int((par['등급'] == 'A').sum())}종")

# 3) 상관분석: 차량별 정비 건수와 피처
vc = ev.groupby("veh").size().reindex(fleet["veh"]).fillna(0).values
rows = []
for col, lab in [("age", "차령"), ("pm_gap", "예방정비 경과시간"), ("terrain", "지형 가혹도"), ("load", "운용 부하"), ("hours", "총 가동시간"), ("humid", "습도 지수")]:
    r, p = pearsonr(fleet[col], vc); rows.append((lab, r, p))
mc = ev.groupby(["month", "part"]).size().unstack(fill_value=0)
tm = ev.groupby("month")["temp"].mean()
r, p = pearsonr(tm, mc["P03"]); rows.append(("월평균 기온-축전지 고장", r, p))
cor = pd.DataFrame(rows, columns=["피처", "r", "p"])
cor["유의"] = cor["p"] < 0.05
print("\n[상관분석] 피처 | r | p-value | 유의(p<0.05)")
for x in cor.itertuples():
    print(f" {x.피처:14s} {x.r:+.2f}  {x.p:.4f}  {'유의' if x.유의 else '-'}")
nsig = int(cor["유의"].sum())

# 4) EDA 차트 8종
fig, ax = plt.subplots(2, 4, figsize=(16, 7))
ax[0, 0].bar(par.index, par["고장률"]); ax[0, 0].set_title("1 Failure rate per 1000h")
ax[0, 1].plot(range(len(par)), par["누적비율"], marker="o"); ax[0, 1].axhline(0.8, ls="--", color="k"); ax[0, 1].set_title("2 Pareto cumulative share")
mc.sum(axis=1).plot(ax=ax[0, 2]); ax[0, 2].set_title("3 Monthly failures")
ev["codes"].str.len().value_counts().sort_index().plot.bar(ax=ax[0, 3]); ax[0, 3].set_title("4 DTCs per maintenance case")
log["code"].value_counts().head(10).plot.bar(ax=ax[1, 0]); ax[1, 0].set_title("5 Top DTC codes")
ev["part"].map(PSYS).value_counts().plot.bar(ax=ax[1, 1]); ax[1, 1].set_title("6 Failures by system")
ax[1, 2].scatter(fleet["age"], vc, s=8); ax[1, 2].set_title("7 Vehicle age vs failures")
ax[1, 3].scatter(fleet["pm_gap"], vc, s=8); ax[1, 3].set_title("8 PM gap vs failures")
plt.tight_layout(); plt.show()

print(f"\nEDA 차트 8종 생성(목표 8종 이상: 달성), 유의한 피처 {nsig}개 (목표 5개 이상: {'달성' if nsig >= 5 else '미달'})")
print("핵심 발견: 1) 소수 부품에 고장 집중 2) 공유·증상 코드가 첫 기록이면 Baseline이 자주 틀림 3) 고령·가혹 지형·예방정비 지연 차량의 고장 증가")
