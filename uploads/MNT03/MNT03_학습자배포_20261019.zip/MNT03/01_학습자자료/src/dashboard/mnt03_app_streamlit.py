"""MNT03 선택 M8 로컬 UI. 원문 시뮬레이터는 별도 보존한다."""
from pathlib import Path
import contextlib,io,runpy,time
import pandas as pd
import streamlit as st
ROOT=Path(__file__).resolve().parents[2]
st.title('MNT03 M8 고장 진단 대시보드')
st.caption('[교육용가상자료] 수정 시뮬레이터의 실제 출력입니다. 현장 진단·자동 승인을 수행하지 않습니다.')
if st.button('가상 요청 시험 실행'):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    stream=io.StringIO();start=time.perf_counter()
    with contextlib.redirect_stdout(stream):
        data=runpy.run_path(str(ROOT/'src/m08_corrected.py'))
    plt.close('all')
    st.session_state['result']={'rows':pd.DataFrame(data['out']), 'log':stream.getvalue(),'elapsed':time.perf_counter()-start}
if 'result' in st.session_state:
    result=st.session_state['result'];frame=result['rows']
    choice=st.selectbox('경보 필터',['전체','경보만'])
    shown=frame if choice=='전체' else frame[frame['alert']]
    st.metric('정상 처리 요청',len(frame));st.metric('경보 요청',int(frame['alert'].sum()))
    st.dataframe(shown);st.bar_chart(shown['part'].value_counts())
    st.caption(f"전체 시뮬레이터 실행 {result['elapsed']:.2f}초. 코드의 처리·집계 2초 대리 목표는 브라우저 렌더링·전송 시간을 포함하지 않습니다.")
    st.download_button('표 CSV 저장',shown.to_csv(index=False).encode('utf-8-sig'),'mnt03_dashboard.csv')
    st.download_button('실행 로그 저장',result['log'],'mnt03_dashboard.txt')
    st.text_area('실행 로그',result['log'])
else:
    st.info('버튼을 누르면 고정 seed 가상 요청을 처리합니다. 설치 제한 환경에서는 노트북 M8 시뮬레이터 로그·그래프·해석을 대체 증거로 제출할 수 있습니다.')
