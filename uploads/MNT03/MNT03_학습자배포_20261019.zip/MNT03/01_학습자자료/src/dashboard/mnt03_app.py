"""1,000건의 DTC 진단 요청을 동시에 주입해 연관 고장 추론(부품 진단 + 기동·제동 계통 경보)의 처리 시간과 경보 정확도를 측정하는 부하 테스트를 수행한다. 형식이 깨진 코드·빈 요청·미등록 차량을 섞은 오류 주입 요청이 격리 처리되는지, 요청 수를 100~5,000건으로 늘렸을 때 시간이 어떻게 변하는지 확인한다."""
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from concurrent.futures import ThreadPoolExecutor
from sklearn.linear_model import LogisticRegression

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# ---------------------------------------------------------------------------
# 공통 분석 조각: 코드 멀티핫 행렬, 차량 맥락 피처, 학습/검증 분할(앞 12개월 학습, 뒤 6개월 검증)
# ---------------------------------------------------------------------------
CIDX = {c: i for i, c in enumerate(CODES)}
SPLIT_M = 12


def multi_hot(ev):
    X = np.zeros((len(ev), len(CODES)))
    for r, cs in enumerate(ev["codes"]):
        for c in cs:
            X[r, CIDX[c]] = 1
    return X


def context(ev, fleet):
    f = fleet.set_index("veh")
    return np.column_stack([ev["veh"].map(f["age"]) / 25, ev["veh"].map(f["pm_gap"]) / 200, ev["veh"].map(f["terrain"]),
                            ev["veh"].map(f["load"]), (ev["temp"] - 12) / 15])


def feats(ev, fleet):
    X = multi_hot(ev)
    n = X.sum(axis=1, keepdims=True) / 3
    return np.hstack([X, n, context(ev, fleet)])


def monthly_counts(ev):
    return ev.groupby(["month", "part"]).size().unstack(fill_value=0).reindex(columns=PID, fill_value=0)


def build_monthly(ev, fleet, top_n=8):
    """부품별 월간 고장 건수 예측용 표: 지연값(lag), 이동평균, 추세, 기대 건수(가동시간 x 설계 고장률), 기온 상호작용, 계절 성분"""
    mc = ev.groupby(["month", "part"]).size().unstack(fill_value=0)
    top = ev["part"].value_counts().index[:top_n]
    mh, tm = fleet.attrs["month_h"], ev.groupby("month")["temp"].mean().values
    rows = []
    for p in top:
        c = mc[p].values.astype(float)
        for m in range(3, MONTHS):
            L = np.log1p(c)
            rows.append({"part": p, "month": m, "y": c[m], "lag1": L[m - 1], "lag2": L[m - 2], "lag3": L[m - 3], "roll3": L[m - 3:m].mean(),
                         "trend": L[m - 1] - L[m - 2], "roll3_std": L[m - 3:m].std(), "log_expected": np.log(mh[m] / 1000 * RATE[p]),
                         "rate_lag1": c[m - 1] / (mh[m - 1] / 1000) / RATE[p], "temp": tm[m] / 10, "cold_elec": max(0, 12 - tm[m]) / 10 * (p in ("P03", "P04")),
                         "heat_cool": max(0, tm[m] - 12) / 10 * (p in ("P06", "P16")), "sin": np.sin(2 * np.pi * m / 12), "cos": np.cos(2 * np.pi * m / 12)})
    D = pd.DataFrame(rows)
    return D, [c for c in D.columns if c not in ("part", "month", "y")], top

fleet, ev, log = make_data()
train, test = ev[ev["month"] < SPLIT_M], ev[ev["month"] >= SPLIT_M].reset_index(drop=True)
clf = LogisticRegression(C=3, max_iter=500).fit(feats(train, fleet), train["part"])
cls, FL = clf.classes_, fleet.set_index("veh")
VALID = set(CODES)


def make_requests(n, seed=0, bad_rate=0.05):
    """[교육용가상자료] 검증 기간 정비 건에서 n건을 뽑아 DTC 요청으로 만든다. bad_rate 비율만큼 오류를 주입한다."""
    rng = np.random.default_rng(seed)
    rows = test.iloc[rng.choice(len(test), n, replace=n > len(test))]
    reqs, kinds = [], []
    for e in rows.itertuples():
        r, kind = {"veh": e.veh, "codes": list(e.codes), "temp": e.temp, "true": e.part}, "정상"
        u = rng.random()
        if u < bad_rate * 0.3: r["codes"] = [c.lower() + " " for c in r["codes"]]; kind = "표기 오류"
        elif u < bad_rate * 0.5: r["codes"] = ["ZZ9"]; kind = "미정의 코드"
        elif u < bad_rate * 0.7: r["codes"] = []; kind = "빈 요청"
        elif u < bad_rate * 0.85: r["veh"] = "V999"; kind = "미등록 차량"
        elif u < bad_rate: r["codes"] = r["codes"] * 3; kind = "중복 코드"
        reqs.append(r); kinds.append(kind)
    return reqs, kinds


def normalize(r):
    """표기 정리(공백·대소문자) 후 검증. 문제가 있으면 예외 대신 사유를 돌려준다."""
    codes = sorted({c.strip().upper() for c in r["codes"]})
    if r["veh"] not in FL.index: return None, "미등록 차량"
    if not codes or any(c not in VALID for c in codes): return None, "빈 요청·미정의 코드"
    return codes, ""


def build_x(batch):
    X = np.zeros((len(batch), len(CODES) + 6))
    for i, (r, cs) in enumerate(batch):
        for c in cs: X[i, CIDX[c]] = 1
        v = FL.loc[r["veh"]]
        X[i, len(CODES):] = [len(cs) / 3, v["age"] / 25, v["pm_gap"] / 200, v["terrain"], v["load"], (r["temp"] - 12) / 15]
    return X


def serve_batch(reqs):
    ok, rej = [], []
    for k, r in enumerate(reqs):
        cs, why = normalize(r)
        (ok if cs else rej).append((k, r, cs) if cs else (k, why))
    X = build_x([(r, cs) for _, r, cs in ok])
    P = clf.predict_proba(X) if len(ok) else np.zeros((0, len(cls)))
    top = cls[P.argmax(axis=1)] if len(ok) else []
    out = [{"k": k, "part": p, "conf": float(P[i].max()), "alert": PSYS[p] in CRIT_SYS} for i, ((k, _, _), p) in enumerate(zip(ok, top))]
    return out, rej


def serve_one(r):
    cs, why = normalize(r)
    if not cs: return None
    p = cls[clf.predict_proba(build_x([(r, cs)]))[0].argmax()]
    return {"part": p, "alert": PSYS[p] in CRIT_SYS}


# 1) 1,000건 동시 주입
reqs, kinds = make_requests(1000)
t0 = time.perf_counter(); out, rej = serve_batch(reqs)
agg = pd.DataFrame(out).groupby("part").size().sort_values(ascending=False).head(5)          # 대시보드 집계까지 포함
alerts = sum(o["alert"] for o in out); dt = time.perf_counter() - t0
print(f"[교육용가상자료] 1,000건 동시 주입: 정상 처리 {len(out)}건, 격리(오류) {len(rej)}건, 처리 시간 {dt:.2f}초 (목표 2초 이내: {'달성' if dt <= 2 else '미달'})")
print(f"  오류 주입 {sum(k != '정상' for k in kinds)}건 유형: " + ", ".join(f"{k} {v}" for k, v in pd.Series(kinds).value_counts().items() if k != "정상"))
print("  격리 사유: " + ", ".join(f"{k} {v}건" for k, v in pd.Series([w for _, w in rej]).value_counts().items()))

# 2) 경보 정확도(기동·제동 계통 고장 경보)
truth = np.array([PSYS[reqs[o["k"]]["true"]] in CRIT_SYS for o in out]); pa = np.array([o["alert"] for o in out])
acc = (truth == pa).mean(); rec = (pa & truth).sum() / truth.sum(); prec = (pa & truth).sum() / pa.sum()
part_acc = np.mean([o["part"] == reqs[o["k"]]["true"] for o in out])
print(f"\n경보 정확도 {acc:.1%} (목표 95% 이상: {'달성' if acc >= 0.95 else '미달'}), 재현율 {rec:.1%}, 정밀도 {prec:.1%}, 경보 {alerts}건")
print(f"참고: 부품 단위 진단 정확도 {part_acc:.1%}, 상위 부품 " + ", ".join(f"{PNAME[p]} {n}" for p, n in agg.items()))

# 3) 단건 호출 방식과 비교(8개 작업자 동시 호출)
t0 = time.perf_counter()
with ThreadPoolExecutor(8) as ex:
    res = list(ex.map(serve_one, reqs))
dt1 = time.perf_counter() - t0
print(f"\n단건 호출 8스레드 {dt1:.2f}초 vs 일괄 처리 {dt:.2f}초 (일괄이 {dt1 / dt:.1f}배 빠름), 단건 방식 예외 0건: {all(r is None or 'part' in r for r in res)}")

# 4) 요청 수 확장 시험
print("[요청 수별 일괄 처리 시간]")
ns, ts = [100, 500, 1000, 2000, 5000], []
for n in ns:
    rq, _ = make_requests(n, seed=n)
    t0 = time.perf_counter(); serve_batch(rq); ts.append(time.perf_counter() - t0)
    print(f"  {n:5d}건: {ts[-1]:.2f}초 ({n / ts[-1]:.0f}건/초)")

plt.figure(figsize=(6, 3.5)); plt.plot(ns, ts, marker="o"); plt.axhline(2, ls="--", color="k")
plt.xlabel("requests"); plt.ylabel("seconds"); plt.title("Batch inference time (line = 2 s)"); plt.tight_layout(); plt.show()
