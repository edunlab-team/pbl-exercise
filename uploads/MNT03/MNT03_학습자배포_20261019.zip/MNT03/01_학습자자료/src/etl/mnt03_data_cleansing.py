"""표기 불일치·중복·단위 혼재·결측·미등록 코드가 섞인 가상 DTC 발생 로그에 정제 규칙 10종을 적용하고, 같은 시간대에 함께 발생한 DTC를 정비 건 단위로 묶어 정규화(중복 제거·정렬)한 마스터 데이터를 만든다. 긴급·비계획 정비는 보존하며 정합성 검증 통과율과 정제 전후 통계를 확인한다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.impute import KNNImputer

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# 1) [교육용가상자료] 원천 로그: 생성 로그에 일부러 오류를 섞는다
fleet, ev, log = make_data()
rng = np.random.default_rng(2)
clean_n = len(log)
start = pd.Timestamp("2025-01-01")
raw = pd.DataFrame({"veh": log["veh"].values, "ts": [(start + pd.Timedelta(hours=t)).strftime("%Y-%m-%d %H:%M") for t in log["ts"]],
                    "code": log["code"].values, "emergency": False})
vn = raw["veh"].str[1:].astype(int).values
raw["op_h"] = (vn * 37 % 900) + log["ts"].values * 0.15           # 차량별 누적 가동시간 계기값(가상)
raw["op_unit"] = "h"
raw["op_h"] = raw["op_h"].round(1)
idx = rng.choice(len(raw), 2600, replace=False)
a, b, c, d_, e, f, g, h_, k = np.split(idx, [400, 900, 1500, 1800, 1880, 1960, 2040, 2300])
raw.loc[a, "veh"] = rng.choice(["v", " V"], len(a)) + raw.loc[a, "veh"].str[1:]                       # 차량 ID 표기 불일치
raw.loc[b, "code"] = [x.lower() if i % 2 else x[0] + "-" + x[1:] + " " for i, x in enumerate(raw.loc[b, "code"])]   # 코드 표기 불일치
raw.loc[c, "ts"] = pd.to_datetime(raw.loc[c, "ts"]).dt.strftime("%Y/%m/%d %H:%M:%S")                   # 시각 형식 혼재
raw.loc[d_, "op_h"] = (raw.loc[d_, "op_h"] * 60).round(0); raw.loc[d_, "op_unit"] = "min"             # 단위 혼재
raw.loc[e, "op_h"] = -1.0                                                                             # 불가능 값
raw.loc[f, "veh"] = "V999"                                                                            # 미등록 차량
raw.loc[g, "code"] = "ZZ9"                                                                            # 미정의 코드
raw.loc[h_, "op_h"] = np.nan                                                                          # 결측
burst = raw.iloc[k[:40]].copy()                                                                       # 긴급·비계획 정비: DTC 6개 폭주
bursts = []
for _, r in burst.iterrows():
    for j, cd in enumerate(rng.choice(CODES, 6, replace=False)):
        bursts.append({**r, "code": cd, "emergency": True,
                       "ts": (pd.to_datetime(r["ts"]) + pd.Timedelta(minutes=j)).strftime("%Y-%m-%d %H:%M")})
raw = pd.concat([raw, pd.DataFrame(bursts), raw.sample(150, random_state=1)], ignore_index=True)    # 폭주 건 + 중복 150건
raw = raw.sample(frac=1, random_state=3).reset_index(drop=True)
print(f"원천 로그 {len(raw)}행 (정상 {clean_n}행 + 긴급 폭주 {len(bursts)}행 + 중복 150행, 오류 주입 {len(idx)}행)")

# 2) 정제 규칙 10종
df, applied = raw.copy(), []
def rule(name, n):
    applied.append((name, int(n)))

rule("R1 중복 행 제거", df.duplicated().sum()); df = df.drop_duplicates().reset_index(drop=True)
v = df["veh"].str.strip().str.upper(); rule("R2 차량 ID 표기 통일", (v != df["veh"]).sum()); df["veh"] = v
cd = df["code"].str.strip().str.upper().str.replace("-", "", regex=False); rule("R3 DTC 코드 표기 통일", (cd != df["code"]).sum()); df["code"] = cd
t1 = pd.to_datetime(df["ts"], format="%Y-%m-%d %H:%M", errors="coerce")
t2 = pd.to_datetime(df["ts"], format="%Y/%m/%d %H:%M:%S", errors="coerce"); rule("R4 발생 시각 형식 통일", t1.isna().sum()); df["ts"] = t1.fillna(t2)
mn = df["op_unit"] == "min"; df.loc[mn, "op_h"] = df.loc[mn, "op_h"] / 60; df["op_unit"] = "h"; rule("R5 가동시간 단위 통일(분 -> 시간)", mn.sum())
bad = df["op_h"] < 0; df.loc[bad, "op_h"] = np.nan; rule("R6 음수 가동시간 결측 처리", bad.sum())
unk = ~df["veh"].isin(fleet["veh"]) | ~df["code"].isin(CODES); quarantine = df[unk].copy(); df = df[~unk].reset_index(drop=True)
rule("R7 미등록 차량·미정의 코드 격리(삭제 아님)", unk.sum())
df["hrs"] = (df["ts"] - start).dt.total_seconds() / 3600; df["vn"] = df["veh"].str[1:].astype(int)
miss = df["op_h"].isna().sum()
df["op_h"] = KNNImputer(n_neighbors=5).fit_transform(df[["hrs", "vn", "op_h"]].assign(vn=df["vn"] / 10))[:, 2]; rule("R8 가동시간 결측 KNN 보정", miss)
df = df.sort_values(["veh", "ts"]).reset_index(drop=True)
df["case"] = (df["veh"] != df["veh"].shift()) | (df["ts"].diff() > pd.Timedelta(hours=1)); df["case_id"] = df["case"].cumsum()
before = len(df); df = df.drop_duplicates(["case_id", "code"]).reset_index(drop=True)
cases = df.groupby("case_id").agg(veh=("veh", "first"), t=("ts", "first"), codes=("code", lambda s: tuple(sorted(s))), n=("code", "size"), emergency=("emergency", "max"))
print(f"(동시 발생 묶음 과정에서 중복 코드 {before - len(df)}행 제거)")
rule("R9 동시 발생 코드 정비 건 묶음·정렬(생성 건수)", len(cases))
cases["outlier_flag"] = (cases["n"] > 4) & ~cases["emergency"]
rule("R10 긴급·비계획 정비 보존(일반 이상 건은 표시만)", cases["emergency"].sum())
print("\n[적용 규칙과 처리 건수]")
for nme, n in applied:
    print(f" {nme:40s} {n:5d}건")

# 3) 정합성 검증
checks = {"중복 0건": not df.duplicated(["case_id", "code"]).any(), "차량 ID 형식": df["veh"].str.match(r"^V\d{3}$").all(),
          "코드 허용 범위": df["code"].isin(CODES).all(), "시각 변환": df["ts"].notna().all(), "가동시간 단위 h": (df["op_unit"] == "h").all(),
          "가동시간 0 이상": (df["op_h"] >= 0).all(), "미등록 건 격리 보관": len(quarantine) == unk.sum(),
          "결측 0건": df[["veh", "code", "ts", "op_h"]].notna().all().all(), "묶음 내 코드 정렬": all(list(c) == sorted(c) for c in cases["codes"]),
          f"긴급 정비 {len(bursts) // 6}건 보존": int(cases["emergency"].sum()) >= len(bursts) // 6}
rate = np.mean(list(checks.values()))
print(f"\n정합성 검증 {sum(checks.values())}/{len(checks)} 통과, 통과율 {rate:.0%} (목표 100%: {'달성' if rate == 1 else '미달'})")
for kx, vx in checks.items():
    if not vx:
        print(" 실패:", kx)
print(f"정비 건 {len(cases)}건 생성(평균 DTC {cases['n'].mean():.2f}개), 이상 표시 {int(cases['outlier_flag'].sum())}건")

# 4) 정제 전후 기술통계 비교
num = pd.to_numeric(raw["op_h"], errors="coerce")
cmp = pd.DataFrame({"정제 전": [len(raw), raw["veh"].nunique(), raw["code"].nunique(), num.mean(), num.min(), num.isna().sum()],
                    "정제 후": [len(df), df["veh"].nunique(), df["code"].nunique(), df["op_h"].mean(), df["op_h"].min(), df["op_h"].isna().sum()]},
                   index=["행 수", "차량 종류 수", "코드 종류 수", "가동시간 평균(h)", "가동시간 최소(h)", "결측 수"]).round(1)
print("\n[정제 전후 기술통계]"); print(cmp.to_string())

fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
ax[0].hist(num.dropna(), bins=40, alpha=0.6, label="raw"); ax[0].hist(df["op_h"], bins=40, alpha=0.6, label="cleaned")
ax[0].set_title("Operating hours before/after unit fix"); ax[0].legend()
ax[1].bar([n.split()[0] for n, _ in applied], [n for _, n in applied]); ax[1].set_title("Records changed by rule")
plt.tight_layout(); plt.show()
