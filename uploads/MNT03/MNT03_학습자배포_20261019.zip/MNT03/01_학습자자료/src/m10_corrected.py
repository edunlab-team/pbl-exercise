# [교육용가상자료] 수정 실습본; src/mNN.py 원문 보존본과 구분.
"""DTC 로그 검증·정제, 진단 모델 자동 재학습(챔피언·도전자 비교 후 교체), 고장 코드 기반 연관 고장 진단과 신뢰도 산출, 신뢰도 낮은 건의 정비관 승인 대기 분리, 다빈도 고장품목 월간 소요 예측까지 정비 가이드 도구를 한 파일로 통합 실행하고, 자체 점검·운영 문서 완비 점검·정비 담당 담당자 브리핑 요약을 출력한다."""
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# ---------------------------------------------------------------------------
# 공통 분석 조각: 코드 멀티핫 행렬, 차량 맥락 피처, 학습/검증 분할(앞 12개월 학습, 뒤 6개월 검증)
# ---------------------------------------------------------------------------
CIDX = {c: i for i, c in enumerate(CODES)}
SPLIT_M = 12


def multi_hot(ev):
    X = np.zeros((len(ev), len(CODES)))
    for r, cs in enumerate(ev["codes"]):
        for c in cs:
            X[r, CIDX[c]] = 1
    return X


def context(ev, fleet):
    f = fleet.set_index("veh")
    return np.column_stack([ev["veh"].map(f["age"]) / 25, ev["veh"].map(f["pm_gap"]) / 200, ev["veh"].map(f["terrain"]),
                            ev["veh"].map(f["load"]), (ev["temp"] - 12) / 15])


def feats(ev, fleet):
    X = multi_hot(ev)
    n = X.sum(axis=1, keepdims=True) / 3
    return np.hstack([X, n, context(ev, fleet)])


def monthly_counts(ev):
    return ev.groupby(["month", "part"]).size().unstack(fill_value=0).reindex(columns=PID, fill_value=0)


def build_monthly(ev, fleet, top_n=8, forecast_month=MONTHS - 1):
    """목표월 직전까지의 정보만 피처로 사용. 품목 선정도 학습기간으로 고정."""
    history = ev[ev["month"] < forecast_month]
    top = history["part"].value_counts().index[:top_n]
    mc = ev.groupby(["month", "part"]).size().unstack(fill_value=0).reindex(index=range(MONTHS), columns=top, fill_value=0)
    mh = fleet.attrs["month_h"]
    tm = ev.groupby("month")["temp"].mean().reindex(range(MONTHS))
    rows = []
    for p in top:
        c = mc[p].values.astype(float)
        L = np.log1p(c)
        for m in range(3, forecast_month + 1):
            t = tm.loc[m - 1]  # 전월 평균기온을 지속 예보로 사용
            rows.append({"part": p, "month": m, "y": c[m], "lag1": L[m-1], "lag2": L[m-2], "lag3": L[m-3],
                         "roll3": L[m-3:m].mean(), "trend": L[m-1]-L[m-2], "roll3_std": L[m-3:m].std(),
                         "log_expected": np.log(mh[m-1] / 1000 * RATE[p]),
                         "rate_lag1": c[m-1] / (mh[m-1] / 1000) / RATE[p], "temp": t / 10,
                         "cold_elec": max(0, 12-t) / 10 * (p in ("P03", "P04")),
                         "heat_cool": max(0, t-12) / 10 * (p in ("P06", "P16")),
                         "sin": np.sin(2*np.pi*m/12), "cos": np.cos(2*np.pi*m/12)})
    D = pd.DataFrame(rows)
    return D, [c for c in D.columns if c not in ("part", "month", "y")], top

# ---------------------------------------------------------------------------
# [교육용가상자료] 부품별 정비 조치 가이드라인(요약 3단계). 실제 정비 기술 매뉴얼이 아니라 교육용으로 만든 예시 문구다.
# ---------------------------------------------------------------------------
GUIDE = {
    "P01": "연료 압력 측정 -> 분사기 누설·막힘 확인 -> 불량 시 분사기 교체", "P02": "흡기 압력·이물 점검 -> 축 유격 확인 -> 불량 시 터보차저 교체",
    "P03": "단자 전압·부식 점검 -> 충전 계통 확인 -> 불량 시 축전지 교체", "P04": "발전 전압 측정 -> 벨트·배선 점검 -> 불량 시 발전기 교체",
    "P05": "제어모듈 소프트웨어·커넥터 점검 -> 변속 이력 확인 -> 불량 시 모듈 교체", "P06": "냉각수량·누수 점검 -> 펌프 작동음 확인 -> 불량 시 펌프 교체",
    "P07": "유압 오일량·압력 점검 -> 펌프 누설 확인 -> 불량 시 펌프 교체", "P08": "센서 배선·간극 점검 -> 신호 파형 확인 -> 불량 시 센서 교체",
    "P09": "커넥터 접촉·부식 점검 -> 핀 상태 확인 -> 불량 시 커넥터 교체", "P10": "필터 오염도 점검 -> 연료 흐름 확인 -> 불량 시 필터 교체",
    "P11": "제동 압력 점검 -> 밸브 작동 확인 -> 불량 시 밸브 교체(안전 확인 필수)", "P12": "조향 반응 점검 -> 액추에이터 작동 확인 -> 불량 시 교체(안전 확인 필수)",
    "P13": "필터 차압 점검 -> 오염 확인 -> 불량 시 필터 교체", "P14": "통신 링크 상태 점검 -> 모듈 전원 확인 -> 불량 시 모듈 교체",
    "P15": "압력 센서 신호 점검 -> 윤활유량 확인 -> 불량 시 센서 교체", "P16": "팬 모터 전류 점검 -> 회전 확인 -> 불량 시 모터 교체"}

CONFIG = {"conf_review": 0.8, "retrain_tolerance": 0.0, "mape_target": 0.25}
OPS_GUIDE = {                                                              # docs/mnt03_operations_guide.md 요약
    "1. 목적과 범위": "DTC 기반 고장 부품 진단 보조와 다빈도 고장품목 식별. 최종 정비 판단은 숙련 정비관.",
    "2. 입력 데이터": "DTC 로그(차량 ID, 시각, 코드), 정비 이력(정비 건 ID, 고장 부품), 차량 속성. 실제 조직 자료 외부 AI 입력 금지.",
    "3. 일일 운용 절차": "로그 검증 -> 정비 건 묶음 -> 진단·신뢰도 산출 -> 낮은 신뢰도 건 승인 대기 -> 조치 후 정비 이력 입력.",
    "4. 승인(HITL) 기준": "신뢰도 0.8 미만·다계통 동시 발생은 숙련 정비관 결정 전 확정 금지, 무응답 시 재확인 표시, 결정 사유 기록.",
    "5. 재학습 절차": "월 1회 신규 정비 이력으로 도전자 학습, 검증 정확도가 나빠지지 않을 때만 교체.",
    "6. 장애 대응": "모델 오류 시 단일 코드 매핑표로 대체, 손상 로그는 수동 확인 목록으로 분리.",
    "7. 연동 인터페이스": "물자 정보체계와 DTC·정비 이력 표준 필드(장비코드·분류군·시각)를 CSV/API로 교환하는 안을 차기 과제로 둔다.",
}

fleet, ev, log = make_data()
OLD, NEW, OPS = ev[ev["month"] < 12], ev[(ev["month"] >= 12) & (ev["month"] < 15)], ev[ev["month"] >= 15].reset_index(drop=True)
t_start = time.perf_counter()


def fit(d):
    return LogisticRegression(C=3, max_iter=500).fit(feats(d, fleet), d["part"])


def retrain(champion, old, new):
    """도전자를 (기존 + 신규 앞 2/3 기간)으로 학습하고, 신규 뒤 1/3 기간에서 챔피언과 정확도를 비교해 악화가 없고 허용오차(음수이면 추가 개선 폭) 조건을 만족하면 교체."""
    cut = new["month"].min() + 2
    hold = new[new["month"] >= cut]
    challenger = fit(pd.concat([old, new[new["month"] < cut]], ignore_index=True))
    a_old = (champion.predict(feats(hold, fleet)) == hold["part"].values).mean()
    a_new = (challenger.predict(feats(hold, fleet)) == hold["part"].values).mean()
    swap = a_new >= a_old and a_new >= a_old - CONFIG["retrain_tolerance"]
    return (challenger if swap else champion), {"챔피언": round(float(a_old), 3), "도전자": round(float(a_new), 3), "교체": bool(swap)}


def validate(df):
    ok = df["codes"].map(lambda cs: len(cs) > 0 and all(c in CODES for c in cs)) & df["veh"].isin(fleet["veh"])
    return df[ok].copy(), df[~ok].copy()


def predict_safe(model, d):
    """모델 오류 시 단일 코드 -> 최다 부품 매핑표로 대체한다."""
    try:
        P = model.predict_proba(feats(d, fleet))
        return model.classes_[P.argmax(axis=1)], P.max(axis=1), "모델"
    except Exception:
        mp = OLD.assign(first=OLD["codes"].str[0]).groupby("first")["part"].agg(lambda s: s.value_counts().index[0])
        return d["codes"].str[0].map(mp).fillna("P01").values, np.full(len(d), 0.5), "매핑표 대체"


# ---------------- 1. 통합 실행 ----------------
champion = fit(OLD)
model, rt = retrain(champion, OLD, NEW)
print(f"[교육용가상자료] 재학습: {rt} -> {'도전자로 교체' if rt['교체'] else '챔피언 유지'}")
ops_all = OPS.copy()
ops_all.at[3, "codes"] = ["ZZ9"]; ops_all.at[40, "codes"] = []             # 손상 로그 2건 주입
ops, manual = validate(ops_all)
ops = ops.reset_index(drop=True)
pred, conf, src = predict_safe(model, ops)
# 수정 실습본: M7의 코드-계통 사전 및 다계통 정의와 동일하다.
CSYS = {c: {PSYS[p] for p in PID if c in (SPEC[p], SHARED.get(p)) or c == SYMP[PSYS[p]]} for c in CODES}

def approval_masks(cases, confidence, threshold, code_systems):
    system_count = cases["codes"].map(lambda cs: len(set().union(*[code_systems[c] for c in cs])))
    multi_system = ((cases["codes"].str.len() >= 3) & (system_count >= 3)).values
    low_confidence = np.asarray(confidence) < threshold
    return low_confidence, multi_system

low_conf, multi_sys = approval_masks(ops, conf, CONFIG["conf_review"], CSYS)
review_mask = low_conf | multi_sys
queue = ops.loc[review_mask].copy()
# 무응답/승인 결정 이벤트는 이 예제에서 생성하지 않는다. 모든 큐 항목은 승인 대기다.
queue["approval_status"] = "숙련 정비관 승인 대기"
low_only = int((low_conf & ~multi_sys).sum())
multi_only = int((multi_sys & ~low_conf).sum())
both_review = int((low_conf & multi_sys).sum())
not_review = int((~review_mask).sum())

def approval_checks(cases, pending, low, multi, regression_ids):
    low_ids = set(cases.loc[low, "ev_id"])
    multi_ids = set(cases.loc[multi, "ev_id"])
    pending_ids = set(pending["ev_id"])
    return {
        "저신뢰 집합은 승인 대기 부분집합": low_ids <= pending_ids,
        "다계통 집합은 승인 대기 부분집합": multi_ids <= pending_ids,
        "승인 대기 큐는 두 조건의 합집합(중복 없음)": pending_ids == low_ids | multi_ids and len(pending) == len(pending_ids),
        "기존 누락 4건 승인 대기 포함": regression_ids <= pending_ids,
        "브리핑 집계 일치": len(pending) == int(np.sum(low & ~multi) + np.sum(multi & ~low) + np.sum(low & multi))
            and len(cases) == len(pending) + int(np.sum(~(low | multi))),
    }
REGRESSION_IDS = {"W09389", "W09446", "W09899", "W10082"}
alerts = [(i, p) for i, p in enumerate(pred) if PSYS[p] in CRIT_SYS and conf[i] >= CONFIG["conf_review"]]
acc = (pred == ops["part"].values).mean()
hi = conf >= CONFIG["conf_review"]
print(f"운용 정비 건 {len(ops_all)}건: 진단 {len(ops)}건, 수동 확인 {len(manual)}건, 출처 '{src}', 정확도 {acc:.1%} (신뢰도 0.8 이상 {hi.sum()}건은 {(pred[hi] == ops['part'].values[hi]).mean():.1%})")

# 다빈도 품목 월간 소요 예측(마지막 달): 과거 월로 학습한 릿지로 다음 달 건수 예측
D, FE, top = build_monthly(ev, fleet)
a, b = D[D["month"] < MONTHS - 1], D[D["month"] == MONTHS - 1]
fc = np.exp(make_pipeline(StandardScaler(), Ridge(alpha=3.0)).fit(a[FE], np.log(a["y"])).predict(b[FE]))
fmape = float(np.mean(np.abs(b["y"].values - fc) / b["y"].values))
print("다빈도 품목 다음 달 소요 예측: " + ", ".join(f"{PNAME[p]} {f:.0f}건(실제 {y:.0f})" for p, f, y in zip(b["part"].values[:3], fc[:3], b["y"].values[:3])) + f" / 8개 품목 MAPE {fmape:.1%}")
print("예측 정보 기준: 목표 17월, 피처는 전월까지, 품목 선정 0~16월. 성능 목표 MAPE 25%:", "달성" if fmape <= CONFIG["mape_target"] else "미달", "(구조 점검과 별도)")
sec = time.perf_counter() - t_start

# ---------------- 2. 자체 점검 ----------------
_, _, bad_src = predict_safe(None, ops.head(3))
checks = {
    "로그 유실 0건": len(ops) + len(manual) == len(ops_all),
    "손상 로그 수동 확인 분리": len(manual) == 2,
    "재학습 파이프라인 실행": "교체" in rt,
    "신뢰도 0~1 범위": bool(((conf >= 0) & (conf <= 1)).all()),
    "모델 장애 시 매핑표 대체": bad_src == "매핑표 대체",
    "모든 진단에 조치 가이드 연결": all(p in GUIDE for p in pred),
    **approval_checks(ops, queue, low_conf, multi_sys, REGRESSION_IDS),
    "과거 정보 기반 예측 산출·유한값": bool(np.isfinite(fc).all() and np.isfinite(fmape)),
}
print(f"\n자체 점검 {sum(checks.values())}/{len(checks)} 통과, 자동 재학습 파이프라인 {'정상 실행' if checks['재학습 파이프라인 실행'] else '실패'}, 전체 실행 {sec:.1f}초")
for k, v in checks.items():
    print("점검 {}: {}".format(k, "PASS" if v else "FAIL"))
assert all(checks.values()), checks
doc = sum(bool(v.strip()) for v in OPS_GUIDE.values()) / len(OPS_GUIDE)
print(f"운영 문서 {len(OPS_GUIDE)}개 장 작성률 {doc:.0%} (목표 100%: {'달성' if doc == 1 else '미달'}) - " + ", ".join(k.split(". ")[1] for k in OPS_GUIDE))

# ---------------- 3. 화면과 브리핑 ----------------
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
cnt = pd.Series(pred).value_counts().head(8)
ax[0].bar(cnt.index, cnt.values); ax[0].set_title("Diagnosed parts (operating period)")
ax[1].hist(conf, bins=20); ax[1].axvline(CONFIG["conf_review"], ls="--", color="k"); ax[1].set_title("Confidence (line = review threshold)")
plt.tight_layout(); plt.show()

fr = (ev["part"].value_counts() / fleet["hours"].sum() * 1000)
cum = ev["part"].value_counts(normalize=True).cumsum()
a_cnt = int((cum <= 0.8).sum()) + 1
print("\n[정비 담당 담당자 브리핑 요약] [교육용가상자료]")
print(f"1. 18개월 정비 {len(ev)}건: 고장률 상위 " + ", ".join(f"{PNAME[p]} {v:.1f}건/1000h" for p, v in fr.sort_values(ascending=False).head(3).items()))
print(f"2. 상위 {a_cnt}개 품목이 전체 고장의 80% 이상: 예비 수리부속 우선 확보 대상")
print(f"3. 운용 기간 진단 {len(ops)}건 중 신뢰도 0.8 이상 {int(hi.sum())}건(정확도 {(pred[hi] == ops['part'].values[hi]).mean():.1%}), 정비관 승인 대기 {len(queue)}건(저신뢰만 {low_only}, 다계통만 {multi_only}, 중복 {both_review}; 승인 대상 밖 {not_review}건, 자동 확정 0건)")
print(f"4. 기동·제동 계통 경보 {len(alerts)}건, 손상 로그 {len(manual)}건 수동 확인")
print(f"5. 진단 모델: {'신규 정비 이력으로 교체' if rt['교체'] else '기존 유지'}, 소요 예측 MAPE {fmape:.1%}")
print("6. 건의: 다빈도 품목 예방정비 주기 재검토, 물자 정보체계와 DTC·정비 이력 표준 필드 연동 인터페이스 정의")
