# [교육용가상자료] 수정 실습본; src/mNN.py 원문 보존본과 구분.
"""정비 담당자가 모바일/웹 화면에서 DTC를 입력하면 후보 고장 부품·신뢰도·정비 조치 절차와 판단 근거(기여도 상위 3개 인자)를 보여 주는 진단 대시보드를 구현한다. 모든 예측 건에 상위 3개 인자를 자동 산출하고 근거 제거 시 확률이 실제로 떨어지는지 점검하며, 자연어 요약과 경보 현황 화면을 만든다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# ---------------------------------------------------------------------------
# 공통 분석 조각: 코드 멀티핫 행렬, 차량 맥락 피처, 학습/검증 분할(앞 12개월 학습, 뒤 6개월 검증)
# ---------------------------------------------------------------------------
CIDX = {c: i for i, c in enumerate(CODES)}
SPLIT_M = 12


def multi_hot(ev):
    X = np.zeros((len(ev), len(CODES)))
    for r, cs in enumerate(ev["codes"]):
        for c in cs:
            X[r, CIDX[c]] = 1
    return X


def context(ev, fleet):
    f = fleet.set_index("veh")
    return np.column_stack([ev["veh"].map(f["age"]) / 25, ev["veh"].map(f["pm_gap"]) / 200, ev["veh"].map(f["terrain"]),
                            ev["veh"].map(f["load"]), (ev["temp"] - 12) / 15])


def feats(ev, fleet):
    X = multi_hot(ev)
    n = X.sum(axis=1, keepdims=True) / 3
    return np.hstack([X, n, context(ev, fleet)])


def monthly_counts(ev):
    return ev.groupby(["month", "part"]).size().unstack(fill_value=0).reindex(columns=PID, fill_value=0)


def build_monthly(ev, fleet, top_n=8):
    """부품별 월간 고장 건수 예측용 표: 지연값(lag), 이동평균, 추세, 기대 건수(가동시간 x 설계 고장률), 기온 상호작용, 계절 성분"""
    mc = ev.groupby(["month", "part"]).size().unstack(fill_value=0)
    top = ev["part"].value_counts().index[:top_n]
    mh, tm = fleet.attrs["month_h"], ev.groupby("month")["temp"].mean().values
    rows = []
    for p in top:
        c = mc[p].values.astype(float)
        for m in range(3, MONTHS):
            L = np.log1p(c)
            rows.append({"part": p, "month": m, "y": c[m], "lag1": L[m - 1], "lag2": L[m - 2], "lag3": L[m - 3], "roll3": L[m - 3:m].mean(),
                         "trend": L[m - 1] - L[m - 2], "roll3_std": L[m - 3:m].std(), "log_expected": np.log(mh[m] / 1000 * RATE[p]),
                         "rate_lag1": c[m - 1] / (mh[m - 1] / 1000) / RATE[p], "temp": tm[m] / 10, "cold_elec": max(0, 12 - tm[m]) / 10 * (p in ("P03", "P04")),
                         "heat_cool": max(0, tm[m] - 12) / 10 * (p in ("P06", "P16")), "sin": np.sin(2 * np.pi * m / 12), "cos": np.cos(2 * np.pi * m / 12)})
    D = pd.DataFrame(rows)
    return D, [c for c in D.columns if c not in ("part", "month", "y")], top

# ---------------------------------------------------------------------------
# [교육용가상자료] 부품별 정비 조치 가이드라인(요약 3단계). 실제 정비 기술 매뉴얼이 아니라 교육용으로 만든 예시 문구다.
# ---------------------------------------------------------------------------
GUIDE = {
    "P01": "연료 압력 측정 -> 분사기 누설·막힘 확인 -> 불량 시 분사기 교체", "P02": "흡기 압력·이물 점검 -> 축 유격 확인 -> 불량 시 터보차저 교체",
    "P03": "단자 전압·부식 점검 -> 충전 계통 확인 -> 불량 시 축전지 교체", "P04": "발전 전압 측정 -> 벨트·배선 점검 -> 불량 시 발전기 교체",
    "P05": "제어모듈 소프트웨어·커넥터 점검 -> 변속 이력 확인 -> 불량 시 모듈 교체", "P06": "냉각수량·누수 점검 -> 펌프 작동음 확인 -> 불량 시 펌프 교체",
    "P07": "유압 오일량·압력 점검 -> 펌프 누설 확인 -> 불량 시 펌프 교체", "P08": "센서 배선·간극 점검 -> 신호 파형 확인 -> 불량 시 센서 교체",
    "P09": "커넥터 접촉·부식 점검 -> 핀 상태 확인 -> 불량 시 커넥터 교체", "P10": "필터 오염도 점검 -> 연료 흐름 확인 -> 불량 시 필터 교체",
    "P11": "제동 압력 점검 -> 밸브 작동 확인 -> 불량 시 밸브 교체(안전 확인 필수)", "P12": "조향 반응 점검 -> 액추에이터 작동 확인 -> 불량 시 교체(안전 확인 필수)",
    "P13": "필터 차압 점검 -> 오염 확인 -> 불량 시 필터 교체", "P14": "통신 링크 상태 점검 -> 모듈 전원 확인 -> 불량 시 모듈 교체",
    "P15": "압력 센서 신호 점검 -> 윤활유량 확인 -> 불량 시 센서 교체", "P16": "팬 모터 전류 점검 -> 회전 확인 -> 불량 시 모터 교체"}

SYSKR = {"engine": "엔진", "electric": "전기", "drive": "구동", "hydraulic": "유압", "brake": "제동", "cooling": "냉각"}
SHNAME = {SHARED[p[0]]: f"{PNAME[p[0]]}·{PNAME[p[1]]} 공유" for p in PAIRS}


def code_name(c):
    if c.startswith("S"):
        return f"공유 코드 {c}({SHNAME[c]})"
    if c.startswith("G"):
        return f"{SYSKR[[s for s, v in SYMP.items() if v == c][0]]} 계통 증상 코드 {c}"
    return f"{PNAME['P' + c[1:3]]} 고유 코드 {c}"


FNAME = [code_name(c) for c in CODES] + ["동시 발생 코드 수", "차령", "예방정비 경과시간", "지형 가혹도", "운용 부하", "기온"]
NC = len(CODES)

fleet, ev, log = make_data()
train, test = ev[ev["month"] < SPLIT_M], ev[ev["month"] >= SPLIT_M].reset_index(drop=True)
Xtr, Xte = feats(train, fleet), feats(test, fleet)
clf = LogisticRegression(C=3, max_iter=500).fit(Xtr, train["part"])
P = clf.predict_proba(Xte)
cls, mu = clf.classes_, Xtr.mean(axis=0)
pred = P.argmax(axis=1)


def explain(i, k=3):
    """예측 부품에 대한 입력 인자별 기여도 = 계수 x (입력값 - 학습 평균). 값이 큰 인자 k개를 반환."""
    contrib = clf.coef_[pred[i]] * (Xte[i] - mu)
    contrib[:NC][Xte[i][:NC] == 0] = -np.inf                  # 입력되지 않은 코드는 근거에서 제외
    idx = np.argsort(-contrib)[:k]
    return [(FNAME[j], contrib[j]) for j in idx], idx


def summary(i):
    f, _ = explain(i)
    return (f"{PNAME[cls[pred[i]]]} 고장 가능성 {P[i, pred[i]]:.0%}. 주요 근거: " + ", ".join(n for n, _ in f) + ".")


# 1) 전 예측 건 기여도 자동 산출 + 근거 유효성 점검
ok3, drop = 0, 0
for i in range(len(test)):
    f, idx = explain(i)
    ok3 += len(f) == 3
    x2 = Xte[i].copy(); x2[idx[0]] = mu[idx[0]]              # 가장 큰 근거를 평균값으로 되돌려 본다
    drop += clf.predict_proba(x2[None])[0, pred[i]] < P[i, pred[i]]
print(f"[교육용가상자료] 예측 {len(test)}건 중 기여도 상위 3개 인자 산출 {ok3}건 (산출률 {ok3 / len(test):.0%}, 목표 100%: {'달성' if ok3 == len(test) else '미달'})")
print(f"근거 유효성: 상위 인자를 평균값으로 되돌리면 예측 확률이 낮아지는 비율 {drop / len(test):.1%}")

# 2) 모바일 진단 카드 2건: 신뢰도 높음 / 낮음
print("\n[모바일 진단 카드]")
for tgt in (0.95, 0.55):
    i = int(np.argmin(np.abs(P.max(axis=1) - tgt)))
    f, _ = explain(i)
    print(f" 입력 DTC {test['codes'][i]}  (실제 고장 {PNAME[test['part'][i]]})")
    print(f"   진단 {PNAME[cls[pred[i]]]} 신뢰도 {P[i, pred[i]]:.0%} | 근거: " + " / ".join(f"{n}({v:+.1f})" for n, v in f))
    print(f"   조치 절차: {GUIDE[cls[pred[i]]]}")
    if P[i, pred[i]] < 0.7: print("   신뢰도 낮음: 숙련 정비관 확인 권고")
    print(f"   요약: {summary(i)}")

# 3) 웹 대시보드: 최근 달 현황과 경보
last = test[test["month"] == MONTHS - 1]
li = last.index.values
alert = [(PSYS[cls[pred[i]]] in CRIT_SYS) and P[i, pred[i]] >= 0.7 for i in li]
print(f"\n[웹 대시보드] 최근 달 정비 건 {len(last)}건, 기동·제동 계통 경보 {sum(alert)}건, 신뢰도 낮음(0.7 미만) {int((P[li].max(axis=1) < 0.7).sum())}건")
cnt = pd.Series([cls[pred[i]] for i in li]).value_counts().head(3)
print("  다빈도 진단 부품: " + ", ".join(f"{PNAME[p]} {n}건" for p, n in cnt.items()))

fig, ax = plt.subplots(2, 2, figsize=(11, 7))
cnt5 = pd.Series([cls[pred[i]] for i in li]).value_counts().head(8)
ax[0, 0].bar(cnt5.index, cnt5.values); ax[0, 0].set_title("Diagnosed parts (last month)")
mon = ev.groupby("month").size(); ax[0, 1].plot(mon.index, mon.values, marker="o"); ax[0, 1].set_title("Monthly maintenance cases")
j = int(np.argmin(np.abs(P.max(axis=1) - 0.55))); f, _ = explain(j)
ax[1, 0].barh([f"factor {k + 1}" for k in range(3)][::-1], [v for _, v in f][::-1]); ax[1, 0].set_title("Top-3 contributions (low-confidence case)")
ax[1, 1].hist(P.max(axis=1), bins=20); ax[1, 1].axvline(0.7, ls="--", color="k"); ax[1, 1].set_title("Confidence distribution (line = 0.7)")
plt.tight_layout(); plt.show()
