# [교육용가상자료] 수정 실습본; src/mNN.py 원문 보존본과 구분.
"""Apriori 연관 규칙 마이닝으로 여러 DTC가 동시에 나타났을 때의 근본 원인 부품을 예측하는 모델을 만들어 단일 코드 Baseline과 비교하고, 부품별 월간 고장 건수 예측용 파생 피처 10개 이상으로 기준 모델을 학습해 시계열 교차검증 MAPE와 피처 중요도를 확인한다."""
import itertools
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.inspection import permutation_importance

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# ---------------------------------------------------------------------------
# 공통 분석 조각: 코드 멀티핫 행렬, 차량 맥락 피처, 학습/검증 분할(앞 12개월 학습, 뒤 6개월 검증)
# ---------------------------------------------------------------------------
CIDX = {c: i for i, c in enumerate(CODES)}
SPLIT_M = 12


def multi_hot(ev):
    X = np.zeros((len(ev), len(CODES)))
    for r, cs in enumerate(ev["codes"]):
        for c in cs:
            X[r, CIDX[c]] = 1
    return X


def context(ev, fleet):
    f = fleet.set_index("veh")
    return np.column_stack([ev["veh"].map(f["age"]) / 25, ev["veh"].map(f["pm_gap"]) / 200, ev["veh"].map(f["terrain"]),
                            ev["veh"].map(f["load"]), (ev["temp"] - 12) / 15])


def feats(ev, fleet):
    X = multi_hot(ev)
    n = X.sum(axis=1, keepdims=True) / 3
    return np.hstack([X, n, context(ev, fleet)])


def monthly_counts(ev):
    return ev.groupby(["month", "part"]).size().unstack(fill_value=0).reindex(columns=PID, fill_value=0)


def build_monthly(ev, fleet, top_n=8):
    """부품별 월간 고장 건수 예측용 표: 지연값(lag), 이동평균, 추세, 기대 건수(가동시간 x 설계 고장률), 기온 상호작용, 계절 성분"""
    mc = ev.groupby(["month", "part"]).size().unstack(fill_value=0)
    top = ev["part"].value_counts().index[:top_n]
    mh, tm = fleet.attrs["month_h"], ev.groupby("month")["temp"].mean().values
    rows = []
    for p in top:
        c = mc[p].values.astype(float)
        for m in range(3, MONTHS):
            L = np.log1p(c)
            rows.append({"part": p, "month": m, "y": c[m], "lag1": L[m - 1], "lag2": L[m - 2], "lag3": L[m - 3], "roll3": L[m - 3:m].mean(),
                         "trend": L[m - 1] - L[m - 2], "roll3_std": L[m - 3:m].std(), "log_expected": np.log(mh[m] / 1000 * RATE[p]),
                         "rate_lag1": c[m - 1] / (mh[m - 1] / 1000) / RATE[p], "temp": tm[m] / 10, "cold_elec": max(0, 12 - tm[m]) / 10 * (p in ("P03", "P04")),
                         "heat_cool": max(0, tm[m] - 12) / 10 * (p in ("P06", "P16")), "sin": np.sin(2 * np.pi * m / 12), "cos": np.cos(2 * np.pi * m / 12)})
    D = pd.DataFrame(rows)
    return D, [c for c in D.columns if c not in ("part", "month", "y")], top

fleet, ev, log = make_data()
ev["first"] = ev["codes"].str[0]
train, test = ev[ev["month"] < 12], ev[ev["month"] >= 12]


# 1) Apriori: 항목 = DTC 코드 + 근본 원인 항목(ROOT:부품). 수준별로 후보를 만들고 최소 지지도 미만은 가지치기한다.
def apriori(trans, min_sup, max_len=3):
    n = len(trans)
    cnt = Counter(i for t in trans for i in t)
    freq = {frozenset([i]): c / n for i, c in cnt.items() if c / n >= min_sup}
    allf, cur = dict(freq), list(freq)
    for k in range(2, max_len + 1):
        cands = {a | b for a, b in itertools.combinations(cur, 2) if len(a | b) == k}
        cands = {c for c in cands if all(frozenset(s) in allf for s in itertools.combinations(c, k - 1))}   # 부분집합 가지치기
        cc = Counter(c for t in trans for c in cands if c <= t)
        cur = [c for c, v in cc.items() if v / n >= min_sup]
        allf.update({c: cc[c] / n for c in cur})
    return allf


trans = [frozenset(cs) | {"ROOT:" + p} for cs, p in zip(train["codes"], train["part"])]
F = apriori(trans, min_sup=0.004)
rules = []
for s, sup in F.items():
    roots = [i for i in s if i.startswith("ROOT:")]
    if len(roots) == 1 and len(s) >= 2:
        ante = s - set(roots)
        conf = sup / F[ante]
        lift = conf / F[frozenset(roots)]
        rules.append({"ante": ante, "part": roots[0][5:], "sup": sup, "conf": conf, "lift": lift})
R = pd.DataFrame(rules)
R = R[(R["conf"] >= 0.5) & (R["lift"] > 1.5)].sort_values("conf", ascending=False).reset_index(drop=True)
print(f"[교육용가상자료] 학습 정비 건 {len(train)}건: 빈발 항목집합 {len(F)}개 -> 연관 규칙 {len(R)}개 (신뢰도 0.5 이상, 향상도 1.5 초과)")
for r in R.head(4).itertuples():
    print(f"  {{{', '.join(sorted(r.ante))}}} -> {PNAME[r.part]}  지지도 {r.sup:.3f} 신뢰도 {r.conf:.2f} 향상도 {r.lift:.1f}")

mp = train.groupby("first")["part"].agg(lambda s: s.value_counts().index[0])
rl = sorted(zip(R["ante"], R["part"], R["conf"]), key=lambda x: (-x[2], -len(x[0])))


def rule_predict(codes, fallback):
    for a, p, c in rl:
        if a <= set(codes):
            return p, c
    return fallback, 0.0


pr = [rule_predict(cs, mp.get(f, "P01")) for cs, f in zip(test["codes"], test["first"])]
pred_rule = np.array([p for p, _ in pr]); pred_base = test["first"].map(mp).values
a_b, a_r = (pred_base == test["part"].values).mean(), (pred_rule == test["part"].values).mean()
multi = test["codes"].str.len().values >= 2
print(f"\n근본 원인 정확도: 단일 코드 Baseline {a_b:.1%} -> 연관 규칙 {a_r:.1%} (코드 2개 이상 동시 발생 건 {(pred_base[multi] == test['part'].values[multi]).mean():.1%} -> {(pred_rule[multi] == test['part'].values[multi]).mean():.1%})")

# 2) 파생 피처 + 월간 고장 건수 기준 모델(상위 8개 부품, 건수는 로그 변환해 학습)
D, FE, top = build_monthly(ev, fleet)
print(f"\n월간 고장 건수 예측: 파생 피처 {len(FE)}개 (목표 10개 이상: {'달성' if len(FE) >= 10 else '미달'}), 대상 {len(top)}개 부품 x {MONTHS - 3}개월")


def model():
    return make_pipeline(StandardScaler(), Ridge(alpha=3.0))


def mape(a, p):
    return float(np.mean(np.abs(a - p) / a))


# 3) 시계열 교차검증: 확장 윈도(과거로만 학습, 뒤 2개월 검증)
folds, mapes = [(range(3, s), range(s, s + 2)) for s in (11, 13, 15)], []
for tr, te in folds:
    a, b = D[D["month"].isin(tr)], D[D["month"].isin(te)]
    mapes.append(mape(b["y"].values, np.exp(model().fit(a[FE], np.log(a["y"])).predict(b[FE]))))
cv = float(np.mean(mapes))
print("시계열 교차검증 폴드별 MAPE: " + ", ".join(f"{m:.1%}" for m in mapes) + f" -> 평균 {cv:.1%} (목표 25% 이하: {'달성' if cv <= 0.25 else '미달'})")

# 4) 피처 중요도(순열 중요도)로 차원 축소
# 수정 실습본: 중요도 선택은 훈련 구간 내부에서만 수행한다.
# 월 번호는 0부터 시작한다. 외부 평가 자료 b는 선택 과정에 전달하지 않는다.
a, b = D[D["month"] < 13], D[D["month"] >= 13]
inner_train = a[a["month"] < 11]
selection = a[a["month"] >= 11]

def select_features(inner_train, selection, features):
    selector = model().fit(inner_train[features], np.log(inner_train["y"]))
    importance = permutation_importance(selector, selection[features], np.log(selection["y"]),
        n_repeats=20, random_state=0, scoring="neg_mean_absolute_error").importances_mean
    ranking = np.argsort(-importance)
    return importance, ranking, [features[i] for i in ranking[:8]]

imp, order, keep = select_features(inner_train, selection, FE)
# 선택을 확정한 뒤 전체 훈련 구간(내부 학습+선택)으로 두 모델을 재학습한다.
m = model().fit(a[FE], np.log(a["y"]))
m5 = model().fit(a[keep], np.log(a["y"]))
def row_ids(frame):
    return set(map(tuple, frame[["part", "month"]].to_numpy()))
split_checks = {
    "내부 학습/선택 분리": row_ids(inner_train).isdisjoint(row_ids(selection)),
    "훈련/평가 분리": row_ids(a).isdisjoint(row_ids(b)),
    "시간 순서": inner_train["month"].max() < selection["month"].min()
        and selection["month"].max() < b["month"].min(),
}
assert all(split_checks.values()), split_checks
print(f"변수 선택/평가 분리 자체 점검 {sum(split_checks.values())}/{len(split_checks)} 통과")
print(f"내부 학습 3~10월 {len(inner_train)}행 / 변수 선택 11~12월 {len(selection)}행 / 재학습 3~12월 {len(a)}행 / 평가 13~17월 {len(b)}행")
full, red = mape(b["y"].values, np.exp(m.predict(b[FE]))), mape(b["y"].values, np.exp(m5.predict(b[keep])))
print("피처 중요도 상위 5: " + ", ".join(f"{FE[i]}({imp[i]:.2f})" for i in order[:5]))
print(f"차원 축소 {len(FE)}개 -> 8개: 선택과 분리된 평가 MAPE {full:.1%} -> {red:.1%}")

fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
ax[0].bar(["baseline", "rules"], [a_b, a_r]); ax[0].set_title("Root-cause accuracy")
ax[1].barh([FE[i] for i in order[:8]][::-1], imp[order[:8]][::-1]); ax[1].set_title("Internal selection importance (log MAE)")
plt.tight_layout(); plt.show()
