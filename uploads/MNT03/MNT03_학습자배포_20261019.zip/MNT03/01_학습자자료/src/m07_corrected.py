# [교육용가상자료] 수정 실습본; 원문 별도 보존.
"""복합 고장이 의심되는 정비 건(신뢰도 낮음, 서로 다른 계통의 DTC 동시 발생)을 숙련 정비관 2차 정밀 진단 대기열에 올려 승인·정정·무응답(엔진 안 유지·재확인 표시)을 사유와 함께 해시 체인 감사 로그에 남기는 HITL 워크플로우 시뮬레이터를 구현한다. 자동 확정 0건, 오진단 비용 절감률, 신뢰도 기준·정비관 수용량·고장 급증에 대한 민감도를 확인한다."""
import hashlib
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# ---------------------------------------------------------------------------
# 공통 분석 조각: 코드 멀티핫 행렬, 차량 맥락 피처, 학습/검증 분할(앞 12개월 학습, 뒤 6개월 검증)
# ---------------------------------------------------------------------------
CIDX = {c: i for i, c in enumerate(CODES)}
SPLIT_M = 12


def multi_hot(ev):
    X = np.zeros((len(ev), len(CODES)))
    for r, cs in enumerate(ev["codes"]):
        for c in cs:
            X[r, CIDX[c]] = 1
    return X


def context(ev, fleet):
    f = fleet.set_index("veh")
    return np.column_stack([ev["veh"].map(f["age"]) / 25, ev["veh"].map(f["pm_gap"]) / 200, ev["veh"].map(f["terrain"]),
                            ev["veh"].map(f["load"]), (ev["temp"] - 12) / 15])


def feats(ev, fleet):
    X = multi_hot(ev)
    n = X.sum(axis=1, keepdims=True) / 3
    return np.hstack([X, n, context(ev, fleet)])


def monthly_counts(ev):
    return ev.groupby(["month", "part"]).size().unstack(fill_value=0).reindex(columns=PID, fill_value=0)


def build_monthly(ev, fleet, top_n=8):
    """부품별 월간 고장 건수 예측용 표: 지연값(lag), 이동평균, 추세, 기대 건수(가동시간 x 설계 고장률), 기온 상호작용, 계절 성분"""
    mc = ev.groupby(["month", "part"]).size().unstack(fill_value=0)
    top = ev["part"].value_counts().index[:top_n]
    mh, tm = fleet.attrs["month_h"], ev.groupby("month")["temp"].mean().values
    rows = []
    for p in top:
        c = mc[p].values.astype(float)
        for m in range(3, MONTHS):
            L = np.log1p(c)
            rows.append({"part": p, "month": m, "y": c[m], "lag1": L[m - 1], "lag2": L[m - 2], "lag3": L[m - 3], "roll3": L[m - 3:m].mean(),
                         "trend": L[m - 1] - L[m - 2], "roll3_std": L[m - 3:m].std(), "log_expected": np.log(mh[m] / 1000 * RATE[p]),
                         "rate_lag1": c[m - 1] / (mh[m - 1] / 1000) / RATE[p], "temp": tm[m] / 10, "cold_elec": max(0, 12 - tm[m]) / 10 * (p in ("P03", "P04")),
                         "heat_cool": max(0, tm[m] - 12) / 10 * (p in ("P06", "P16")), "sin": np.sin(2 * np.pi * m / 12), "cos": np.cos(2 * np.pi * m / 12)})
    D = pd.DataFrame(rows)
    return D, [c for c in D.columns if c not in ("part", "month", "y")], top

fleet, ev, log = make_data()
train, test = ev[ev["month"] < SPLIT_M], ev[ev["month"] >= SPLIT_M].reset_index(drop=True)
clf = LogisticRegression(C=3, max_iter=500).fit(feats(train, fleet), train["part"])
P = clf.predict_proba(feats(test, fleet))
cls = clf.classes_
top1 = cls[P.argmax(axis=1)]
conf = P.max(axis=1)
CSYS = {c: {PSYS[p] for p in PID if c in (SPEC[p], SHARED.get(p)) or c == SYMP[PSYS[p]]} for c in CODES}
nsys = test["codes"].map(lambda cs: len(set().union(*[CSYS[c] for c in cs])))
multi_sys = ((test["codes"].str.len() >= 3) & (nsys >= 3)).values          # 3개 이상 계통에 걸친 DTC가 동시에 발생
THR, CAP = 0.8, 300      # 운영점: 신뢰도 0.8 미만 또는 다계통 동시 발생이면 정밀 진단, 정비관 월 수용량 300건(아래 민감도 분석으로 선정)

# [교육용가상자료] 가정 비용지수: 오진단 시 헛교체 부품비 + 헛교체 공수 + 재입고 패널티 3.0 + 올바른 수리, 정밀 진단 1건 1.0
REVIEW_COST, REVISIT, SENIOR_ACC, NO_RESP = 1.0, 3.0, 0.93, 0.08


def case_cost(pred, true):
    if pred == true:
        return REPH[true]
    return COST[pred] + REPH[pred] + REVISIT + REPH[true]


class Audit:
    def __init__(self):
        self.log = []

    def add(self, **body):
        prev = self.log[-1]["hash"] if self.log else "GENESIS"
        body = {"seq": len(self.log), **body}
        self.log.append({**body, "prev": prev, "hash": hashlib.sha256((prev + json.dumps(body, sort_keys=True, ensure_ascii=False)).encode()).hexdigest()})

    def verify(self):
        prev = "GENESIS"
        for e in self.log:
            b = {k: v for k, v in e.items() if k not in ("prev", "hash")}
            if e["prev"] != prev or hashlib.sha256((prev + json.dumps(b, sort_keys=True, ensure_ascii=False)).encode()).hexdigest() != e["hash"]:
                return e["seq"]
            prev = e["hash"]
        return None


def run(thr=THR, cap=CAP, surge=1.0, seed=0, audit=None, mode="hitl", requests=None):
    """고유 요청 단위 처리. 미결은 확정 진단·비용/오진 분모에서 제외한다.
    surge 신규 요청은 별도 ID를 부여하고, 같은 ID의 재전송은 한 번만 처리한다.
    """
    assert mode in ("hitl", "auto") and cap >= 0 and surge >= 1
    rng = np.random.default_rng(seed)
    audit = Audit() if audit is None else audit
    if requests is None:
        requests = [(str(test.iloc[i]["ev_id"]), i) for i in range(len(test))]
        extra = rng.choice(len(test), int(len(test) * (surge - 1)), replace=True)
        requests += [(f"SURGE-{j}-{test.iloc[int(i)]['ev_id']}", int(i)) for j, i in enumerate(extra)]
    unique = {}
    for request_id, i in requests:
        if request_id in unique:
            assert unique[request_id] == i, "동일 요청 ID의 내용 충돌"
        unique[request_id] = i
    records, monthly = [], {}
    cost, wrong, comparable_auto_cost = 0.0, 0, 0.0
    for m in range(SPLIT_M, MONTHS):
        mi = [(rid, i) for rid, i in unique.items() if test.iloc[i]["month"] == m]
        flag = [(rid, i) for rid, i in mi if conf[i] < thr or multi_sys[i]]
        flag.sort(key=lambda item: (PSYS[top1[item[1]]] not in CRIT_SYS, conf[item[1]], item[0]))
        queue = {rid for rid, i in flag[:cap]} if mode == "hitl" else set()
        processed = 0
        for rid, i in mi:
            true, final = test.iloc[i]["part"], None
            suspicious = bool(conf[i] < thr or multi_sys[i])
            status, origin = "PENDING_CAPACITY", None
            if rid in queue:
                processed += 1
                assert processed <= cap, (m, processed, cap)
                audit.add(event="PROPOSE", case=rid, engine=str(top1[i]), status="PENDING")
                cost += REVIEW_COST
                r = rng.random()
                if r < NO_RESP:
                    status = "PENDING_NO_RESPONSE"
                    audit.add(event="NO_RESPONSE", case=rid, status=status, reason="무응답: 미결/재확인", final=None)
                else:
                    if r < NO_RESP + (1 - NO_RESP) * SENIOR_ACC:
                        final, why = true, "추가 계측·부품 분리 점검으로 확인"
                    else:
                        final, why = cls[np.argsort(-P[i])[1]], "2순위 후보로 정정(근거 부족)"
                    status, origin = "CONFIRMED", "HUMAN"
                    audit.add(event="DECIDE", case=rid, decision="승인" if final == top1[i] else "정정",
                              final=str(final), reason=why, by="숙련 정비관(모의)")
            elif suspicious and mode == "hitl":
                audit.add(event="PENDING_CAPACITY", case=rid, final=None, reason="월 수용량 초과: 미결/재확인")
            else:
                final, status, origin = top1[i], "CONFIRMED", "ENGINE"
                audit.add(event="AUTO_CONFIRM", case=rid, final=str(final), suspicious=suspicious)
            if final is not None:
                cost += case_cost(final, true)
                comparable_auto_cost += case_cost(top1[i], true)
                wrong += final != true
            records.append(dict(request_id=rid, month=m, suspicious=suspicious, queued=rid in queue,
                                status=status, origin=origin, final=final))
        monthly[m] = processed
        assert processed == len(queue) and processed <= cap, (m, processed, cap)
    decided = sum(r["origin"] == "HUMAN" for r in records)
    confirmed = sum(r["status"] == "CONFIRMED" for r in records)
    auto = sum(r["suspicious"] and not r["queued"] and r["origin"] == "ENGINE" and r["final"] is not None for r in records)
    logged = sum(e["event"] == "DECIDE" for e in audit.log)
    assert decided == logged
    assert len(records) == len(unique)
    return {"cost": cost, "wrong": wrong / max(confirmed, 1), "queued": sum(monthly.values()),
            "decided": decided, "logged": logged, "silent": sum(r["status"] == "PENDING_NO_RESPONSE" for r in records),
            "overflow": sum(r["status"] == "PENDING_CAPACITY" for r in records),
            "n": len(records), "auto": auto, "confirmed": confirmed, "monthly": monthly,
            "duplicates": len(requests) - len(unique), "records": records, "comparable_auto_cost": comparable_auto_cost}


aud = Audit()
A, H = run(mode="auto", audit=Audit()), run(audit=aud)
print(f"[교육용가상자료] 고유 요청 {H['n']}건, 의심 건 {sum(r['suspicious'] for r in H['records'])}건")
print(f"비교용 엔진 단독: 의심 건 자동 확정 {A['auto']}건 (운영 금지 비교)")
print(f"HITL 대기열 {H['queued']}건, 결정 {H['decided']}건, 미결/재확인: 무응답 {H['silent']}건 + 수용량 밖 {H['overflow']}건")
print(f"의심 건 자동 확정 {H['auto']}건 (확정 기록에서 계산)")
print(f"결정 로깅률(대기열 대비 결정 비율) {H['decided'] / max(H['queued'], 1):.1%} ({H['decided']}/{H['queued']}); 결정 이벤트 기록률 {H['logged'] / max(H['decided'], 1):.0%}")
print(f"확정 진단 {H['confirmed']}건 기준 오진단율 {H['wrong']:.1%}; 미결은 오진·정상 판정에서 제외")
cut = 1 - H['cost'] / H['comparable_auto_cost']
print(f"확정 집합 비교 비용 절감률 {cut:.1%} (검토비는 무응답 포함, 미결 수리·지연 비용 미포함)")
print("원문 전체 업무 비용절감 15% 목표 달성은 이 부분집합 지표로 판정하지 않는다.")
print("결정 사유 예:", "; ".join(sorted({e['reason'] for e in aud.log if e['event'] == 'DECIDE'})))
import copy
probe = copy.deepcopy(aud)
probe.log[7]['reason'] = '사후 수정'
print(f"감사 로그 무결성: {'정상' if aud.verify() is None else '이상'}, 사본 변조 시 seq {probe.verify()}에서 탐지")
print("[수용량 민감도] 월별 처리 건수; 급증은 신규 요청 ID, 동일 ID 재전송은 중복 제거")
for cap in (50, 100, 200, 300):
    for surge in (1.0, 1.5):
        result = run(cap=cap, surge=surge)
        assert all(v <= cap for v in result['monthly'].values())
        print(f"cap={cap}, surge={surge}: {list(result['monthly'].values())}, 무응답 {result['silent']}, 수용량 밖 {result['overflow']}, 자동 확정 {result['auto']}")
print("[신뢰도 민감도] 확정 집합 비용 비교; 미결 비용 제외, 전체 비용 목표 미판정")
for threshold in (0.5, 0.6, 0.7, 0.8, 0.9):
    r = run(thr=threshold)
    saving = 100 * (1 - r['cost'] / r['comparable_auto_cost']) if r['comparable_auto_cost'] else float('nan')
    print(f"thr={threshold}: 확정 집합 절감률 {saving:.1f}%, 대기열 {r['queued']}, 미결 {r['silent']+r['overflow']}")
print("[급증 비용 민감도] 각 조건의 확정 집합만 비교; 미결을 비용 0으로 간주하지 않음")
for capacity in (100, 300):
    for surge_rate in (1.0, 1.5):
        r = run(cap=capacity, surge=surge_rate)
        saving = 100 * (1 - r['cost'] / r['comparable_auto_cost']) if r['comparable_auto_cost'] else float('nan')
        print(f"cap={capacity}, surge={surge_rate}: 확정 집합 절감률 {saving:.1f}%, 확정 {r['confirmed']}, 미결 {r['silent']+r['overflow']}")
print("수용량 자체 점검 통과 (급증 포함)")
plt.figure(figsize=(6, 3.5))
plt.bar(list(H['monthly']), list(H['monthly'].values()))
plt.axhline(CAP, ls='--'); plt.xlabel('month'); plt.ylabel('reviewed requests')
plt.title('Monthly unique requests reviewed'); plt.tight_layout(); plt.show()
