"""DTC 조합과 차량 맥락을 입력받아 후보 고장 부품 3개와 추천 신뢰도 점수, 정비 조치 가이드라인을 산출하는 추천 엔진을 개발하고, 신뢰도가 실제 정확도와 맞는지(보정) 확인한다. 부품별 월간 고장 건수 예측은 전월값 기준 모델 대비 릿지·그래디언트 부스팅 앙상블의 MAE/RMSE 개선율과 R2로 평가한다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# ---------------------------------------------------------------------------
# 공통 분석 조각: 코드 멀티핫 행렬, 차량 맥락 피처, 학습/검증 분할(앞 12개월 학습, 뒤 6개월 검증)
# ---------------------------------------------------------------------------
CIDX = {c: i for i, c in enumerate(CODES)}
SPLIT_M = 12


def multi_hot(ev):
    X = np.zeros((len(ev), len(CODES)))
    for r, cs in enumerate(ev["codes"]):
        for c in cs:
            X[r, CIDX[c]] = 1
    return X


def context(ev, fleet):
    f = fleet.set_index("veh")
    return np.column_stack([ev["veh"].map(f["age"]) / 25, ev["veh"].map(f["pm_gap"]) / 200, ev["veh"].map(f["terrain"]),
                            ev["veh"].map(f["load"]), (ev["temp"] - 12) / 15])


def feats(ev, fleet):
    X = multi_hot(ev)
    n = X.sum(axis=1, keepdims=True) / 3
    return np.hstack([X, n, context(ev, fleet)])


def monthly_counts(ev):
    return ev.groupby(["month", "part"]).size().unstack(fill_value=0).reindex(columns=PID, fill_value=0)


def build_monthly(ev, fleet, top_n=8):
    """부품별 월간 고장 건수 예측용 표: 지연값(lag), 이동평균, 추세, 기대 건수(가동시간 x 설계 고장률), 기온 상호작용, 계절 성분"""
    mc = ev.groupby(["month", "part"]).size().unstack(fill_value=0)
    top = ev["part"].value_counts().index[:top_n]
    mh, tm = fleet.attrs["month_h"], ev.groupby("month")["temp"].mean().values
    rows = []
    for p in top:
        c = mc[p].values.astype(float)
        for m in range(3, MONTHS):
            L = np.log1p(c)
            rows.append({"part": p, "month": m, "y": c[m], "lag1": L[m - 1], "lag2": L[m - 2], "lag3": L[m - 3], "roll3": L[m - 3:m].mean(),
                         "trend": L[m - 1] - L[m - 2], "roll3_std": L[m - 3:m].std(), "log_expected": np.log(mh[m] / 1000 * RATE[p]),
                         "rate_lag1": c[m - 1] / (mh[m - 1] / 1000) / RATE[p], "temp": tm[m] / 10, "cold_elec": max(0, 12 - tm[m]) / 10 * (p in ("P03", "P04")),
                         "heat_cool": max(0, tm[m] - 12) / 10 * (p in ("P06", "P16")), "sin": np.sin(2 * np.pi * m / 12), "cos": np.cos(2 * np.pi * m / 12)})
    D = pd.DataFrame(rows)
    return D, [c for c in D.columns if c not in ("part", "month", "y")], top

# ---------------------------------------------------------------------------
# [교육용가상자료] 부품별 정비 조치 가이드라인(요약 3단계). 실제 정비 기술 매뉴얼이 아니라 교육용으로 만든 예시 문구다.
# ---------------------------------------------------------------------------
GUIDE = {
    "P01": "연료 압력 측정 -> 분사기 누설·막힘 확인 -> 불량 시 분사기 교체", "P02": "흡기 압력·이물 점검 -> 축 유격 확인 -> 불량 시 터보차저 교체",
    "P03": "단자 전압·부식 점검 -> 충전 계통 확인 -> 불량 시 축전지 교체", "P04": "발전 전압 측정 -> 벨트·배선 점검 -> 불량 시 발전기 교체",
    "P05": "제어모듈 소프트웨어·커넥터 점검 -> 변속 이력 확인 -> 불량 시 모듈 교체", "P06": "냉각수량·누수 점검 -> 펌프 작동음 확인 -> 불량 시 펌프 교체",
    "P07": "유압 오일량·압력 점검 -> 펌프 누설 확인 -> 불량 시 펌프 교체", "P08": "센서 배선·간극 점검 -> 신호 파형 확인 -> 불량 시 센서 교체",
    "P09": "커넥터 접촉·부식 점검 -> 핀 상태 확인 -> 불량 시 커넥터 교체", "P10": "필터 오염도 점검 -> 연료 흐름 확인 -> 불량 시 필터 교체",
    "P11": "제동 압력 점검 -> 밸브 작동 확인 -> 불량 시 밸브 교체(안전 확인 필수)", "P12": "조향 반응 점검 -> 액추에이터 작동 확인 -> 불량 시 교체(안전 확인 필수)",
    "P13": "필터 차압 점검 -> 오염 확인 -> 불량 시 필터 교체", "P14": "통신 링크 상태 점검 -> 모듈 전원 확인 -> 불량 시 모듈 교체",
    "P15": "압력 센서 신호 점검 -> 윤활유량 확인 -> 불량 시 센서 교체", "P16": "팬 모터 전류 점검 -> 회전 확인 -> 불량 시 모터 교체"}

fleet, ev, log = make_data()
train, test = ev[ev["month"] < SPLIT_M], ev[ev["month"] >= SPLIT_M]

# 1) 추천 엔진: DTC 멀티핫 + 맥락 -> 부품별 확률(= 추천 신뢰도 점수)
Xtr, Xte = feats(train, fleet), feats(test, fleet)
clf = LogisticRegression(C=3, max_iter=500).fit(Xtr, train["part"])
P = clf.predict_proba(Xte)
cls = clf.classes_
top1 = cls[P.argmax(axis=1)]
conf = P.max(axis=1)
y = test["part"].values
top3 = np.mean([t in cls[np.argsort(-p)[:3]] for t, p in zip(y, P)])
mp = train.assign(first=train["codes"].str[0]).groupby("first")["part"].agg(lambda s: s.value_counts().index[0])
base_acc = (test["codes"].str[0].map(mp).values == y).mean()
print(f"[교육용가상자료] 추천 엔진 검증 {len(test)}건: top-1 정확도 {(top1 == y).mean():.1%} (단일 코드 Baseline {base_acc:.1%}), top-3 포함률 {top3:.1%}")

# 2) 신뢰도 점수 보정: 신뢰도 구간별 실제 정확도
bins = [0, 0.5, 0.7, 0.9, 1.01]
lab = ["~0.5", "0.5~0.7", "0.7~0.9", "0.9~"]
cb = pd.cut(conf, bins, labels=lab, right=False)
cal = pd.DataFrame({"conf": conf, "ok": top1 == y, "b": cb}).groupby("b", observed=True).agg(건수=("ok", "size"), 평균신뢰도=("conf", "mean"), 실제정확도=("ok", "mean"))
print("\n[신뢰도 보정] 구간 | 건수 | 평균 신뢰도 | 실제 정확도")
for k, r in cal.iterrows():
    print(f" {k:8s} {int(r['건수']):5d}  {r['평균신뢰도']:.2f}  {r['실제정확도']:.2f}")
ece = float((cal["건수"] * (cal["평균신뢰도"] - cal["실제정확도"]).abs()).sum() / cal["건수"].sum())
print(f"기대 보정 오차(ECE) {ece:.3f}")

# 3) 정비 조치 가이드라인 카드(상위 후보 3개와 신뢰도)
print("\n[진단 카드 예시] 정비 조치 가이드라인")
for i in (int(np.argmin(np.abs(conf - 0.95))), int(np.argmin(np.abs(conf - 0.55)))):
    order = np.argsort(-P[i])[:3]
    print(f" 입력 DTC {test['codes'].iloc[i]} -> " + ", ".join(f"{PNAME[cls[j]]} {P[i, j]:.0%}" for j in order))
    print(f"   조치: {GUIDE[cls[order[0]]]}" + ("" if conf[i] >= 0.7 else "  (신뢰도 낮음: 숙련 정비관 확인 권고)"))

# 4) 월간 고장 건수 예측: 기준(전월값) vs 고도화(릿지 + GBR 앙상블, 소규모 격자 탐색)
D, FE, top = build_monthly(ev, fleet)
a, b = D[D["month"] < 13], D[D["month"] >= 13]
ya, yb = np.log(a["y"]), b["y"].values
naive = np.expm1(b["lag1"].values)
def ens(tr, te, al, dep):
    g = GradientBoostingRegressor(n_estimators=150, max_depth=dep, learning_rate=0.05, random_state=0).fit(tr[FE], np.log(tr["y"]))
    r = make_pipeline(StandardScaler(), Ridge(alpha=al)).fit(tr[FE], np.log(tr["y"]))
    return np.exp(0.5 * g.predict(te[FE]) + 0.5 * r.predict(te[FE]))


inner_tr, inner_va = a[a["month"] < 11], a[a["month"] >= 11]          # 하이퍼파라미터는 학습 구간 안에서만 선택(검증 구간 미사용)
score = {(al, dep): mean_absolute_error(inner_va["y"], ens(inner_tr, inner_va, al, dep)) for al in (1, 3, 10) for dep in (2, 3)}
al, dep = min(score, key=score.get)
adv = ens(a, b, al, dep)
met = lambda p: (mean_absolute_error(yb, p), mean_squared_error(yb, p) ** 0.5, r2_score(yb, p))
m0, m1 = met(naive), met(adv)
print(f"\n[월간 고장 건수 예측] 검증 {len(b)}건(상위 {len(top)}개 부품 x 5개월), 선택 하이퍼파라미터 ridge alpha={al}, GBR depth={dep}")
print(f" 기준(전월값)  MAE {m0[0]:.2f}  RMSE {m0[1]:.2f}  R2 {m0[2]:.3f}")
print(f" 고도화(앙상블) MAE {m1[0]:.2f}  RMSE {m1[1]:.2f}  R2 {m1[2]:.3f}")
imp_mae, imp_rmse = 1 - m1[0] / m0[0], 1 - m1[1] / m0[1]
print(f"개선율 MAE {imp_mae:.1%}, RMSE {imp_rmse:.1%} (목표 20% 이상: {'달성' if min(imp_mae, imp_rmse) >= 0.2 else '미달'}), R2 {m1[2]:.3f} (목표 0.85 이상: {'달성' if m1[2] >= 0.85 else '미달'})")

fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
ax[0].plot([0, 1], [0, 1], "k--"); ax[0].plot(cal["평균신뢰도"], cal["실제정확도"], marker="o"); ax[0].set_title("Confidence calibration")
ax[1].scatter(yb, adv, s=12, label="ensemble"); ax[1].scatter(yb, naive, s=12, label="naive"); ax[1].plot([0, yb.max()], [0, yb.max()], "k--")
ax[1].set_title("Monthly failure count: actual vs predicted"); ax[1].legend()
plt.tight_layout(); plt.show()
