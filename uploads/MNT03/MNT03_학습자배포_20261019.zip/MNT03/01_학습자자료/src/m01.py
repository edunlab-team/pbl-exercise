"""특수차량/작업차량 계열 가상 차량의 전자제어장치(ECU) 고장 진단 코드(DTC) 발생 로그, 정비 이력, 정비 매뉴얼 데이터셋의 스키마·데이터 딕셔너리(피처 20개 이상)와 고장률 분석 업무 프로세스 맵을 정의하고, 가상 데이터로 검증한다."""
import json
import re
import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# 1) 업무 프로세스 맵: DTC 발생부터 고장률 집계·환류까지 (각 단계에서 생기는 데이터)
PROCESS = [("DTC 발생", "차량 ID, 발생 시각, DTC 코드, 가동시간 계기값"), ("로그 수집·정제", "중복 제거, 코드·시각 표기 통일"),
           ("동시 발생 묶음", "같은 정비 건에서 발생한 DTC 세트(정규화)"), ("고장 진단", "추정 고장 부품, 신뢰도"),
           ("정비 조치", "정비 매뉴얼 절차, 수리시간, 교체 부품"), ("정비 이력 연결", "정비 건 ID로 DTC와 실제 고장 부품 연결"),
           ("고장률 집계", "부품별 1000가동시간당 고장 건수"), ("다빈도 품목 식별", "파레토(ABC) 등급, 관리 대상 선정"),
           ("사후검토(AAR)", "오진단 사례, 규칙 조정 이력")]

# 2) 스키마(데이터 딕셔너리): 그룹 / 필드 / 자료형 / 규칙 / 설명
S = {
    "dtc_log": {
        "ev_id": (str, {"pattern": r"^W\d{5}$"}, "정비 건 ID(DTC와 정비 이력을 잇는 키)"),
        "veh_id": (str, {"pattern": r"^V\d{3}$"}, "차량 ID(가상)"),
        "ts": (float, {"min": 0, "max": 13000}, "DTC 발생 시각(모의 시작 후 경과 시간, h)"),
        "code": (str, {"enum": CODES}, "DTC 코드(고유·공유·계통 증상 28종)"),
        "co_count": (int, {"min": 1, "max": 8}, "같은 정비 건에서 동시 발생한 DTC 수"),
    },
    "work_order": {
        "part_id": (str, {"enum": PID}, "실제 고장 부품(정비 이력) - 예측대상 1"),
        "system": (str, {"enum": SYS}, "고장 계통"),
        "repair_h": (float, {"min": 0.1, "max": 24}, "수리 소요시간(h)"),
        "unit_cost": (float, {"min": 0, "max": 50}, "부품 단가지수(가상)"),
        "unplanned": (bool, {}, "비계획·긴급 정비 여부"),
        "month": (int, {"min": 0, "max": 17}, "정비 월(모의 시작 기준)"),
    },
    "vehicle": {
        "age": (float, {"min": 0, "max": 40}, "차령(년)"),
        "op_hours": (float, {"min": 0, "max": 400}, "월 가동시간(h)"),
        "pm_gap": (float, {"min": 0, "max": 500}, "마지막 예방정비 후 경과 가동시간(h)"),
        "terrain": (float, {"min": 0, "max": 1}, "운용 지형 가혹도(0~1)"),
        "load": (float, {"min": 0, "max": 1}, "운용 부하 수준(0~1)"),
        "temp": (float, {"min": -40, "max": 60}, "정비 시점 기온(도)"),
    },
    "manual": {
        "code_ref": (str, {"enum": CODES}, "매뉴얼 기준 DTC 코드"),
        "cand_parts": (list, {}, "코드별 후보 고장 부품 목록"),
        "step_no": (int, {"min": 1, "max": 20}, "정비 조치 절차 단계 번호"),
        "safety_flag": (bool, {}, "안전 주의 항목 포함 여부"),
    },
    "target": {
        "fail_rate": (float, {"min": 0, "max": 100}, "부품별 1000가동시간당 고장률 - 예측대상 2"),
        "confidence": (float, {"min": 0, "max": 1}, "진단 추천 신뢰도 점수 - 예측대상 3"),
    },
}


def check(name, v, typ, rule):
    if not isinstance(v, typ) or (typ in (int, float) and isinstance(v, bool)):
        return [f"{name}: 자료형 오류({type(v).__name__})"]
    e = []
    if "enum" in rule and v not in rule["enum"]:
        e.append(f"{name}: 허용되지 않은 값 '{v}'")
    if "min" in rule and v < rule["min"]:
        e.append(f"{name}: 최소값 {rule['min']} 미만")
    if "max" in rule and v > rule["max"]:
        e.append(f"{name}: 최대값 {rule['max']} 초과")
    if "pattern" in rule and not re.match(rule["pattern"], v):
        e.append(f"{name}: 형식 불일치 '{v}'")
    return e


def validate(rec):
    errs = []
    for g, fields in S.items():
        for k, (typ, rule, _) in fields.items():
            if k not in rec.get(g, {}):
                errs.append(f"{g}.{k}: 필수 필드 누락")
            else:
                errs += check(f"{g}.{k}", rec[g][k], typ, rule)
    return errs


# 3) [교육용가상자료] 생성 데이터에서 20건 추출해 레코드 형태로 만들고 검증
fleet, ev, log = make_data()
f = fleet.set_index("veh")
recs = []
for e in ev.sample(20, random_state=0).itertuples():
    first = log[log["ev_id"] == e.ev_id].iloc[0]
    cs = e.codes
    recs.append({
        "dtc_log": {"ev_id": e.ev_id, "veh_id": e.veh, "ts": float(round(first["ts"], 1)), "code": cs[0], "co_count": len(cs)},
        "work_order": {"part_id": e.part, "system": PSYS[e.part], "repair_h": float(REPH[e.part]), "unit_cost": float(COST[e.part]),
                       "unplanned": bool(len(cs) >= 3), "month": int(e.month)},
        "vehicle": {"age": float(f.loc[e.veh, "age"]), "op_hours": float(round(f.loc[e.veh, "base_h"], 1)), "pm_gap": float(round(f.loc[e.veh, "pm_gap"], 1)),
                    "terrain": float(round(f.loc[e.veh, "terrain"], 2)), "load": float(round(f.loc[e.veh, "load"], 2)), "temp": float(round(e.temp, 1))},
        "manual": {"code_ref": cs[0], "cand_parts": [p for p in PID if cs[0] in (SPEC[p], SHARED.get(p))] or [e.part], "step_no": 1,
                   "safety_flag": PSYS[e.part] in CRIT_SYS},
        "target": {"fail_rate": float(RATE[e.part]), "confidence": 0.8}})
ok = sum(not validate(r) for r in recs)
print(f"가상 데이터 {len(ev)}건(DTC 로그 {len(log)}행) 생성, 표본 {len(recs)}건 중 검증 통과 {ok}건, 오류 {len(recs) - ok}건")
print(f"전체 DTC 로그 코드 허용값 검증: {'통과' if log['code'].isin(CODES).all() else '실패'}")

# 4) 오류 주입 시험
bad = json.loads(json.dumps(recs[0]))
bad["dtc_log"]["code"] = "C999"                  # 정의되지 않은 DTC 코드
bad["dtc_log"]["veh_id"] = "TANK-7"              # ID 형식 오류
bad["vehicle"]["load"] = 1.8                     # 범위 초과
del bad["work_order"]["repair_h"]                # 필수 필드 누락
bad["target"]["confidence"] = "높음"             # 자료형 오류
print("\n[오류 주입 결과]")
for e in validate(bad):
    print(" -", e)

# 5) 프로세스 맵과 데이터 딕셔너리
print("\n[업무 프로세스 맵]")
print(" -> ".join(f"{i}.{p}" for i, (p, _) in enumerate(PROCESS, 1)))
for p, d in PROCESS:
    print(f"   {p:10s}: {d}")
rows = [(g, k, t.__name__, d) for g, fl in S.items() for k, (t, r, d) in fl.items()]
dd = pd.DataFrame(rows, columns=["그룹", "필드", "자료형", "설명"])
print(f"\n[데이터 딕셔너리] 피처 {len(dd)}개 (목표 20개 이상: {'달성' if len(dd) >= 20 else '미달'})")
print(dd.to_string(index=False))
