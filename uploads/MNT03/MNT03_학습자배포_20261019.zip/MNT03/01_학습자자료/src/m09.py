"""AAR(사후검토) 대상 기간의 연관 고장 오진단 사례를 원인별(모호 코드만 입력, 연쇄 고장 코드 오인, 잡음 코드 오인, 기타)로 분류하고, 고장 룰베이스의 코드 유형별 가중치와 사전확률 보정을 AAR 기간 자료로 재튜닝한 뒤 별도 검증 기간에서 효과를 확인한다. 비용 절감액, 재작업 시간 단축률, 헛교체 부품 감소율의 3대 효과 지표와 단계별 도입 로드맵을 산출한다."""
import itertools
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 차량 100대의 18개월 고장 진단 코드(DTC)·정비 이력 생성기 (실제 조직·장비·정비 실적 없음)
# 부품 16종(1000가동시간당 고장률 차등), DTC 28종(부품 고유 코드, 짝 부품 공유 코드, 계통 증상 코드)
# 고장 1건(정비 이력)마다 DTC가 1~5개 동시 발생하고, 연쇄 고장 코드와 일시 잡음 코드가 섞인다.
# ---------------------------------------------------------------------------
PARTS = [  # (ID, 이름, 계통, 1000가동시간당 고장률, 가상 단가지수, 수리시간 h)
    ("P01", "연료분사기", "engine", 12.0, 3.0, 2.0), ("P02", "터보차저", "engine", 9.0, 8.0, 5.0),
    ("P03", "축전지", "electric", 6.5, 4.0, 1.5), ("P04", "발전기", "electric", 4.0, 9.0, 3.0),
    ("P05", "변속기 제어모듈", "drive", 3.0, 12.0, 6.0), ("P06", "냉각수 펌프", "engine", 2.2, 3.5, 3.0),
    ("P07", "유압 펌프", "hydraulic", 1.6, 10.0, 4.0), ("P08", "속도 센서", "drive", 1.2, 2.0, 1.5),
    ("P09", "ECU 커넥터", "electric", 0.9, 2.5, 1.5), ("P10", "연료 필터", "engine", 0.7, 0.8, 0.7),
    ("P11", "제동 밸브", "brake", 0.5, 6.0, 3.0), ("P12", "조향 액추에이터", "drive", 0.4, 9.0, 5.0),
    ("P13", "공기 필터", "engine", 0.3, 0.5, 0.5), ("P14", "통신 인터페이스 모듈", "electric", 0.25, 3.0, 1.5),
    ("P15", "윤활유 압력 센서", "engine", 0.2, 1.0, 1.0), ("P16", "팬 구동 모터", "cooling", 0.15, 2.0, 2.0)]
PID = [p[0] for p in PARTS]
PNAME = {p[0]: p[1] for p in PARTS}; PSYS = {p[0]: p[2] for p in PARTS}; RATE = {p[0]: p[3] for p in PARTS}
COST = {p[0]: p[4] for p in PARTS}; REPH = {p[0]: p[5] for p in PARTS}
PAIRS = [("P01", "P02"), ("P03", "P04"), ("P05", "P08"), ("P06", "P10"), ("P09", "P14"), ("P13", "P15")]
SHARED = {p: f"S{k + 1:02d}" for k, pr in enumerate(PAIRS) for p in pr}     # 짝 부품이 함께 쓰는 모호한 코드
SPEC = {p: f"C{p[1:]}1" for p in PID}                                          # 부품 고유 코드
SYS = ["engine", "electric", "drive", "hydraulic", "brake", "cooling"]
SYMP = {s: f"G{i + 1:02d}" for i, s in enumerate(SYS)}                         # 계통 증상 코드
CODES = sorted(set(SPEC.values()) | set(SHARED.values()) | set(SYMP.values()))
CASCADE = {"P01": [("P10", 0.20)], "P02": [("P06", 0.20)], "P03": [("P04", 0.25)], "P04": [("P09", 0.25)],
           "P05": [("P08", 0.30)], "P06": [("P16", 0.30)], "P09": [("P14", 0.20)], "P12": [("P07", 0.20)]}
CRIT_SYS = {"engine", "drive", "brake"}        # 기동·제동 불능 위험 계통(경보 대상)
MONTHS = 18


def make_fleet(n=100, seed=0):
    rng = np.random.default_rng(seed)
    f = pd.DataFrame({"veh": [f"V{i:03d}" for i in range(n)], "age": rng.integers(1, 26, n).astype(float),
                      "terrain": rng.uniform(0, 1, n), "load": rng.uniform(0, 1, n), "pm_gap": rng.uniform(20, 200, n),
                      "humid": rng.uniform(0, 1, n), "base_h": rng.uniform(55, 125, n)})
    f["mult"] = np.exp(0.045 * (f["age"] - 13) + 0.9 * (f["terrain"] - .5) + 0.8 * (f["load"] - .5)
                       + 0.006 * (f["pm_gap"] - 110) + 0.7 * (f["humid"] - .5))
    return f


def make_data(seed=1, months=MONTHS):
    """반환: fleet(차량 속성), ev(정비 이력 1건=1행: 발생 DTC 목록, 실제 고장 부품), log(DTC 발생 로그, 행=코드 1건)"""
    rng = np.random.default_rng(seed)
    fleet = make_fleet()
    V = len(fleet)
    temp = 12 + 14 * np.sin(2 * np.pi * (np.arange(months) - 3) / 12)            # 월평균 기온(가상)
    hours = fleet["base_h"].values[:, None] * (1 + 0.25 * np.sin(2 * np.pi * np.arange(months) / 12 + 1)) * rng.lognormal(0, .12, (V, months))
    fleet["hours"] = hours.sum(axis=1)                                           # 차량별 18개월 총 가동시간
    fleet.attrs["month_h"] = hours.sum(axis=0)                                   # 월별 전체 가동시간(고장률 분모)
    evs = []
    for p in PID:
        s = np.ones(months)
        if p in ("P03", "P04"): s = np.exp(-0.06 * (temp - 12))                   # 한랭기 전기계통 증가
        if p in ("P06", "P16"): s = np.exp(0.05 * (temp - 12))                    # 혹서기 냉각계통 증가
        cnt = rng.poisson(RATE[p] * hours / 1000 * fleet["mult"].values[:, None] * s[None, :])
        for v, m in zip(*np.nonzero(cnt)):
            for _ in range(cnt[v, m]):
                evs.append((fleet["veh"][v], int(m), m * 720 + rng.uniform(0, 720), p, float(temp[m] + rng.normal(0, 3))))
    ev = pd.DataFrame(evs, columns=["veh", "month", "t", "part", "temp"]).sort_values("t").reset_index(drop=True)
    ev["ev_id"] = [f"W{i:05d}" for i in range(len(ev))]
    rows, codes = [], []
    for e in ev.itertuples():
        c, r = [], rng.random(3)
        if r[0] < 0.6: c.append(SPEC[e.part])
        if e.part in SHARED and r[1] < 0.6: c.append(SHARED[e.part])
        if r[2] < 0.5: c.append(SYMP[PSYS[e.part]])
        if not c: c.append(SHARED.get(e.part, SPEC[e.part]))
        for q, pr in CASCADE.get(e.part, []):
            if rng.random() < pr: c.append(SPEC[q])
        if rng.random() < 0.12: c.append(SPEC[PID[rng.integers(0, 16)]])
        c = list(dict.fromkeys(c))
        rng.shuffle(c)                                                           # 동시 발생 코드의 기록 순서는 임의
        codes.append(c)
        for k, cd in enumerate(c):
            rows.append((e.ev_id, e.veh, e.t + k * 0.1, cd))
    ev["codes"] = codes
    log = pd.DataFrame(rows, columns=["ev_id", "veh", "ts", "code"])
    return fleet, ev, log

# ---------------------------------------------------------------------------
# 공통 분석 조각: 코드 멀티핫 행렬, 차량 맥락 피처, 학습/검증 분할(앞 12개월 학습, 뒤 6개월 검증)
# ---------------------------------------------------------------------------
CIDX = {c: i for i, c in enumerate(CODES)}
SPLIT_M = 12


def multi_hot(ev):
    X = np.zeros((len(ev), len(CODES)))
    for r, cs in enumerate(ev["codes"]):
        for c in cs:
            X[r, CIDX[c]] = 1
    return X


def context(ev, fleet):
    f = fleet.set_index("veh")
    return np.column_stack([ev["veh"].map(f["age"]) / 25, ev["veh"].map(f["pm_gap"]) / 200, ev["veh"].map(f["terrain"]),
                            ev["veh"].map(f["load"]), (ev["temp"] - 12) / 15])


def feats(ev, fleet):
    X = multi_hot(ev)
    n = X.sum(axis=1, keepdims=True) / 3
    return np.hstack([X, n, context(ev, fleet)])


def monthly_counts(ev):
    return ev.groupby(["month", "part"]).size().unstack(fill_value=0).reindex(columns=PID, fill_value=0)


def build_monthly(ev, fleet, top_n=8):
    """부품별 월간 고장 건수 예측용 표: 지연값(lag), 이동평균, 추세, 기대 건수(가동시간 x 설계 고장률), 기온 상호작용, 계절 성분"""
    mc = ev.groupby(["month", "part"]).size().unstack(fill_value=0)
    top = ev["part"].value_counts().index[:top_n]
    mh, tm = fleet.attrs["month_h"], ev.groupby("month")["temp"].mean().values
    rows = []
    for p in top:
        c = mc[p].values.astype(float)
        for m in range(3, MONTHS):
            L = np.log1p(c)
            rows.append({"part": p, "month": m, "y": c[m], "lag1": L[m - 1], "lag2": L[m - 2], "lag3": L[m - 3], "roll3": L[m - 3:m].mean(),
                         "trend": L[m - 1] - L[m - 2], "roll3_std": L[m - 3:m].std(), "log_expected": np.log(mh[m] / 1000 * RATE[p]),
                         "rate_lag1": c[m - 1] / (mh[m - 1] / 1000) / RATE[p], "temp": tm[m] / 10, "cold_elec": max(0, 12 - tm[m]) / 10 * (p in ("P03", "P04")),
                         "heat_cool": max(0, tm[m] - 12) / 10 * (p in ("P06", "P16")), "sin": np.sin(2 * np.pi * m / 12), "cos": np.cos(2 * np.pi * m / 12)})
    D = pd.DataFrame(rows)
    return D, [c for c in D.columns if c not in ("part", "month", "y")], top

fleet, ev, log = make_data()
train, aar, val = ev[ev["month"] < 12], ev[(ev["month"] >= 12) & (ev["month"] < 15)].reset_index(drop=True), ev[ev["month"] >= 15].reset_index(drop=True)

# 1) 룰베이스: 점수(부품) = sum[코드 유형 가중치 x P(부품 | 코드)] + 사전확률 보정. 학습 기간 조건부확률표를 쓴다.
Xtr = multi_hot(train)
Y = pd.get_dummies(train["part"]).reindex(columns=PID, fill_value=0).values.astype(float)
COND = (Xtr.T @ Y) / np.maximum(Xtr.sum(axis=0)[:, None], 1)             # P(부품 | 코드)
PRIOR = np.log(Y.mean(axis=0) + 1e-9)
CTYPE = np.array([0 if c in SPEC.values() else 1 if c in SHARED.values() else 2 for c in CODES])    # 0 고유 / 1 공유 / 2 계통 증상
V1 = {"w": (1.0, 1.0, 1.0), "beta": 0.0}                                  # 기존 룰베이스(모든 코드 동일 가중, 사전확률 미반영)


def predict(ev_, p):
    W = np.array(p["w"])[CTYPE][:, None] * COND
    S = multi_hot(ev_) @ W + p["beta"] * PRIOR[None, :]
    base = np.array(PID)[S.argmax(axis=1)]
    ov = p.get("override", {})                                            # AAR에서 만든 예외 규칙(DTC 조합 -> 부품)이 우선
    return np.array([ov.get(frozenset(c), b) for c, b in zip(ev_["codes"], base)])


def cost(pred, true):
    return sum(REPH[t] if p == t else COST[p] + REPH[p] + 3.0 + REPH[t] for p, t in zip(pred, true))


def err_stats(pred, true):
    wrong = pred != true.values
    return int(wrong.sum()), sum(REPH[p] + 3.0 + REPH[t] for p, t in zip(pred[wrong], true[wrong])), int(wrong.sum())


# 2) AAR: 오진단 원인 분류
pa = predict(aar, V1)
casc = {(p, q) for p, lst in CASCADE.items() for q, _ in lst}
cause = []
for cs, t, q in zip(aar["codes"], aar["part"], pa):
    if t == q: continue
    sp = [c for c in cs if c in SPEC.values()]
    if not sp: cause.append("모호 코드(공유·증상)만 입력")
    elif len(sp) >= 2 and ((t, q) in casc or (q, t) in casc): cause.append("연쇄 고장 코드 오인")
    elif len(sp) >= 2: cause.append("복수 고유 코드 충돌(잡음 포함)")
    else: cause.append("기타(고유 코드 1개, 확률 편향)")
C = pd.Series(cause).value_counts()
print(f"[교육용가상자료] AAR 기간(12~14월) 정비 {len(aar)}건: 기존 룰베이스 오진단 {len(cause)}건 ({len(cause) / len(aar):.1%})")
for k, v in C.items():
    print(f"  {k:24s} {v:4d}건 ({v / len(cause):.0%})")
ex = [(cs, PNAME[t], PNAME[q]) for cs, t, q in zip(aar["codes"], aar["part"], pa) if t != q and sum(c in SPEC.values() for c in cs) >= 2][:1]
print("  사례:", f"입력 DTC {ex[0][0]} -> 오진단 {ex[0][2]}, 실제 {ex[0][1]}" if ex else "-")

# 3) 재튜닝: (가) 코드 유형 가중치·사전확률 격자 탐색, (나) AAR 오진단 조합에서 예외 규칙 추출. 모두 AAR 기간 자료만 쓰고 검증 기간은 건드리지 않는다.
best = None
for w in itertools.product((0.5, 1.0, 1.5, 2.0), repeat=3):
    for beta in (0.0, 0.2, 0.5, 1.0):
        p = {"w": w, "beta": beta}
        c = cost(predict(aar, p), aar["part"])
        if best is None or c < best[0]: best = (c, p)
V2 = dict(best[1])
pa2 = predict(aar, V2)
bad_sets = {frozenset(c) for c, t, q in zip(aar["codes"], aar["part"], pa2) if t != q}
grp = {}
for c, t in zip(aar["codes"], aar["part"]):
    grp.setdefault(frozenset(c), Counter())[t] += 1
V2["override"] = {k: v.most_common(1)[0][0] for k, v in grp.items()
                  if k in bad_sets and sum(v.values()) >= 3 and v.most_common(1)[0][1] / sum(v.values()) >= 0.6}
print(f"\n재튜닝 결과: 코드 유형 가중치(고유·공유·증상) {V1['w']} -> {V2['w']}, 사전확률 보정 {V1['beta']} -> {V2['beta']}, AAR 예외 규칙 {len(V2['override'])}개 추가")
rows = []
for nm, d in (("AAR 기간(튜닝)", aar), ("검증 기간(15~17월)", val)):
    p1, p2 = predict(d, V1), predict(d, V2)
    rows.append((nm, (p1 == d["part"].values).mean(), (p2 == d["part"].values).mean(), cost(p1, d["part"]), cost(p2, d["part"])))
    print(f" {nm:14s} 정확도 {rows[-1][1]:.1%} -> {rows[-1][2]:.1%}, 비용지수 {rows[-1][3]:.0f} -> {rows[-1][4]:.0f}")

# 4) ROI 3대 지표(검증 기간 3개월, 가정 단가 기준 상대값)
p1, p2 = predict(val, V1), predict(val, V2)
n1, h1, _ = err_stats(p1, val["part"]); n2, h2, _ = err_stats(p2, val["part"])
saved = cost(p1, val["part"]) - cost(p2, val["part"])
wasted1 = sum(COST[p] for p, t in zip(p1, val["part"]) if p != t); wasted2 = sum(COST[p] for p, t in zip(p2, val["part"]) if p != t)
print("\n[ROI 3대 정량 효과 지표] (검증 3개월, 가정 단가)")
print(f" 1) 비용 절감: 비용지수 {saved:.0f} 절감 ({saved / cost(p1, val['part']):.1%}), 연환산 약 {saved * 4:.0f}")
print(f" 2) 시간 단축: 오진단 재작업 {h1:.0f}h -> {h2:.0f}h ({1 - h2 / h1:.1%} 단축)")
print(f" 3) 헛교체 부품 비용: {wasted1:.0f} -> {wasted2:.0f} ({1 - wasted2 / wasted1:.1%} 감소), 오진단 {n1}건 -> {n2}건")
print("[도입 로드맵] 단기(1~3월): 가중치 갱신 + 정비관 확인 병행 / 중기(3~12월): AAR 분기 반복·신규 코드 반영 / 장기(1년~): 물자 정보체계 이력 연동")

fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
ax[0].barh([f"cause {i + 1}" for i in range(len(C))][::-1], C.values[::-1]); ax[0].set_title("Misdiagnosis causes (AAR period)")
ax[1].bar(["before", "after"], [rows[1][1], rows[1][2]]); ax[1].set_ylim(0.5, 1); ax[1].set_title("Validation accuracy")
plt.tight_layout(); plt.show()
