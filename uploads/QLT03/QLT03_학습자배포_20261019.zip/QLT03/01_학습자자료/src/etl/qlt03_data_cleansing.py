"""해상도·밝기·표기가 제각각인 장비 외관 사진과 제원 기록, 결함 영역(바운딩 박스) 라벨의 가상 원천 자료에 조명 보정·해상도 표준화·박스 정리를 포함한 정제 규칙 11종을 적용하고, 긴급 점검 사진 같은 물자 예외 데이터는 보존하면서 정합성 검증 통과율과 정제 전후 통계를 확인한다."""
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.impute import KNNImputer

# ---------------------------------------------------------------------------
# [교육용가상자료] 장비 외관 사진 생성기 (실제 장비·조직·위치 사진이 아니라 난수로 그린 64x64 합성 이미지)
# 도장된 금속 표면에 균열(crack)·부식(corrosion)·파손(damage)·누유(leak)를 그리고, 조명 편차와 진흙(mud) 오염을 섞는다.
# 이미지와 함께 장비 관리 기록(제원 요약)과 정답 결함 마스크·손상도·정비 등급을 만든다.
# ---------------------------------------------------------------------------
from scipy import ndimage as ndi

SZ = 64
CLASSES = ["none", "crack", "corrosion", "damage", "leak"]
KO_CLS = {"none": "결함 없음", "crack": "균열", "corrosion": "부식", "damage": "파손", "leak": "누유"}
CLS_W = {"none": 0.0, "crack": 1.4, "corrosion": 1.0, "damage": 1.6, "leak": 0.6}      # 손상도 계산용 결함 유형 가중치
GRADE_NAME = {1: "1단계 정비", 2: "2단계 정비", 3: "3단계 정비"}
YY, XX = np.mgrid[0:SZ, 0:SZ]


def grade_of(idx):
    return np.where(np.asarray(idx) >= 65, 3, np.where(np.asarray(idx) >= 35, 2, 1))


def blob(rng, cy, cx, r, rough=0.35):
    """불규칙한 원형 영역 마스크."""
    noise = ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 3)
    noise = noise / (np.abs(noise).max() + 1e-9)
    return (np.hypot(YY - cy, XX - cx) + rough * r * 2.2 * noise) < r


def draw(rng, cls, sev):
    """결함 유형·심각도 sev(0~1)에 맞는 정답 마스크와 색 정보를 만든다."""
    m = np.zeros((SZ, SZ), bool)
    if cls == "crack":
        y, x, ang = rng.uniform(12, 52), rng.uniform(12, 52), rng.uniform(0, np.pi)
        for _ in range(int(20 + 40 * sev)):
            ang += rng.normal(0, 0.35); y += np.sin(ang) * 1.2; x += np.cos(ang) * 1.2
            if 0 <= int(y) < SZ and 0 <= int(x) < SZ:
                m[int(y), int(x)] = True
        m = ndi.binary_dilation(m, iterations=1 + int(sev > 0.6))
    elif cls == "corrosion":
        for _ in range(int(rng.integers(1, 4))):
            m |= blob(rng, rng.uniform(14, 50), rng.uniform(14, 50), 3 + 9 * sev * rng.uniform(0.6, 1.1))
    elif cls == "damage":
        m = blob(rng, rng.uniform(20, 44), rng.uniform(20, 44), 6 + 12 * sev, 0.3)
    elif cls == "leak":
        x0, y0 = rng.uniform(16, 48), rng.uniform(8, 24)
        w, ln = 2 + 4 * sev, 12 + 26 * sev
        m = (np.abs(XX - x0 - 0.15 * (YY - y0)) < w * (1 - 0.4 * (YY - y0) / ln)) & (YY > y0) & (YY < y0 + ln)
    return m


def make_images(n=600, seed=0, mud=0.0, p_none=0.25, dark=False):
    """가상 외관 사진 n장(+진흙 오염 mud 비율)과 관리 기록·정답. 반환: meta(DataFrame), imgs(n,64,64,3), masks(n,64,64)."""
    rng = np.random.default_rng(seed)
    imgs, masks, rows = np.zeros((n, SZ, SZ, 3), np.float32), np.zeros((n, SZ, SZ), bool), []
    for i in range(n):
        cls = "none" if rng.random() < p_none else str(rng.choice(CLASSES[1:], p=[0.25, 0.3, 0.25, 0.2]))
        sev = 0.0 if cls == "none" else float(rng.beta(1.6, 2.0))
        base = np.array([0.42, 0.46, 0.40]) * (1 + 0.5 * ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 8)[..., None] * 3)
        img = base + rng.normal(0, 0.012, (SZ, SZ, 3))
        m = draw(rng, cls, sev)
        a = ndi.gaussian_filter(m.astype(float), 0.8)[..., None]                        # 경계를 부드럽게 섞는다
        if cls == "crack":
            col = img * rng.uniform(0.2, 0.45)
        elif cls == "corrosion":
            col = np.array([0.55, 0.30, 0.12]) * rng.uniform(0.75, 1.15) * (0.85 + 0.3 * rng.random((SZ, SZ, 1)))
        elif cls == "damage":
            col = np.ones_like(img) * np.array([0.34, 0.34, 0.36]) * (1.0 - 0.45 * sev) * rng.uniform(0.75, 1.0)
            rim = m & ~ndi.binary_erosion(m, iterations=2)
            a = np.maximum(a, 0.0); img = np.where(rim[..., None], 0.7, img)
        elif cls == "leak":
            col = np.ones_like(img) * np.array([0.10, 0.09, 0.08]) * rng.uniform(0.8, 2.6)
        else:
            col = img
        img = img * (1 - a) + col * a
        if rng.random() < 0.35:                                   # 무해한 얼룩(결함 아님): 옅은 갈색 번짐
            st = blob(rng, rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(6, 14), 0.5)
            al = ndi.gaussian_filter(st.astype(float), 2.5)[..., None] * rng.uniform(0.15, 0.4)
            img = img * (1 - al) + np.array([0.50, 0.40, 0.30]) * al
        if rng.random() < 0.3:                                    # 무해한 긴 스크래치(밝은 선)
            y0, x0, ang = rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(0, np.pi)
            for t in np.linspace(0, 25, 40):
                yy, xx = int(y0 + t * np.sin(ang)), int(x0 + t * np.cos(ang))
                if 0 <= yy < SZ and 0 <= xx < SZ:
                    img[yy, xx] = np.clip(img[yy, xx] * 1.5, 0, 1)
        if mud > 0:                                           # 진흙 오염: 결함 위를 덮을 수 있다(정답 마스크는 그대로)
            mm = np.zeros((SZ, SZ), bool)
            while mm.mean() < mud:
                mm |= blob(rng, rng.uniform(0, SZ), rng.uniform(0, SZ), rng.uniform(5, 11), 0.5)
            img[mm] = np.array([0.38, 0.30, 0.22]) * (0.85 + 0.3 * rng.random((mm.sum(), 1)))
        gain = rng.uniform(0.3, 0.55) if dark else rng.uniform(0.5, 1.15)
        ang = rng.uniform(0, 2 * np.pi)
        light = gain * (1 + 0.3 * (np.cos(ang) * (XX - 32) + np.sin(ang) * (YY - 32)) / 32)
        imgs[i] = np.clip(img * light[..., None] + rng.normal(0, 0.025, (SZ, SZ, 3)), 0, 1)
        masks[i] = m
        area = float(m.mean())
        depth = {"none": 0.0, "crack": 0.3 + 3.0 * sev, "corrosion": 0.1 + 1.5 * sev, "damage": 1.0 + 8.0 * sev, "leak": 0.0}[cls] * rng.lognormal(0, 0.1)
        idx = float(np.clip(100 * (1 - np.exp(-(CLS_W[cls] * area * 9 + 0.05 * depth))) + rng.normal(0, 1.5), 0, 100))
        rows.append({"img_id": f"IMG{seed:02d}{i:04d}", "cls": cls, "sev": sev, "area_frac": area, "depth_mm": depth, "damage_idx": idx,
                     "grade": int(grade_of(idx)), "gain": gain, "mud": mud})
    meta = pd.DataFrame(rows)
    # 장비 관리 기록(제원 요약): 사진 판정과 대조할 값
    age = rng.integers(1, 25, n)
    meta["day"] = np.sort(rng.integers(0, 90, n))
    meta["equip_type"] = rng.choice(["vehicle", "generator", "comm", "trailer"], n, p=[0.4, 0.2, 0.2, 0.2])
    meta["mfg_year"] = 2026 - age
    meta["op_hours"] = np.clip(rng.normal(180 * age, 400, n) + 8 * meta["damage_idx"], 10, 20000)
    meta["env"] = rng.choice(["coastal", "inland"], n, p=[0.3, 0.7])
    reg = np.clip(meta["grade"] + rng.choice([-1, 0, 0, 0, 0, 0, 1, 2], n), 1, 3)           # 장비 관리 기록상 직전 정비 등급
    meta["reg_grade"] = reg
    meta["emergency"] = rng.random(n) < 0.04                                               # 긴급 점검 요청(화질 불량이어도 보존)
    return meta, imgs, masks

# ---- 전처리(조명 보정·표준화)와 결함 후보 분할, 특징 추출 (cv2 대신 numpy·scipy 사용) ----
def correct(img):
    """조명 보정: 밝기에 평면(조명 기울기)을 적합해 나눈다. 어두운 결함 화소는 제외하고 두 번 반복 적합한다. 반환: 보정 밝기(정상 면 약 1), 색 비율."""
    g = img.mean(axis=2)
    A = np.c_[np.ones(SZ * SZ), XX.ravel() / SZ, YY.ravel() / SZ]
    keep = np.ones(SZ * SZ, bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(A[keep], g.ravel()[keep], rcond=None)
        plane = (A @ coef).reshape(SZ, SZ)
        keep = (np.abs(g - plane) < 0.08 * np.maximum(plane, 1e-3)).ravel()
        if keep.sum() < 200:
            keep[:] = True
    c = g / np.maximum(plane, 1e-3)
    chroma = img[..., 0] / (img.sum(axis=2) + 1e-6)
    return c, chroma


SEGP = {"dark": 0.7, "rust": 0.5, "rim": 1.45}            # 분할 임계값(어두움 보정 밝기, 붉은 비율, 밝은 테두리): 재보정 대상


def segment(img):
    """결함 후보 마스크: 어두운 영역(균열·누유·파손) + 붉은 갈색 영역(부식) + 밝은 테두리(파손)."""
    c, chroma = correct(img)
    dark = c < SEGP["dark"]
    rust = (chroma > SEGP["rust"]) & (c > 0.45)
    rim = c > SEGP["rim"]
    m = dark | rust | ndi.binary_dilation(rim, iterations=1) & ndi.binary_dilation(dark, iterations=3)
    m = ndi.binary_opening(m, structure=np.ones((2, 2))) if m.sum() > 12 else m
    return m, c, chroma, dark, rust, rim


def extract(img):
    """분할 결과와 색·모양에서 24개 특징을 만든다."""
    m, c, chroma, dark, rust, rim = segment(img)
    lab, n = ndi.label(m)
    area = float(m.sum())
    if n:
        sizes = ndi.sum(m, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        sl = ndi.find_objects(lab)[k - 1]
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        big = float(sizes.max())
        elong, fill = max(h, w) / max(min(h, w), 1), big / (h * w)
    else:
        big, elong, fill = 0.0, 1.0, 0.0
    gy, gx = np.gradient(c)
    mag = np.hypot(gx, gy)
    inside = m.sum() > 0
    return {"area_px": area, "area_frac": area / SZ ** 2, "n_comp": float(n), "big_px": big, "elong": elong, "fill": fill,
            "dark_frac": float(dark.mean()), "rust_frac": float(rust.mean()), "rim_frac": float(rim.mean()),
            "c_mean": float(c.mean()), "c_std": float(c.std()), "c_min": float(c.min()), "edge_mean": float(mag.mean()), "edge_p95": float(np.quantile(mag, 0.95)),
            "chroma_mean": float(chroma.mean()), "chroma_max": float(chroma.max()),
            "in_dark": float(c[m].mean()) if inside else 1.0, "in_chroma": float(chroma[m].mean()) if inside else float(chroma.mean()),
            "ring_contrast": float(c[ndi.binary_dilation(m, iterations=3) & ~m].mean() - c[m].mean()) if inside and (~m).any() else 0.0,
            "thin": float(1 - fill), "gain": float(img.mean()), "sat": float((img.max(axis=2) - img.min(axis=2)).mean()),
            "cy": float(ndi.center_of_mass(m)[0] / SZ) if inside else 0.5, "cx": float(ndi.center_of_mass(m)[1] / SZ) if inside else 0.5}


def feature_table(imgs):
    return pd.DataFrame([extract(im) for im in imgs])

rng = np.random.default_rng(2)
meta, imgs, masks = make_images(150, seed=2)
n0 = len(meta)
applied = []


def rule(name, n):
    applied.append((name, int(n)))


def true_box(m):
    ys, xs = np.where(m)
    return (int(xs.min()), int(ys.min()), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)) if len(xs) else None


# ---------------- 1) 원천 자료 만들기(일부러 넣은 오류) ----------------
raw_imgs, rows = [], []
sizes = rng.choice([32, 64, 128], n0, p=[0.2, 0.55, 0.25])
dark_set = set(rng.choice(n0, 35, replace=False))
emerg = set(rng.choice(n0, 6, replace=False))
for i in range(n0):
    im = imgs[i]
    if sizes[i] != 64:
        im = np.clip(ndi.zoom(im, (sizes[i] / 64, sizes[i] / 64, 1), order=1), 0, 1)
    if i in dark_set or i in emerg:
        im = im * 0.45                                                            # 저조도 촬영
    raw_imgs.append(im.astype(np.float32))
    tb = true_box(masks[i]); k = sizes[i] / 64
    box = None if tb is None else [tb[0] * k, tb[1] * k, tb[2] * k, tb[3] * k]
    fmt = "xywh"
    if box is not None and rng.random() < 0.4:                                    # 일부는 xyxy 형식으로 기록
        box, fmt = [box[0], box[1], box[0] + box[2], box[1] + box[3]], "xyxy"
    rows.append({"img_id": f"IMG{i:06d}", "shot": f"2026-{rng.integers(1, 10):02d}-{rng.integers(1, 28):02d}", "equip_id": f"VX-{1000 + i:04d}-{2000 + i:04d}",
                 "mfg_year": int(meta.loc[i, "mfg_year"]), "op_hours": float(meta.loc[i, "op_hours"]), "hours_unit": "h", "reg_grade": float(meta.loc[i, "reg_grade"]),
                 "w": int(sizes[i]), "box": box, "box_fmt": fmt, "emergency": i in emerg})
raw = pd.DataFrame(rows)
idx = rng.choice(n0, 60, replace=False)
a, b, c, d, e, f, g, h = idx[:8], idx[8:16], idx[16:24], idx[24:32], idx[32:40], idx[40:46], idx[46:52], idx[52:60]
raw.loc[a, "img_id"] = raw.loc[a, "img_id"].str.replace("IMG", "img-")                     # 사진 ID 표기 불일치
raw.loc[b, "shot"] = [x.replace("-", "") for x in raw.loc[b, "shot"]]                      # 촬영일 형식 혼재
raw.loc[c, "op_hours"] = raw.loc[c, "op_hours"] / 24; raw.loc[c, "hours_unit"] = "day"      # 가동시간 단위 혼재
raw.loc[d, "mfg_year"] = rng.choice([1900, 2085], len(d))                                   # 불가능한 제조연도
raw.loc[e, ["mfg_year", "op_hours", "reg_grade"]] = np.nan                                  # 제원 결측
for i in f:                                                                                 # 박스가 사진 밖으로 나감
    if raw.at[i, "box"] is not None and raw.at[i, "box_fmt"] == "xywh":
        raw.at[i, "box"] = [raw.at[i, "w"] - 2, raw.at[i, "box"][1], raw.at[i, "box"][2] + 6, raw.at[i, "box"][3]]
for i in g:                                                                                 # 폭 0 박스
    if raw.at[i, "box"] is not None and raw.at[i, "box_fmt"] == "xywh":
        raw.at[i, "box"] = [raw.at[i, "box"][0], raw.at[i, "box"][1], 0, 0]
dup_rows = raw.sample(8, random_state=1)
raw = pd.concat([raw, dup_rows], ignore_index=True)
raw_imgs += [raw_imgs[int(r["img_id"][-6:])] for _, r in dup_rows.iterrows()]               # 중복 사진
print(f"원천 사진 {len(raw)}장 (중복 8장, 오류 주입 {len(idx)}건, 저조도 {len(dark_set | emerg)}장, 긴급 점검 {len(emerg)}장 포함)")

# ---------------- 2) 정제 규칙 11종 ----------------
df, ims = raw.copy(), list(raw_imgs)
dup = df.duplicated(["img_id", "equip_id", "shot"]); rule("R1 중복 사진 제거", dup.sum())
keep = (~dup).values; df = df[keep].reset_index(drop=True); ims = [im for im, k in zip(ims, keep) if k]
bad_id = ~df["img_id"].str.match(r"^IMG\d{6}$"); df["img_id"] = "IMG" + df["img_id"].str.extract(r"(\d{6})")[0]; rule("R2 사진 ID 표기 통일", bad_id.sum())
t1 = pd.to_datetime(df["shot"], format="%Y-%m-%d", errors="coerce"); t2 = pd.to_datetime(df["shot"], format="%Y%m%d", errors="coerce")
rule("R3 촬영일 형식 통일", t1.isna().sum()); df["shot"] = t1.fillna(t2)
day = df["hours_unit"] == "day"; df.loc[day, "op_hours"] *= 24; df["hours_unit"] = "h"; rule("R4 가동시간 단위 통일(일 -> 시간)", day.sum())
bad = ~df["mfg_year"].between(1990, 2026) & df["mfg_year"].notna(); df.loc[bad, "mfg_year"] = np.nan; rule("R5 불가능 제조연도 결측 처리", bad.sum())
nres = sum(im.shape[0] != 64 for im in ims)
ims = [np.clip(ndi.zoom(im, (64 / im.shape[0], 64 / im.shape[1], 1), order=1), 0, 1) if im.shape[0] != 64 else im for im in ims]
rule("R6 해상도 표준화(32/128 -> 64px)", nres)
before_b = np.array([im.mean() for im in ims])
fixed = []
for im in ims:
    cc, _ = correct(im)                                       # 보정 밝기 = 밝기 / 조명 평면
    plane = im.mean(axis=2) / np.maximum(cc, 1e-6)
    fixed.append(np.clip(im * 0.45 / np.maximum(plane, 1e-3)[..., None], 0, 1))   # 조명 기울기를 펴고 정상 면 밝기를 0.45로 맞춘다
ims = fixed; rule("R7 조명 보정·정규화(평균 밝기 0.3 미만 사진 수)", (before_b < 0.3).sum())
bx = []
nx = 0
for (_, r) in df.iterrows():
    if r["box"] is None:
        bx.append(None); continue
    x, y, w_, h_ = r["box"]
    if r["box_fmt"] == "xyxy":
        w_, h_ = w_ - x, h_ - y; nx += 1
    k = 64 / r["w"]
    bx.append([x * k, y * k, w_ * k, h_ * k])
rule("R8 박스 형식 통일(xyxy -> xywh, 64px 좌표)", nx)
clip_n, zero_n, boxes, manual = 0, 0, [], []
for i, b_ in enumerate(bx):
    if b_ is None:
        boxes.append(None); continue
    x, y, w_, h_ = b_
    x2, y2 = min(x + w_, 64), min(y + h_, 64)
    if x2 > 64 or x + w_ > 64.5 or y + h_ > 64.5:
        clip_n += 1
    if x2 - x < 1 or y2 - y < 1:
        zero_n += 1; manual.append(df.loc[i, "img_id"]); boxes.append(None); continue
    boxes.append([int(round(x)), int(round(y)), int(round(x2 - x)), int(round(y2 - y))])
rule("R9 박스 좌표 클리핑·무효 박스 수동 확인 분리", clip_n + zero_n)
miss = df[["mfg_year", "op_hours", "reg_grade"]].isna().sum().sum()
df[["mfg_year", "op_hours", "reg_grade"]] = KNNImputer(n_neighbors=5).fit_transform(df[["mfg_year", "op_hours", "reg_grade", "w"]])[:, :3]
df["mfg_year"] = df["mfg_year"].round().astype(int); df["reg_grade"] = df["reg_grade"].round().astype(int); rule("R10 제원 결측 KNN 보정", miss)
df["quality_flag"] = np.array([im.std() < 0.03 for im in ims]) & ~df["emergency"]
rule("R11 긴급 점검 사진 보존·일반 저화질 표시", int(df["emergency"].sum()))

# ---------------- 3) 정합성 검증 ----------------
after_b = np.array([im.mean() for im in ims])
tb = {r["img_id"]: true_box(masks[int(r["img_id"][-6:])]) for _, r in df.iterrows()}
ious = []
for (_, r), bb in zip(df.iterrows(), boxes):
    t = tb[r["img_id"]]
    if bb is not None and t is not None:
        ix = max(0, min(bb[0] + bb[2], t[0] + t[2]) - max(bb[0], t[0])); iy = max(0, min(bb[1] + bb[3], t[1] + t[3]) - max(bb[1], t[1]))
        ious.append(ix * iy / (bb[2] * bb[3] + t[2] * t[3] - ix * iy))
chk = {"중복 사진 0장": not df["img_id"].duplicated().any(), "사진 ID 형식": df["img_id"].str.match(r"^IMG\d{6}$").all(), "촬영일 변환": df["shot"].notna().all(),
       "가동시간 단위 h": (df["hours_unit"] == "h").all(), "제조연도 1990~2026": df["mfg_year"].between(1990, 2026).all(),
       "모든 사진 64x64x3": all(im.shape == (64, 64, 3) for im in ims), "밝기 편차 감소": after_b.std() < before_b.std() / 2,
       "박스가 사진 안": all(b_ is None or (b_[0] + b_[2] <= 64 and b_[1] + b_[3] <= 64) for b_ in boxes), "박스 면적 양수": all(b_ is None or (b_[2] > 0 and b_[3] > 0) for b_ in boxes),
       "제원 결측 0건": df[["mfg_year", "op_hours", "reg_grade"]].notna().all().all(), f"긴급 점검 {int(df['emergency'].sum())}장 보존": int(df["emergency"].sum()) == len(emerg),
       "정제 박스와 정답 박스 평균 IoU 0.9 이상": float(np.mean(ious)) >= 0.9}
rate = np.mean(list(chk.values()))
print("\n[적용 규칙과 처리 건수]")
for nme, n in applied:
    print(f" {nme:44s} {n:4d}건")
print(f"\n정합성 검증 {sum(chk.values())}/{len(chk)} 통과, 통과율 {rate:.0%} (목표 100%: {'달성' if rate == 1 else '미달'}), 규칙 {len(applied)}종 (목표 10종 이상: {'달성' if len(applied) >= 10 else '미달'})")
for k, v in chk.items():
    if not v:
        print(" 실패:", k, "(IoU %.2f)" % np.mean(ious))
print(f"정제 후 사진 {len(df)}장, 박스 수동 확인 {len(manual)}장, 긴급 점검 {int(df['emergency'].sum())}장 유지, 정제 박스 평균 IoU {np.mean(ious):.2f}")
cmp = pd.DataFrame({"정제 전": [before_b.mean(), before_b.std(), raw["op_hours"].mean(), raw["mfg_year"].min(), raw["mfg_year"].max()],
                    "정제 후": [after_b.mean(), after_b.std(), df["op_hours"].mean(), df["mfg_year"].min(), df["mfg_year"].max()]},
                   index=["평균 밝기", "밝기 표준편차", "평균 가동시간(h)", "최소 제조연도", "최대 제조연도"]).round(3)
print("\n[정제 전후 통계]"); print(cmp.to_string())

fig, ax = plt.subplots(1, 3, figsize=(12, 3.5))
ax[0].hist(before_b, bins=25, alpha=0.6, label="raw"); ax[0].hist(after_b, bins=25, alpha=0.6, label="normalized"); ax[0].set_title("Mean brightness"); ax[0].legend()
j = int(np.argmin(before_b))
ax[1].imshow(raw_imgs[j][..., :] / max(raw_imgs[j].max(), 1e-3)); ax[1].set_title("dark photo (raw, stretched)"); ax[1].axis("off")
ax[2].imshow(ims[j]); ax[2].set_title("after normalization"); ax[2].axis("off")
plt.tight_layout(); plt.show()
