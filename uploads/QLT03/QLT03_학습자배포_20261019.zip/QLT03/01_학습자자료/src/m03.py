"""밝기 히스토그램과 평균 색만 쓰는 외관 결함 유무 1차 판별 Baseline 비전 모델(로지스틱 회귀)을 구현해 성능과 한계(작은 균열·조명 의존)를 확인하고, 탐색적 분석(EDA) 차트 8종·상관분석(p-value)·정비 공수 파레토(ABC)·제원 기록과의 불일치 분석으로 핵심 관리 대상을 찾는다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

# ---------------------------------------------------------------------------
# [교육용가상자료] 장비 외관 사진 생성기 (실제 장비·조직·위치 사진이 아니라 난수로 그린 64x64 합성 이미지)
# 도장된 금속 표면에 균열(crack)·부식(corrosion)·파손(damage)·누유(leak)를 그리고, 조명 편차와 진흙(mud) 오염을 섞는다.
# 이미지와 함께 장비 관리 기록(제원 요약)과 정답 결함 마스크·손상도·정비 등급을 만든다.
# ---------------------------------------------------------------------------
from scipy import ndimage as ndi

SZ = 64
CLASSES = ["none", "crack", "corrosion", "damage", "leak"]
KO_CLS = {"none": "결함 없음", "crack": "균열", "corrosion": "부식", "damage": "파손", "leak": "누유"}
CLS_W = {"none": 0.0, "crack": 1.4, "corrosion": 1.0, "damage": 1.6, "leak": 0.6}      # 손상도 계산용 결함 유형 가중치
GRADE_NAME = {1: "1단계 정비", 2: "2단계 정비", 3: "3단계 정비"}
YY, XX = np.mgrid[0:SZ, 0:SZ]


def grade_of(idx):
    return np.where(np.asarray(idx) >= 65, 3, np.where(np.asarray(idx) >= 35, 2, 1))


def blob(rng, cy, cx, r, rough=0.35):
    """불규칙한 원형 영역 마스크."""
    noise = ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 3)
    noise = noise / (np.abs(noise).max() + 1e-9)
    return (np.hypot(YY - cy, XX - cx) + rough * r * 2.2 * noise) < r


def draw(rng, cls, sev):
    """결함 유형·심각도 sev(0~1)에 맞는 정답 마스크와 색 정보를 만든다."""
    m = np.zeros((SZ, SZ), bool)
    if cls == "crack":
        y, x, ang = rng.uniform(12, 52), rng.uniform(12, 52), rng.uniform(0, np.pi)
        for _ in range(int(20 + 40 * sev)):
            ang += rng.normal(0, 0.35); y += np.sin(ang) * 1.2; x += np.cos(ang) * 1.2
            if 0 <= int(y) < SZ and 0 <= int(x) < SZ:
                m[int(y), int(x)] = True
        m = ndi.binary_dilation(m, iterations=1 + int(sev > 0.6))
    elif cls == "corrosion":
        for _ in range(int(rng.integers(1, 4))):
            m |= blob(rng, rng.uniform(14, 50), rng.uniform(14, 50), 3 + 9 * sev * rng.uniform(0.6, 1.1))
    elif cls == "damage":
        m = blob(rng, rng.uniform(20, 44), rng.uniform(20, 44), 6 + 12 * sev, 0.3)
    elif cls == "leak":
        x0, y0 = rng.uniform(16, 48), rng.uniform(8, 24)
        w, ln = 2 + 4 * sev, 12 + 26 * sev
        m = (np.abs(XX - x0 - 0.15 * (YY - y0)) < w * (1 - 0.4 * (YY - y0) / ln)) & (YY > y0) & (YY < y0 + ln)
    return m


def make_images(n=600, seed=0, mud=0.0, p_none=0.25, dark=False):
    """가상 외관 사진 n장(+진흙 오염 mud 비율)과 관리 기록·정답. 반환: meta(DataFrame), imgs(n,64,64,3), masks(n,64,64)."""
    rng = np.random.default_rng(seed)
    imgs, masks, rows = np.zeros((n, SZ, SZ, 3), np.float32), np.zeros((n, SZ, SZ), bool), []
    for i in range(n):
        cls = "none" if rng.random() < p_none else str(rng.choice(CLASSES[1:], p=[0.25, 0.3, 0.25, 0.2]))
        sev = 0.0 if cls == "none" else float(rng.beta(1.6, 2.0))
        base = np.array([0.42, 0.46, 0.40]) * (1 + 0.5 * ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 8)[..., None] * 3)
        img = base + rng.normal(0, 0.012, (SZ, SZ, 3))
        m = draw(rng, cls, sev)
        a = ndi.gaussian_filter(m.astype(float), 0.8)[..., None]                        # 경계를 부드럽게 섞는다
        if cls == "crack":
            col = img * rng.uniform(0.2, 0.45)
        elif cls == "corrosion":
            col = np.array([0.55, 0.30, 0.12]) * rng.uniform(0.75, 1.15) * (0.85 + 0.3 * rng.random((SZ, SZ, 1)))
        elif cls == "damage":
            col = np.ones_like(img) * np.array([0.34, 0.34, 0.36]) * (1.0 - 0.45 * sev) * rng.uniform(0.75, 1.0)
            rim = m & ~ndi.binary_erosion(m, iterations=2)
            a = np.maximum(a, 0.0); img = np.where(rim[..., None], 0.7, img)
        elif cls == "leak":
            col = np.ones_like(img) * np.array([0.10, 0.09, 0.08]) * rng.uniform(0.8, 2.6)
        else:
            col = img
        img = img * (1 - a) + col * a
        if rng.random() < 0.35:                                   # 무해한 얼룩(결함 아님): 옅은 갈색 번짐
            st = blob(rng, rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(6, 14), 0.5)
            al = ndi.gaussian_filter(st.astype(float), 2.5)[..., None] * rng.uniform(0.15, 0.4)
            img = img * (1 - al) + np.array([0.50, 0.40, 0.30]) * al
        if rng.random() < 0.3:                                    # 무해한 긴 스크래치(밝은 선)
            y0, x0, ang = rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(0, np.pi)
            for t in np.linspace(0, 25, 40):
                yy, xx = int(y0 + t * np.sin(ang)), int(x0 + t * np.cos(ang))
                if 0 <= yy < SZ and 0 <= xx < SZ:
                    img[yy, xx] = np.clip(img[yy, xx] * 1.5, 0, 1)
        if mud > 0:                                           # 진흙 오염: 결함 위를 덮을 수 있다(정답 마스크는 그대로)
            mm = np.zeros((SZ, SZ), bool)
            while mm.mean() < mud:
                mm |= blob(rng, rng.uniform(0, SZ), rng.uniform(0, SZ), rng.uniform(5, 11), 0.5)
            img[mm] = np.array([0.38, 0.30, 0.22]) * (0.85 + 0.3 * rng.random((mm.sum(), 1)))
        gain = rng.uniform(0.3, 0.55) if dark else rng.uniform(0.5, 1.15)
        ang = rng.uniform(0, 2 * np.pi)
        light = gain * (1 + 0.3 * (np.cos(ang) * (XX - 32) + np.sin(ang) * (YY - 32)) / 32)
        imgs[i] = np.clip(img * light[..., None] + rng.normal(0, 0.025, (SZ, SZ, 3)), 0, 1)
        masks[i] = m
        area = float(m.mean())
        depth = {"none": 0.0, "crack": 0.3 + 3.0 * sev, "corrosion": 0.1 + 1.5 * sev, "damage": 1.0 + 8.0 * sev, "leak": 0.0}[cls] * rng.lognormal(0, 0.1)
        idx = float(np.clip(100 * (1 - np.exp(-(CLS_W[cls] * area * 9 + 0.05 * depth))) + rng.normal(0, 1.5), 0, 100))
        rows.append({"img_id": f"IMG{seed:02d}{i:04d}", "cls": cls, "sev": sev, "area_frac": area, "depth_mm": depth, "damage_idx": idx,
                     "grade": int(grade_of(idx)), "gain": gain, "mud": mud})
    meta = pd.DataFrame(rows)
    # 장비 관리 기록(제원 요약): 사진 판정과 대조할 값
    age = rng.integers(1, 25, n)
    meta["day"] = np.sort(rng.integers(0, 90, n))
    meta["equip_type"] = rng.choice(["vehicle", "generator", "comm", "trailer"], n, p=[0.4, 0.2, 0.2, 0.2])
    meta["mfg_year"] = 2026 - age
    meta["op_hours"] = np.clip(rng.normal(180 * age, 400, n) + 8 * meta["damage_idx"], 10, 20000)
    meta["env"] = rng.choice(["coastal", "inland"], n, p=[0.3, 0.7])
    reg = np.clip(meta["grade"] + rng.choice([-1, 0, 0, 0, 0, 0, 1, 2], n), 1, 3)           # 장비 관리 기록상 직전 정비 등급
    meta["reg_grade"] = reg
    meta["emergency"] = rng.random(n) < 0.04                                               # 긴급 점검 요청(화질 불량이어도 보존)
    return meta, imgs, masks

# ---- 전처리(조명 보정·표준화)와 결함 후보 분할, 특징 추출 (cv2 대신 numpy·scipy 사용) ----
def correct(img):
    """조명 보정: 밝기에 평면(조명 기울기)을 적합해 나눈다. 어두운 결함 화소는 제외하고 두 번 반복 적합한다. 반환: 보정 밝기(정상 면 약 1), 색 비율."""
    g = img.mean(axis=2)
    A = np.c_[np.ones(SZ * SZ), XX.ravel() / SZ, YY.ravel() / SZ]
    keep = np.ones(SZ * SZ, bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(A[keep], g.ravel()[keep], rcond=None)
        plane = (A @ coef).reshape(SZ, SZ)
        keep = (np.abs(g - plane) < 0.08 * np.maximum(plane, 1e-3)).ravel()
        if keep.sum() < 200:
            keep[:] = True
    c = g / np.maximum(plane, 1e-3)
    chroma = img[..., 0] / (img.sum(axis=2) + 1e-6)
    return c, chroma


SEGP = {"dark": 0.7, "rust": 0.5, "rim": 1.45}            # 분할 임계값(어두움 보정 밝기, 붉은 비율, 밝은 테두리): 재보정 대상


def segment(img):
    """결함 후보 마스크: 어두운 영역(균열·누유·파손) + 붉은 갈색 영역(부식) + 밝은 테두리(파손)."""
    c, chroma = correct(img)
    dark = c < SEGP["dark"]
    rust = (chroma > SEGP["rust"]) & (c > 0.45)
    rim = c > SEGP["rim"]
    m = dark | rust | ndi.binary_dilation(rim, iterations=1) & ndi.binary_dilation(dark, iterations=3)
    m = ndi.binary_opening(m, structure=np.ones((2, 2))) if m.sum() > 12 else m
    return m, c, chroma, dark, rust, rim


def extract(img):
    """분할 결과와 색·모양에서 24개 특징을 만든다."""
    m, c, chroma, dark, rust, rim = segment(img)
    lab, n = ndi.label(m)
    area = float(m.sum())
    if n:
        sizes = ndi.sum(m, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        sl = ndi.find_objects(lab)[k - 1]
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        big = float(sizes.max())
        elong, fill = max(h, w) / max(min(h, w), 1), big / (h * w)
    else:
        big, elong, fill = 0.0, 1.0, 0.0
    gy, gx = np.gradient(c)
    mag = np.hypot(gx, gy)
    inside = m.sum() > 0
    return {"area_px": area, "area_frac": area / SZ ** 2, "n_comp": float(n), "big_px": big, "elong": elong, "fill": fill,
            "dark_frac": float(dark.mean()), "rust_frac": float(rust.mean()), "rim_frac": float(rim.mean()),
            "c_mean": float(c.mean()), "c_std": float(c.std()), "c_min": float(c.min()), "edge_mean": float(mag.mean()), "edge_p95": float(np.quantile(mag, 0.95)),
            "chroma_mean": float(chroma.mean()), "chroma_max": float(chroma.max()),
            "in_dark": float(c[m].mean()) if inside else 1.0, "in_chroma": float(chroma[m].mean()) if inside else float(chroma.mean()),
            "ring_contrast": float(c[ndi.binary_dilation(m, iterations=3) & ~m].mean() - c[m].mean()) if inside and (~m).any() else 0.0,
            "thin": float(1 - fill), "gain": float(img.mean()), "sat": float((img.max(axis=2) - img.min(axis=2)).mean()),
            "cy": float(ndi.center_of_mass(m)[0] / SZ) if inside else 0.5, "cx": float(ndi.center_of_mass(m)[1] / SZ) if inside else 0.5}


def feature_table(imgs):
    return pd.DataFrame([extract(im) for im in imgs])

mtr, itr, _ = make_images(400, seed=1)
mte, ite, kte = make_images(300, seed=2)


def hist_feat(imgs):
    """Baseline 특징: 밝기 히스토그램 16칸 + 채널 평균 3 + 밝기 표준편차 1."""
    out = []
    for im in imgs:
        g = im.mean(axis=2)
        h, _ = np.histogram(g / max(g.max(), 1e-3), bins=16, range=(0, 1))
        out.append(np.r_[h / g.size, im.mean(axis=(0, 1)) / max(g.mean(), 1e-3), g.std() / max(g.mean(), 1e-3)])
    return np.array(out)


Htr, Hte = hist_feat(itr), hist_feat(ite)
ytr, yte = (mtr["cls"] != "none").values, (mte["cls"] != "none").values
base = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, C=0.5)).fit(Htr, ytr)
pr = base.predict(Hte)
print(f"[Baseline 결과] 학습 {len(mtr)}장 / 평가 {len(mte)}장, 결함 사진 {yte.mean():.1%}")
print(f"정확도 {accuracy_score(yte, pr):.1%}, 정밀도 {precision_score(yte, pr):.1%}, 재현율 {recall_score(yte, pr):.1%}, F1 {f1_score(yte, pr):.3f}")
rec = pd.DataFrame({"cls": mte["cls"], "hit": pr == yte}).query("cls != 'none'").groupby("cls")["hit"].mean().round(2)
print("결함 유형별 재현율:", ", ".join(f"{KO_CLS[k]} {v:.0%}" for k, v in rec.items()))
small = (mte["area_frac"] > 0) & (mte["area_frac"] < 0.02)
print(f"면적 2% 미만 작은 결함 {int(small.sum())}장 재현율 {pr[small.values].mean():.0%} (큰 결함 {pr[(mte['area_frac'] >= 0.02).values].mean():.0%})")
dk = mte["gain"] < 0.6
print(f"조명이 어두운 사진(gain<0.6) 정확도 {(pr == yte)[dk.values].mean():.0%} vs 밝은 사진 {(pr == yte)[~dk.values].mean():.0%}")
print("-> 전체 통계만 보는 Baseline은 작은 균열을 놓치고 조명에 흔들린다. 결함 위치·모양을 보는 분할 특징이 필요하다(미션 4~5의 동기).")

# 1) 상관분석: 결함 유무와의 관계(점이연 상관, 유의수준 0.05) - 사진 특징 + 장비 제원 기록
Fall = pd.concat([feature_table(ite), feature_table(itr[:200])], ignore_index=True)
mall = pd.concat([mte, mtr[:200]], ignore_index=True)
Fall["op_hours"], Fall["reg_grade"], Fall["mfg_year"] = mall["op_hours"], mall["reg_grade"], mall["mfg_year"]
Fall["coastal"] = (mall["env"] == "coastal").astype(int)
yall = (mall["cls"] != "none").astype(float)
rows = []
for f in ["c_std", "c_min", "edge_p95", "dark_frac", "rust_frac", "sat", "op_hours", "reg_grade", "mfg_year", "coastal"]:
    r, p = stats.pearsonr(Fall[f].astype(float), yall)
    rows.append({"피처": f, "상관계수": round(r, 3), "p-value": f"{p:.1e}", "유의": p < 0.05})
corr = pd.DataFrame(rows).sort_values("상관계수", key=abs, ascending=False)
print("\n[결함 유무와의 상관분석]")
print(corr.to_string(index=False))
n_sig = int(corr["유의"].sum())
print(f"유의미한 피처 {n_sig}개 (목표 5개 이상: {'달성' if n_sig >= 5 else '미달'})")

# 2) 제원 기록과의 불일치: 사진 판정 등급 vs 관리 기록 등급
ct = pd.crosstab(mall["grade"], mall["reg_grade"]).rename(index=GRADE_NAME, columns=GRADE_NAME)
gap = (mall["grade"] - mall["reg_grade"]).abs() >= 2
print(f"\n[제원 대조] 사진 등급과 관리 기록 등급이 2단계 이상 다른 장비 {int(gap.sum())}대({gap.mean():.1%}) -> 제원 이상 신호 후보")
print(ct.to_string())

# 3) 파레토(ABC): 정비 공수(가상)가 큰 (장비 구분, 결함 유형) 조합
HOURS = {1: 2, 2: 8, 3: 30}
mall["hours"] = mall["grade"].map(HOURS)
g = mall[mall["cls"] != "none"].groupby(["equip_type", "cls"])["hours"].sum().sort_values(ascending=False)
cum = g.cumsum() / g.sum()
abc = pd.cut(cum, [0, 0.8, 0.95, 1.0], labels=["A", "B", "C"])
print("\n[파레토 A등급(누적 정비 공수 80%)]", ", ".join(f"{e}/{KO_CLS[c]}" for (e, c), v in abc.items() if v == "A"))
print(f"A등급은 전체 조합 {len(g)}개 중 {int((abc == 'A').sum())}개({(abc == 'A').mean():.0%})")

# 4) EDA 차트 8종
fig, ax = plt.subplots(2, 4, figsize=(18, 8))
a = ax.ravel()
a[0].imshow(np.concatenate([ite[int(np.where(mte['cls'] == c)[0][0])] for c in CLASSES], axis=1)); a[0].set_title("1. Samples: none/crack/corrosion/damage/leak"); a[0].axis("off")
mall["cls"].value_counts().plot.bar(ax=a[1]); a[1].set_title("2. Photos by defect class")
a[2].hist(mall.loc[yall == 0, "gain"], bins=20, alpha=0.6, label="none"); a[2].hist(mall.loc[yall == 1, "gain"], bins=20, alpha=0.6, label="defect"); a[2].legend(); a[2].set_title("3. Lighting gain")
mall.boxplot(column="damage_idx", by="cls", ax=a[3], rot=30); a[3].set_title("4. Damage index by class")
a[4].imshow(ct.values, cmap="Blues"); a[4].set_xticks(range(3), [1, 2, 3]); a[4].set_yticks(range(3), [1, 2, 3]); a[4].set_xlabel("registered grade"); a[4].set_ylabel("photo grade"); a[4].set_title("5. Photo vs registered grade")
a[5].scatter(mall["op_hours"], mall["damage_idx"], s=6, c=mall["env"].map({"coastal": "tab:red", "inland": "tab:blue"})); a[5].set_title("6. Op hours vs damage (red = coastal)")
a[6].barh(corr["피처"], corr["상관계수"]); a[6].set_title("7. Correlation with defect")
a[7].plot(range(1, len(cum) + 1), cum.values, "o-"); a[7].axhline(0.8, ls="--", c="gray"); a[7].set_title("8. Pareto of repair hours")
plt.suptitle("QLT03 EDA - baseline defect screening (synthetic photos)"); plt.tight_layout(); plt.show()
print("\nEDA 차트 8종 생성 (목표 8종 이상: 달성)")
