"""장비 외관 결함(균열·부식·파손·누유) 사진 데이터셋의 라벨링 기준, 사진·장비 제원(관리 기록)·결함 라벨·판정 결과의 스키마와 데이터 딕셔너리(피처 20개 이상), 업무 프로세스 맵을 정의하고 가상 샘플로 제원 정합성을 검증한다."""
import json
import re
import numpy as np
import pandas as pd

# 1) 업무 프로세스 맵: 촬영에서 정비 등급 승인·제원 환류까지
PROCESS = [("촬영", "사진 ID, 촬영일, 촬영 조건(조명·오염)"), ("제원 대조", "장비 식별코드, 제조연도, 가동시간, 기록상 정비 등급"),
           ("전처리", "조명 보정, 해상도 표준화, 결함 영역(바운딩 박스)"), ("결함 판별", "결함 유형, 결함 면적, 추정 깊이"),
           ("손상도 산정", "손상도 점수(0~100), 판정 신뢰도"), ("검사관 보정", "수동 보정 여부, 보정 사유"),
           ("정비 등급 승인", "현장·현장·3단계 정비 등급, 승인자, 승인 시각"), ("제원 환류", "판정 결과와 기록상 등급의 불일치, 제원 수정 요청"), ("사후검토(AAR)", "오판 원인, 파라미터 재보정 이력")]

# 2) 라벨링 기준(데이터 딕셔너리의 일부)
LABEL_RULES = {"crack": "선형 어두운 균열, 길이 10px 이상", "corrosion": "붉은 갈색 면, 면적 12px 이상", "damage": "함몰·파단 윤곽(밝은 테두리 포함)",
               "leak": "어둡고 번지는 액체 자국(아래 방향 흐름)", "none": "결함 없음(무해한 얼룩·긁힘은 결함으로 라벨하지 않음)"}

# 3) 스키마: 그룹 / 필드 / 자료형 / 규칙 / 설명
S = {
    "photo": {
        "img_id": (str, {"pattern": r"^IMG\d{6}$"}, "사진 ID"),
        "shot_day": (int, {"min": 0, "max": 400}, "촬영일(점검 시작 후 경과일)"),
        "width": (int, {"enum": [64]}, "표준 해상도 가로(px)"),
        "height": (int, {"enum": [64]}, "표준 해상도 세로(px)"),
        "channels": (int, {"enum": [3]}, "채널 수(RGB)"),
        "brightness": (float, {"min": 0.05, "max": 1.0}, "평균 밝기(0~1)"),
        "mud_ratio": (float, {"min": 0, "max": 1}, "진흙·오염 가림 비율(추정)"),
    },
    "spec": {
        "equip_id": (str, {"pattern": r"^VX-\d{4}-\d{4}$"}, "장비 식별코드(표준 코드 형식을 모사한 가상 코드)"),
        "equip_type": (str, {"enum": ["vehicle", "generator", "comm", "trailer"]}, "장비 구분"),
        "mfg_year": (int, {"min": 1990, "max": 2026}, "제조연도(가상)"),
        "op_hours": (float, {"min": 0, "max": 30000}, "누적 가동시간(h)"),
        "env": (str, {"enum": ["coastal", "inland"]}, "운용 환경"),
        "reg_grade": (int, {"enum": [1, 2, 3]}, "관리 기록상 직전 정비 등급(1 현장, 2 현장, 3 3단계 정비)"),
    },
    "label": {
        "defect_class": (str, {"enum": ["none", "crack", "corrosion", "damage", "leak"]}, "결함 유형"),
        "bbox_x": (int, {"min": 0, "max": 63}, "결함 박스 좌상단 x"),
        "bbox_y": (int, {"min": 0, "max": 63}, "결함 박스 좌상단 y"),
        "bbox_w": (int, {"min": 1, "max": 64}, "결함 박스 폭"),
        "bbox_h": (int, {"min": 1, "max": 64}, "결함 박스 높이"),
        "emergency": (bool, {}, "긴급 점검 요청 여부(화질 불량이어도 보존)"),
    },
    "result": {
        "area_frac": (float, {"min": 0, "max": 1}, "결함 면적 비율 - 예측대상 1"),
        "depth_mm": (float, {"min": 0, "max": 30}, "추정 결함 깊이 - 예측대상 2"),
        "damage_idx": (float, {"min": 0, "max": 100}, "손상도 점수 - 예측대상 3"),
        "grade": (int, {"enum": [1, 2, 3]}, "정비 등급(현장/현장/3단계 정비) - 예측대상 4"),
        "confidence": (float, {"min": 0, "max": 1}, "판정 신뢰도 지수"),
    },
}


def check(name, v, typ, rule):
    if not isinstance(v, typ) or (typ in (int, float) and isinstance(v, bool)):
        return [f"{name}: 자료형 오류({type(v).__name__})"]
    e = []
    if "enum" in rule and v not in rule["enum"]:
        e.append(f"{name}: 허용되지 않은 값 '{v}'")
    if "min" in rule and v < rule["min"]:
        e.append(f"{name}: 최소값 {rule['min']} 미만")
    if "max" in rule and v > rule["max"]:
        e.append(f"{name}: 최대값 {rule['max']} 초과")
    if "pattern" in rule and not re.match(rule["pattern"], v):
        e.append(f"{name}: 형식 불일치 '{v}'")
    return e


def validate(rec):
    errs = []
    for g, fields in S.items():
        for k, (typ, rule, _) in fields.items():
            if k not in rec.get(g, {}):
                errs.append(f"{g}.{k}: 필수 필드 누락")
            else:
                errs += check(f"{g}.{k}", rec[g][k], typ, rule)
    b = rec.get("label", {})
    if all(k in b for k in ("bbox_x", "bbox_w", "bbox_y", "bbox_h")) and (b["bbox_x"] + b["bbox_w"] > 64 or b["bbox_y"] + b["bbox_h"] > 64):
        errs.append("label.bbox: 박스가 이미지 밖으로 나감")
    if rec.get("result", {}).get("grade") in (1, 2, 3) and rec.get("spec", {}).get("reg_grade") in (1, 2, 3):
        if abs(rec["result"]["grade"] - rec["spec"]["reg_grade"]) >= 2:
            errs.append("제원 대조: 판정 등급과 관리 기록 등급이 2단계 이상 차이(제원 이상 신호)")
    return errs


# 4) [교육용가상자료] 샘플 20건
rng = np.random.default_rng(1)
recs = []
for i in range(20):
    g = int(rng.integers(1, 4))
    recs.append({
        "photo": {"img_id": f"IMG{i:06d}", "shot_day": int(rng.integers(0, 90)), "width": 64, "height": 64, "channels": 3,
                  "brightness": float(round(rng.uniform(0.2, 0.9), 2)), "mud_ratio": float(round(rng.uniform(0, 0.3), 2))},
        "spec": {"equip_id": f"VX-{rng.integers(1000, 9999)}-{rng.integers(1000, 9999)}", "equip_type": str(rng.choice(["vehicle", "generator", "comm", "trailer"])),
                 "mfg_year": int(rng.integers(2000, 2025)), "op_hours": float(round(rng.uniform(100, 9000), 0)), "env": str(rng.choice(["coastal", "inland"])),
                 "reg_grade": int(np.clip(g + rng.integers(-1, 2), 1, 3))},
        "label": {"defect_class": str(rng.choice(["none", "crack", "corrosion", "damage", "leak"])), "bbox_x": int(rng.integers(0, 30)), "bbox_y": int(rng.integers(0, 30)),
                  "bbox_w": int(rng.integers(5, 30)), "bbox_h": int(rng.integers(5, 30)), "emergency": bool(rng.random() < 0.05)},
        "result": {"area_frac": float(round(rng.uniform(0, 0.2), 3)), "depth_mm": float(round(rng.uniform(0, 6), 1)), "damage_idx": float(round(rng.uniform(0, 100), 1)),
                   "grade": g, "confidence": float(round(rng.uniform(0.5, 1), 2))}})
ok = sum(not validate(r) for r in recs)
print(f"정상 샘플 {len(recs)}건 중 검증 통과 {ok}건, 오류 {len(recs) - ok}건")

# 5) 오류 주입 시험
bad = json.loads(json.dumps(recs[0]))
bad["spec"]["mfg_year"] = 2085                     # 제원 값 범위 이상(미래 제조연도)
bad["label"]["bbox_x"] = 60; bad["label"]["bbox_w"] = 20   # 박스가 사진 밖으로 나감
bad["result"]["grade"] = 5                         # 허용되지 않은 등급
del bad["spec"]["op_hours"]                        # 가동시간 누락
bad["photo"]["brightness"] = "어두움"               # 자료형 오류
print("\n[오류 주입 결과]")
for e in validate(bad):
    print(" -", e)
mis = json.loads(json.dumps(recs[1])); mis["result"]["grade"] = 3; mis["spec"]["reg_grade"] = 1
print("제원 불일치 시험:", validate(mis))

# 6) 프로세스 맵과 데이터 딕셔너리
print("\n[업무 프로세스 맵]")
print(" -> ".join(f"{i}.{p}" for i, (p, _) in enumerate(PROCESS, 1)))
for p, d in PROCESS:
    print(f"   {p:10s}: {d}")
print("\n[라벨링 기준]")
for k, v in LABEL_RULES.items():
    print(f"   {k:10s}: {v}")
rows = [(g, k, t.__name__, str(r) if r else "-", d) for g, f in S.items() for k, (t, r, d) in f.items()]
dd = pd.DataFrame(rows, columns=["그룹", "필드", "자료형", "규칙", "설명"])
print(f"\n[데이터 딕셔너리] 피처 {len(dd)}개 (목표 20개 이상: {'달성' if len(dd) >= 20 else '미달'})")
print(dd[["그룹", "필드", "자료형", "설명"]].to_string(index=False))
print("\n예측 대상: 결함 면적, 추정 깊이, 손상도 점수, 정비 등급. 제원 활용: 사진 판정과 관리 기록 등급이 크게 다르면 제원 이상 신호로 표시")
