"""분할(thresholding 기반 결함 후보 분할, Mask R-CNN 대체) 결과에서 결함 면적을 측정·보정하고 깊이와 손상도 점수를 학습해 손상도를 자동 판정하며, 분할 IoU·면적/깊이/손상도 오차(MAPE)와 변수군 제거 실험으로 파생 피처 설계의 타당성을 검증한다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import r2_score

# ---------------------------------------------------------------------------
# [교육용가상자료] 장비 외관 사진 생성기 (실제 장비·조직·위치 사진이 아니라 난수로 그린 64x64 합성 이미지)
# 도장된 금속 표면에 균열(crack)·부식(corrosion)·파손(damage)·누유(leak)를 그리고, 조명 편차와 진흙(mud) 오염을 섞는다.
# 이미지와 함께 장비 관리 기록(제원 요약)과 정답 결함 마스크·손상도·정비 등급을 만든다.
# ---------------------------------------------------------------------------
from scipy import ndimage as ndi

SZ = 64
CLASSES = ["none", "crack", "corrosion", "damage", "leak"]
KO_CLS = {"none": "결함 없음", "crack": "균열", "corrosion": "부식", "damage": "파손", "leak": "누유"}
CLS_W = {"none": 0.0, "crack": 1.4, "corrosion": 1.0, "damage": 1.6, "leak": 0.6}      # 손상도 계산용 결함 유형 가중치
GRADE_NAME = {1: "1단계 정비", 2: "2단계 정비", 3: "3단계 정비"}
YY, XX = np.mgrid[0:SZ, 0:SZ]


def grade_of(idx):
    return np.where(np.asarray(idx) >= 65, 3, np.where(np.asarray(idx) >= 35, 2, 1))


def blob(rng, cy, cx, r, rough=0.35):
    """불규칙한 원형 영역 마스크."""
    noise = ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 3)
    noise = noise / (np.abs(noise).max() + 1e-9)
    return (np.hypot(YY - cy, XX - cx) + rough * r * 2.2 * noise) < r


def draw(rng, cls, sev):
    """결함 유형·심각도 sev(0~1)에 맞는 정답 마스크와 색 정보를 만든다."""
    m = np.zeros((SZ, SZ), bool)
    if cls == "crack":
        y, x, ang = rng.uniform(12, 52), rng.uniform(12, 52), rng.uniform(0, np.pi)
        for _ in range(int(20 + 40 * sev)):
            ang += rng.normal(0, 0.35); y += np.sin(ang) * 1.2; x += np.cos(ang) * 1.2
            if 0 <= int(y) < SZ and 0 <= int(x) < SZ:
                m[int(y), int(x)] = True
        m = ndi.binary_dilation(m, iterations=1 + int(sev > 0.6))
    elif cls == "corrosion":
        for _ in range(int(rng.integers(1, 4))):
            m |= blob(rng, rng.uniform(14, 50), rng.uniform(14, 50), 3 + 9 * sev * rng.uniform(0.6, 1.1))
    elif cls == "damage":
        m = blob(rng, rng.uniform(20, 44), rng.uniform(20, 44), 6 + 12 * sev, 0.3)
    elif cls == "leak":
        x0, y0 = rng.uniform(16, 48), rng.uniform(8, 24)
        w, ln = 2 + 4 * sev, 12 + 26 * sev
        m = (np.abs(XX - x0 - 0.15 * (YY - y0)) < w * (1 - 0.4 * (YY - y0) / ln)) & (YY > y0) & (YY < y0 + ln)
    return m


def make_images(n=600, seed=0, mud=0.0, p_none=0.25, dark=False):
    """가상 외관 사진 n장(+진흙 오염 mud 비율)과 관리 기록·정답. 반환: meta(DataFrame), imgs(n,64,64,3), masks(n,64,64)."""
    rng = np.random.default_rng(seed)
    imgs, masks, rows = np.zeros((n, SZ, SZ, 3), np.float32), np.zeros((n, SZ, SZ), bool), []
    for i in range(n):
        cls = "none" if rng.random() < p_none else str(rng.choice(CLASSES[1:], p=[0.25, 0.3, 0.25, 0.2]))
        sev = 0.0 if cls == "none" else float(rng.beta(1.6, 2.0))
        base = np.array([0.42, 0.46, 0.40]) * (1 + 0.5 * ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 8)[..., None] * 3)
        img = base + rng.normal(0, 0.012, (SZ, SZ, 3))
        m = draw(rng, cls, sev)
        a = ndi.gaussian_filter(m.astype(float), 0.8)[..., None]                        # 경계를 부드럽게 섞는다
        if cls == "crack":
            col = img * rng.uniform(0.2, 0.45)
        elif cls == "corrosion":
            col = np.array([0.55, 0.30, 0.12]) * rng.uniform(0.75, 1.15) * (0.85 + 0.3 * rng.random((SZ, SZ, 1)))
        elif cls == "damage":
            col = np.ones_like(img) * np.array([0.34, 0.34, 0.36]) * (1.0 - 0.45 * sev) * rng.uniform(0.75, 1.0)
            rim = m & ~ndi.binary_erosion(m, iterations=2)
            a = np.maximum(a, 0.0); img = np.where(rim[..., None], 0.7, img)
        elif cls == "leak":
            col = np.ones_like(img) * np.array([0.10, 0.09, 0.08]) * rng.uniform(0.8, 2.6)
        else:
            col = img
        img = img * (1 - a) + col * a
        if rng.random() < 0.35:                                   # 무해한 얼룩(결함 아님): 옅은 갈색 번짐
            st = blob(rng, rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(6, 14), 0.5)
            al = ndi.gaussian_filter(st.astype(float), 2.5)[..., None] * rng.uniform(0.15, 0.4)
            img = img * (1 - al) + np.array([0.50, 0.40, 0.30]) * al
        if rng.random() < 0.3:                                    # 무해한 긴 스크래치(밝은 선)
            y0, x0, ang = rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(0, np.pi)
            for t in np.linspace(0, 25, 40):
                yy, xx = int(y0 + t * np.sin(ang)), int(x0 + t * np.cos(ang))
                if 0 <= yy < SZ and 0 <= xx < SZ:
                    img[yy, xx] = np.clip(img[yy, xx] * 1.5, 0, 1)
        if mud > 0:                                           # 진흙 오염: 결함 위를 덮을 수 있다(정답 마스크는 그대로)
            mm = np.zeros((SZ, SZ), bool)
            while mm.mean() < mud:
                mm |= blob(rng, rng.uniform(0, SZ), rng.uniform(0, SZ), rng.uniform(5, 11), 0.5)
            img[mm] = np.array([0.38, 0.30, 0.22]) * (0.85 + 0.3 * rng.random((mm.sum(), 1)))
        gain = rng.uniform(0.3, 0.55) if dark else rng.uniform(0.5, 1.15)
        ang = rng.uniform(0, 2 * np.pi)
        light = gain * (1 + 0.3 * (np.cos(ang) * (XX - 32) + np.sin(ang) * (YY - 32)) / 32)
        imgs[i] = np.clip(img * light[..., None] + rng.normal(0, 0.025, (SZ, SZ, 3)), 0, 1)
        masks[i] = m
        area = float(m.mean())
        depth = {"none": 0.0, "crack": 0.3 + 3.0 * sev, "corrosion": 0.1 + 1.5 * sev, "damage": 1.0 + 8.0 * sev, "leak": 0.0}[cls] * rng.lognormal(0, 0.1)
        idx = float(np.clip(100 * (1 - np.exp(-(CLS_W[cls] * area * 9 + 0.05 * depth))) + rng.normal(0, 1.5), 0, 100))
        rows.append({"img_id": f"IMG{seed:02d}{i:04d}", "cls": cls, "sev": sev, "area_frac": area, "depth_mm": depth, "damage_idx": idx,
                     "grade": int(grade_of(idx)), "gain": gain, "mud": mud})
    meta = pd.DataFrame(rows)
    # 장비 관리 기록(제원 요약): 사진 판정과 대조할 값
    age = rng.integers(1, 25, n)
    meta["day"] = np.sort(rng.integers(0, 90, n))
    meta["equip_type"] = rng.choice(["vehicle", "generator", "comm", "trailer"], n, p=[0.4, 0.2, 0.2, 0.2])
    meta["mfg_year"] = 2026 - age
    meta["op_hours"] = np.clip(rng.normal(180 * age, 400, n) + 8 * meta["damage_idx"], 10, 20000)
    meta["env"] = rng.choice(["coastal", "inland"], n, p=[0.3, 0.7])
    reg = np.clip(meta["grade"] + rng.choice([-1, 0, 0, 0, 0, 0, 1, 2], n), 1, 3)           # 장비 관리 기록상 직전 정비 등급
    meta["reg_grade"] = reg
    meta["emergency"] = rng.random(n) < 0.04                                               # 긴급 점검 요청(화질 불량이어도 보존)
    return meta, imgs, masks
# ---- 전처리(조명 보정·표준화)와 결함 후보 분할, 특징 추출 (cv2 대신 numpy·scipy 사용) ----
def correct(img):
    """조명 보정: 밝기에 평면(조명 기울기)을 적합해 나눈다. 어두운 결함 화소는 제외하고 두 번 반복 적합한다. 반환: 보정 밝기(정상 면 약 1), 색 비율."""
    g = img.mean(axis=2)
    A = np.c_[np.ones(SZ * SZ), XX.ravel() / SZ, YY.ravel() / SZ]
    keep = np.ones(SZ * SZ, bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(A[keep], g.ravel()[keep], rcond=None)
        plane = (A @ coef).reshape(SZ, SZ)
        keep = (np.abs(g - plane) < 0.08 * np.maximum(plane, 1e-3)).ravel()
        if keep.sum() < 200:
            keep[:] = True
    c = g / np.maximum(plane, 1e-3)
    chroma = img[..., 0] / (img.sum(axis=2) + 1e-6)
    return c, chroma


SEGP = {"dark": 0.7, "rust": 0.5, "rim": 1.45}            # 분할 임계값(어두움 보정 밝기, 붉은 비율, 밝은 테두리): 재보정 대상


def segment(img):
    """결함 후보 마스크: 어두운 영역(균열·누유·파손) + 붉은 갈색 영역(부식) + 밝은 테두리(파손)."""
    c, chroma = correct(img)
    dark = c < SEGP["dark"]
    rust = (chroma > SEGP["rust"]) & (c > 0.45)
    rim = c > SEGP["rim"]
    m = dark | rust | ndi.binary_dilation(rim, iterations=1) & ndi.binary_dilation(dark, iterations=3)
    m = ndi.binary_opening(m, structure=np.ones((2, 2))) if m.sum() > 12 else m
    return m, c, chroma, dark, rust, rim


def extract(img):
    """분할 결과와 색·모양에서 24개 특징을 만든다."""
    m, c, chroma, dark, rust, rim = segment(img)
    lab, n = ndi.label(m)
    area = float(m.sum())
    if n:
        sizes = ndi.sum(m, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        sl = ndi.find_objects(lab)[k - 1]
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        big = float(sizes.max())
        elong, fill = max(h, w) / max(min(h, w), 1), big / (h * w)
    else:
        big, elong, fill = 0.0, 1.0, 0.0
    gy, gx = np.gradient(c)
    mag = np.hypot(gx, gy)
    inside = m.sum() > 0
    return {"area_px": area, "area_frac": area / SZ ** 2, "n_comp": float(n), "big_px": big, "elong": elong, "fill": fill,
            "dark_frac": float(dark.mean()), "rust_frac": float(rust.mean()), "rim_frac": float(rim.mean()),
            "c_mean": float(c.mean()), "c_std": float(c.std()), "c_min": float(c.min()), "edge_mean": float(mag.mean()), "edge_p95": float(np.quantile(mag, 0.95)),
            "chroma_mean": float(chroma.mean()), "chroma_max": float(chroma.max()),
            "in_dark": float(c[m].mean()) if inside else 1.0, "in_chroma": float(chroma[m].mean()) if inside else float(chroma.mean()),
            "ring_contrast": float(c[ndi.binary_dilation(m, iterations=3) & ~m].mean() - c[m].mean()) if inside and (~m).any() else 0.0,
            "thin": float(1 - fill), "gain": float(img.mean()), "sat": float((img.max(axis=2) - img.min(axis=2)).mean()),
            "cy": float(ndi.center_of_mass(m)[0] / SZ) if inside else 0.5, "cx": float(ndi.center_of_mass(m)[1] / SZ) if inside else 0.5}


def feature_table(imgs):
    return pd.DataFrame([extract(im) for im in imgs])
# ---- 판정 파이프라인: 결함 유형 분류 + 손상도 회귀(분류 확률 포함) -> 정비 등급 ----
def fit_pipeline(meta, F):
    """결함 유형 분류기와 손상도 회귀기를 학습한다. 회귀기 입력의 분류 확률은 교차 예측으로 만들어 누설을 막는다."""
    clf = RandomForestClassifier(n_estimators=150, random_state=0, n_jobs=1)
    P = cross_val_predict(clf, F, meta["cls"], cv=4, method="predict_proba")
    clf.fit(F, meta["cls"])
    reg = GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.06, random_state=0).fit(np.c_[F.values, P], meta["damage_idx"])
    return {"clf": clf, "reg": reg, "cols": list(F.columns)}


def predict_pipeline(pl, F):
    X = F[pl["cols"]]
    P = pl["clf"].predict_proba(X)
    idx = np.clip(pl["reg"].predict(np.c_[X.values, P]), 0, 100)
    return pl["clf"].classes_[P.argmax(axis=1)], P, idx, P.max(axis=1)

mtr, itr, ktr = make_images(600, seed=1)
mte, ite, kte = make_images(300, seed=2)
Ftr, Fte = feature_table(itr), feature_table(ite)
print(f"[1] 파생 피처 {Ftr.shape[1]}개(분할 면적·성분 수·모양, 명암, 색, 가장자리, 위치) / 학습 {len(mtr)}장, 평가 {len(mte)}장 (1화소 = 1.5mm 가정)")

# ---------------- 1) 분할 정밀도: 정답 마스크와의 IoU ----------------
seg = [segment(im)[0] for im in ite]
rows = []
for c in CLASSES[1:]:
    ix = np.where(mte["cls"].values == c)[0]
    iou = [(seg[i] & kte[i]).sum() / max((seg[i] | kte[i]).sum(), 1) for i in ix]
    dice = [2 * (seg[i] & kte[i]).sum() / max(seg[i].sum() + kte[i].sum(), 1) for i in ix]
    hit = [seg[i].sum() > 0 and (seg[i] & kte[i]).sum() > 0 for i in ix]
    rows.append((KO_CLS[c], len(ix), np.mean(iou), np.mean(dice), np.mean(hit)))
sg = pd.DataFrame(rows, columns=["결함", "장수", "평균 IoU", "평균 Dice", "검출률"])
print("[2] 분할 성능(평가 300장)\n" + sg.round(2).to_string(index=False))
ok0 = np.mean([seg[i].sum() == 0 or (seg[i].sum() < 12) for i in np.where(mte["cls"].values == "none")[0]])
print(f"    결함 없는 사진 {int((mte['cls'] == 'none').sum())}장 중 분할 결과가 거의 비어 있는(12화소 미만) 사진 {ok0:.0%} (무해한 얼룩·스크래치 오탐 억제)")

# ---------------- 2) 면적 측정과 유형별 보정 ----------------
pl = fit_pipeline(mtr, Ftr)
cls_te, P_te, idx_te, conf_te = predict_pipeline(pl, Fte)
a_true, a_raw = mte["area_frac"].values, Fte["area_frac"].values
cal = {c: LinearRegression().fit(Ftr.loc[mtr["cls"].values == c, ["area_frac"]], mtr.loc[mtr["cls"].values == c, "area_frac"]) for c in CLASSES[1:]}
a_cal = np.array([cal[c].predict(pd.DataFrame({"area_frac": [a]}))[0] if c != "none" else 0.0 for c, a in zip(cls_te, a_raw)])
m = a_true > 0
mp = lambda y, p: float(np.mean(np.abs(y - p) / y) * 100)
print(f"\n[3] 면적 측정(결함 {int(m.sum())}장): 분할 원측정 MAPE {mp(a_true[m], a_raw[m]):.1f}% -> 유형별 선형 보정 후 {mp(a_true[m], a_cal[m]):.1f}% (분류 정확도 {(cls_te == mte['cls'].values).mean():.1%})")
print(f"    면적 환산 예: 평균 결함 면적 {a_true[m].mean() * SZ ** 2 * 1.5 ** 2:.0f}mm2(정답) / {a_cal[m].mean() * SZ ** 2 * 1.5 ** 2:.0f}mm2(보정 측정)")

# ---------------- 3) 깊이·손상도 모델 ----------------
dm_tr = mtr["depth_mm"].values > 0.2
Xtr = np.c_[Ftr[pl["cols"]].values, cross_val_predict(RandomForestClassifier(n_estimators=100, random_state=0, n_jobs=1), Ftr, mtr["cls"], cv=3, method="predict_proba")]
dep = GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.06, random_state=0).fit(Xtr[dm_tr], mtr["depth_mm"].values[dm_tr])
d_pred = np.clip(dep.predict(np.c_[Fte[pl["cols"]].values, P_te]), 0, None)
dm = mte["depth_mm"].values > 0.2
print(f"[4] 깊이 추정(깊이 있는 유형 {int(dm.sum())}장, 누유는 깊이 0으로 제외): MAPE {mp(mte['depth_mm'].values[dm], d_pred[dm]):.1f}%, MAE {np.mean(np.abs(mte['depth_mm'].values[dm] - d_pred[dm])):.2f}mm")
print("    깊이는 사진 한 장으로 직접 관측되지 않아 면적·명암에서 간접 추정하므로 손상도보다 오차가 크다(실제 업무는 깊이 게이지 등 현장 측정으로 확인).")
y = mte["damage_idx"].values
big = y >= 10
mape_d, mae_d = mp(y[big], idx_te[big]), float(np.mean(np.abs(y - idx_te)))
base = LinearRegression().fit(Ftr[["area_px"]], mtr["damage_idx"])
b_pred = np.clip(base.predict(Fte[["area_px"]]), 0, 100)
print(f"[5] 손상도 점수(0~100, 점수 10 이상 {int(big.sum())}장): 면적만 쓰는 기준 MAPE {mp(y[big], b_pred[big]):.1f}% -> 제안 모델 MAPE {mape_d:.1f}% (목표 25% 이하: {'달성' if mape_d <= 25 else '미달'}), MAE {mae_d:.2f}, R2 {r2_score(y, idx_te):.3f}")
g_true, g_pred = mte["grade"].values, grade_of(idx_te)
print(f"    정비 등급 일치율 {(g_true == g_pred).mean():.1%}, 한 단계 이내 {(np.abs(g_true - g_pred) <= 1).mean():.1%}")

# ---------------- 4) 변수군 제거 실험 ----------------
groups = {"분할 면적·모양": ["area_px", "area_frac", "n_comp", "big_px", "elong", "fill", "thin", "cy", "cx"], "명암(어두운 비율·대비)": ["dark_frac", "c_mean", "c_std", "c_min", "in_dark", "ring_contrast"],
          "색(붉은 갈색)": ["rust_frac", "chroma_mean", "chroma_max", "in_chroma", "sat"], "가장자리·테두리": ["edge_mean", "edge_p95", "rim_frac"], "조명": ["gain"]}
full_cols = list(Ftr.columns)


def run(cols):
    g = GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.06, random_state=0).fit(Ftr[cols], mtr["damage_idx"])
    p = np.clip(g.predict(Fte[cols]), 0, 100)
    return mp(y[big], p[big])


full = run(full_cols)
ab = pd.DataFrame([(k, run([c for c in full_cols if c not in v])) for k, v in groups.items()], columns=["제거한 변수군", "MAPE(%)"]).assign(증가=lambda x: x["MAPE(%)"] - full).sort_values("증가", ascending=False)
print(f"\n[6] 변수군 제거(분류 확률 없이 24개 피처만 사용, 전체 MAPE {full:.1f}%)\n" + ab.round(2).to_string(index=False))
print(f"    해석: 제거 시 오차가 가장 크게 늘어난 변수군은 '{ab.iloc[0]['제거한 변수군']}'(+{ab.iloc[0]['증가']:.1f}%p)이다. 변수군끼리 정보가 겹쳐 단독 제거 효과는 작게 나타날 수 있다.")
print("    판정은 정비 의사결정 보조이며 최종 등급은 검사관이 확정한다(M7). 사진·장비는 모두 교육용 가상 자료이다.")

fig, ax = plt.subplots(1, 3, figsize=(15, 4.3))
ax[0].bar(range(len(sg)), sg["평균 IoU"]); ax[0].set_xticks(range(len(sg))); ax[0].set_xticklabels(["crack", "corrosion", "damage", "leak"]); ax[0].set_title("Segmentation IoU by defect type")
ax[1].scatter(a_true[m], a_raw[m], s=8, label="raw"); ax[1].scatter(a_true[m], a_cal[m], s=8, label="calibrated"); ax[1].plot([0, .2], [0, .2], "k--"); ax[1].legend(); ax[1].set_title("Defect area fraction: true vs measured")
ax[2].scatter(y, idx_te, s=8); ax[2].plot([0, 100], [0, 100], "k--"); ax[2].set_title("Damage index: true vs predicted")
plt.tight_layout(); plt.show()
