"""QLT03 M8 로컬 대시보드. 교육용 합성자료만 사용하며 외부 통신은 하지 않는다."""
from pathlib import Path
import contextlib
import io
import runpy
import time

PROJECT = Path(__file__).resolve().parents[2]


def load_results(source=None):
    """원문 시뮬레이터를 그대로 실행하여 동일한 표와 실측 시간을 반환한다."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    source = Path(source) if source is not None else PROJECT / "src/m08.py"
    log = io.StringIO()
    previous_show = plt.show
    plt.show = lambda *args, **kwargs: plt.close("all")
    started = time.perf_counter()
    try:
        with contextlib.redirect_stdout(log):
            result = runpy.run_path(str(source), run_name="__main__")
    finally:
        plt.show = previous_show
        plt.close("all")
    return {"sweep": result["sw"], "conditions": result["cc"],
            "loading": result["loads"], "stdout": log.getvalue(),
            "elapsed_seconds": time.perf_counter() - started}


def main():
    import pandas as pd
    import streamlit as st
    st.set_page_config(page_title="QLT03 합성 외관검사", layout="wide")
    st.title("QLT03 M8 합성 외관검사 대시보드")
    st.caption("[교육용가상자료] 원문 M8 시뮬레이터 결과. 현장 성능·실제 장비 판정이 아닙니다.")
    st.info("자동 처리 후보도 검사관 확인이 필요합니다. 웹앱 실행과 외부 배포는 별개입니다.")
    cached_results = st.cache_data(show_spinner=False)(load_results)
    if st.button("합성자료 시험 실행", key="run_simulator"):
        with st.spinner("고정 seed 합성사진 생성·모델 학습·스트레스 시험 실행 중"):
            try:
                st.session_state["qlt03_results"] = cached_results()
            except Exception as error:
                st.error(f"실행 실패: {error}. M8 노트북/콘솔 대체 경로와 환경 안내를 확인하세요.")
                return
    result = st.session_state.get("qlt03_results")
    if result is None:
        st.write("버튼을 눌러 결과를 생성하세요. 최초 실행에는 모델 학습 시간이 포함됩니다.")
        return
    sweep = result["sweep"]
    selected = st.selectbox("진흙 혼입 비율", sweep["진흙 비율"].tolist())
    row = sweep.loc[sweep["진흙 비율"] == selected].iloc[0]
    st.metric("시험 사진 수", f"{int(row['장수'])}장")
    st.metric("자동 처리 후보 비율", f"{row['자동 처리 비율']:.1%}")
    accuracy = row["경보 정확도(게이트 후)"]
    st.metric("후보 내 경보 정확도", "평가 불가 (후보 0건)" if pd.isna(accuracy) else f"{accuracy:.1%}")
    st.caption("경보 정확도의 분모는 게이트 통과 후보입니다. 후보 0건은 100%가 아닙니다.")
    st.dataframe(sweep)
    st.line_chart(sweep.set_index("진흙 비율")[["자동 처리 비율", "경보 정확도(게이트 후)"]])
    st.subheader("복합 열화 조건")
    st.dataframe(result["conditions"])
    st.subheader("시뮬레이터 집계·차트 렌더링 시간")
    st.dataframe(pd.DataFrame(result["loading"], columns=["건수", "초"]))
    st.caption(f"이번 시뮬레이터 전체 실행 {result['elapsed_seconds']:.2f}초. 위 표의 시간은 웹 브라우저 응답 시간이 아닙니다.")
    st.download_button("현재 시험 표 CSV 저장", sweep.to_csv(index=False).encode("utf-8-sig"),
                       file_name="qlt03_m08_sweep.csv", mime="text/csv")
    st.download_button("실행 로그 저장", result["stdout"].encode("utf-8"),
                       file_name="qlt03_m08_app_stdout.txt", mime="text/plain")
    st.text_area("이번 실행 로그", result["stdout"], height=260)


if __name__ == "__main__":
    main()
