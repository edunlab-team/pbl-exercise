"""AI 정비 등급 판정을 신뢰도에 따라 간이 승인·정밀 판독으로 나누는 검사 운영안을 비용으로 최적화하고(전수 정밀 판독 관행 대비, 검사관 일일 한도 제약 반영), 모든 판정을 검사관 수동 보정 후 정비감독관(3단계 정비·보정 건은 품질보증관까지)이 직접 승인하는 HITL 절차(권한·사유·해시 체인 감사 로그)를 구현한다."""
import hashlib
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.model_selection import cross_val_predict

# ---------------------------------------------------------------------------
# [교육용가상자료] 장비 외관 사진 생성기 (실제 장비·조직·위치 사진이 아니라 난수로 그린 64x64 합성 이미지)
# 도장된 금속 표면에 균열(crack)·부식(corrosion)·파손(damage)·누유(leak)를 그리고, 조명 편차와 진흙(mud) 오염을 섞는다.
# 이미지와 함께 장비 관리 기록(제원 요약)과 정답 결함 마스크·손상도·정비 등급을 만든다.
# ---------------------------------------------------------------------------
from scipy import ndimage as ndi

SZ = 64
CLASSES = ["none", "crack", "corrosion", "damage", "leak"]
KO_CLS = {"none": "결함 없음", "crack": "균열", "corrosion": "부식", "damage": "파손", "leak": "누유"}
CLS_W = {"none": 0.0, "crack": 1.4, "corrosion": 1.0, "damage": 1.6, "leak": 0.6}      # 손상도 계산용 결함 유형 가중치
GRADE_NAME = {1: "1단계 정비", 2: "2단계 정비", 3: "3단계 정비"}
YY, XX = np.mgrid[0:SZ, 0:SZ]


def grade_of(idx):
    return np.where(np.asarray(idx) >= 65, 3, np.where(np.asarray(idx) >= 35, 2, 1))


def blob(rng, cy, cx, r, rough=0.35):
    """불규칙한 원형 영역 마스크."""
    noise = ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 3)
    noise = noise / (np.abs(noise).max() + 1e-9)
    return (np.hypot(YY - cy, XX - cx) + rough * r * 2.2 * noise) < r


def draw(rng, cls, sev):
    """결함 유형·심각도 sev(0~1)에 맞는 정답 마스크와 색 정보를 만든다."""
    m = np.zeros((SZ, SZ), bool)
    if cls == "crack":
        y, x, ang = rng.uniform(12, 52), rng.uniform(12, 52), rng.uniform(0, np.pi)
        for _ in range(int(20 + 40 * sev)):
            ang += rng.normal(0, 0.35); y += np.sin(ang) * 1.2; x += np.cos(ang) * 1.2
            if 0 <= int(y) < SZ and 0 <= int(x) < SZ:
                m[int(y), int(x)] = True
        m = ndi.binary_dilation(m, iterations=1 + int(sev > 0.6))
    elif cls == "corrosion":
        for _ in range(int(rng.integers(1, 4))):
            m |= blob(rng, rng.uniform(14, 50), rng.uniform(14, 50), 3 + 9 * sev * rng.uniform(0.6, 1.1))
    elif cls == "damage":
        m = blob(rng, rng.uniform(20, 44), rng.uniform(20, 44), 6 + 12 * sev, 0.3)
    elif cls == "leak":
        x0, y0 = rng.uniform(16, 48), rng.uniform(8, 24)
        w, ln = 2 + 4 * sev, 12 + 26 * sev
        m = (np.abs(XX - x0 - 0.15 * (YY - y0)) < w * (1 - 0.4 * (YY - y0) / ln)) & (YY > y0) & (YY < y0 + ln)
    return m


def make_images(n=600, seed=0, mud=0.0, p_none=0.25, dark=False):
    """가상 외관 사진 n장(+진흙 오염 mud 비율)과 관리 기록·정답. 반환: meta(DataFrame), imgs(n,64,64,3), masks(n,64,64)."""
    rng = np.random.default_rng(seed)
    imgs, masks, rows = np.zeros((n, SZ, SZ, 3), np.float32), np.zeros((n, SZ, SZ), bool), []
    for i in range(n):
        cls = "none" if rng.random() < p_none else str(rng.choice(CLASSES[1:], p=[0.25, 0.3, 0.25, 0.2]))
        sev = 0.0 if cls == "none" else float(rng.beta(1.6, 2.0))
        base = np.array([0.42, 0.46, 0.40]) * (1 + 0.5 * ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 8)[..., None] * 3)
        img = base + rng.normal(0, 0.012, (SZ, SZ, 3))
        m = draw(rng, cls, sev)
        a = ndi.gaussian_filter(m.astype(float), 0.8)[..., None]                        # 경계를 부드럽게 섞는다
        if cls == "crack":
            col = img * rng.uniform(0.2, 0.45)
        elif cls == "corrosion":
            col = np.array([0.55, 0.30, 0.12]) * rng.uniform(0.75, 1.15) * (0.85 + 0.3 * rng.random((SZ, SZ, 1)))
        elif cls == "damage":
            col = np.ones_like(img) * np.array([0.34, 0.34, 0.36]) * (1.0 - 0.45 * sev) * rng.uniform(0.75, 1.0)
            rim = m & ~ndi.binary_erosion(m, iterations=2)
            a = np.maximum(a, 0.0); img = np.where(rim[..., None], 0.7, img)
        elif cls == "leak":
            col = np.ones_like(img) * np.array([0.10, 0.09, 0.08]) * rng.uniform(0.8, 2.6)
        else:
            col = img
        img = img * (1 - a) + col * a
        if rng.random() < 0.35:                                   # 무해한 얼룩(결함 아님): 옅은 갈색 번짐
            st = blob(rng, rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(6, 14), 0.5)
            al = ndi.gaussian_filter(st.astype(float), 2.5)[..., None] * rng.uniform(0.15, 0.4)
            img = img * (1 - al) + np.array([0.50, 0.40, 0.30]) * al
        if rng.random() < 0.3:                                    # 무해한 긴 스크래치(밝은 선)
            y0, x0, ang = rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(0, np.pi)
            for t in np.linspace(0, 25, 40):
                yy, xx = int(y0 + t * np.sin(ang)), int(x0 + t * np.cos(ang))
                if 0 <= yy < SZ and 0 <= xx < SZ:
                    img[yy, xx] = np.clip(img[yy, xx] * 1.5, 0, 1)
        if mud > 0:                                           # 진흙 오염: 결함 위를 덮을 수 있다(정답 마스크는 그대로)
            mm = np.zeros((SZ, SZ), bool)
            while mm.mean() < mud:
                mm |= blob(rng, rng.uniform(0, SZ), rng.uniform(0, SZ), rng.uniform(5, 11), 0.5)
            img[mm] = np.array([0.38, 0.30, 0.22]) * (0.85 + 0.3 * rng.random((mm.sum(), 1)))
        gain = rng.uniform(0.3, 0.55) if dark else rng.uniform(0.5, 1.15)
        ang = rng.uniform(0, 2 * np.pi)
        light = gain * (1 + 0.3 * (np.cos(ang) * (XX - 32) + np.sin(ang) * (YY - 32)) / 32)
        imgs[i] = np.clip(img * light[..., None] + rng.normal(0, 0.025, (SZ, SZ, 3)), 0, 1)
        masks[i] = m
        area = float(m.mean())
        depth = {"none": 0.0, "crack": 0.3 + 3.0 * sev, "corrosion": 0.1 + 1.5 * sev, "damage": 1.0 + 8.0 * sev, "leak": 0.0}[cls] * rng.lognormal(0, 0.1)
        idx = float(np.clip(100 * (1 - np.exp(-(CLS_W[cls] * area * 9 + 0.05 * depth))) + rng.normal(0, 1.5), 0, 100))
        rows.append({"img_id": f"IMG{seed:02d}{i:04d}", "cls": cls, "sev": sev, "area_frac": area, "depth_mm": depth, "damage_idx": idx,
                     "grade": int(grade_of(idx)), "gain": gain, "mud": mud})
    meta = pd.DataFrame(rows)
    # 장비 관리 기록(제원 요약): 사진 판정과 대조할 값
    age = rng.integers(1, 25, n)
    meta["day"] = np.sort(rng.integers(0, 90, n))
    meta["equip_type"] = rng.choice(["vehicle", "generator", "comm", "trailer"], n, p=[0.4, 0.2, 0.2, 0.2])
    meta["mfg_year"] = 2026 - age
    meta["op_hours"] = np.clip(rng.normal(180 * age, 400, n) + 8 * meta["damage_idx"], 10, 20000)
    meta["env"] = rng.choice(["coastal", "inland"], n, p=[0.3, 0.7])
    reg = np.clip(meta["grade"] + rng.choice([-1, 0, 0, 0, 0, 0, 1, 2], n), 1, 3)           # 장비 관리 기록상 직전 정비 등급
    meta["reg_grade"] = reg
    meta["emergency"] = rng.random(n) < 0.04                                               # 긴급 점검 요청(화질 불량이어도 보존)
    return meta, imgs, masks
# ---- 전처리(조명 보정·표준화)와 결함 후보 분할, 특징 추출 (cv2 대신 numpy·scipy 사용) ----
def correct(img):
    """조명 보정: 밝기에 평면(조명 기울기)을 적합해 나눈다. 어두운 결함 화소는 제외하고 두 번 반복 적합한다. 반환: 보정 밝기(정상 면 약 1), 색 비율."""
    g = img.mean(axis=2)
    A = np.c_[np.ones(SZ * SZ), XX.ravel() / SZ, YY.ravel() / SZ]
    keep = np.ones(SZ * SZ, bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(A[keep], g.ravel()[keep], rcond=None)
        plane = (A @ coef).reshape(SZ, SZ)
        keep = (np.abs(g - plane) < 0.08 * np.maximum(plane, 1e-3)).ravel()
        if keep.sum() < 200:
            keep[:] = True
    c = g / np.maximum(plane, 1e-3)
    chroma = img[..., 0] / (img.sum(axis=2) + 1e-6)
    return c, chroma


SEGP = {"dark": 0.7, "rust": 0.5, "rim": 1.45}            # 분할 임계값(어두움 보정 밝기, 붉은 비율, 밝은 테두리): 재보정 대상


def segment(img):
    """결함 후보 마스크: 어두운 영역(균열·누유·파손) + 붉은 갈색 영역(부식) + 밝은 테두리(파손)."""
    c, chroma = correct(img)
    dark = c < SEGP["dark"]
    rust = (chroma > SEGP["rust"]) & (c > 0.45)
    rim = c > SEGP["rim"]
    m = dark | rust | ndi.binary_dilation(rim, iterations=1) & ndi.binary_dilation(dark, iterations=3)
    m = ndi.binary_opening(m, structure=np.ones((2, 2))) if m.sum() > 12 else m
    return m, c, chroma, dark, rust, rim


def extract(img):
    """분할 결과와 색·모양에서 24개 특징을 만든다."""
    m, c, chroma, dark, rust, rim = segment(img)
    lab, n = ndi.label(m)
    area = float(m.sum())
    if n:
        sizes = ndi.sum(m, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        sl = ndi.find_objects(lab)[k - 1]
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        big = float(sizes.max())
        elong, fill = max(h, w) / max(min(h, w), 1), big / (h * w)
    else:
        big, elong, fill = 0.0, 1.0, 0.0
    gy, gx = np.gradient(c)
    mag = np.hypot(gx, gy)
    inside = m.sum() > 0
    return {"area_px": area, "area_frac": area / SZ ** 2, "n_comp": float(n), "big_px": big, "elong": elong, "fill": fill,
            "dark_frac": float(dark.mean()), "rust_frac": float(rust.mean()), "rim_frac": float(rim.mean()),
            "c_mean": float(c.mean()), "c_std": float(c.std()), "c_min": float(c.min()), "edge_mean": float(mag.mean()), "edge_p95": float(np.quantile(mag, 0.95)),
            "chroma_mean": float(chroma.mean()), "chroma_max": float(chroma.max()),
            "in_dark": float(c[m].mean()) if inside else 1.0, "in_chroma": float(chroma[m].mean()) if inside else float(chroma.mean()),
            "ring_contrast": float(c[ndi.binary_dilation(m, iterations=3) & ~m].mean() - c[m].mean()) if inside and (~m).any() else 0.0,
            "thin": float(1 - fill), "gain": float(img.mean()), "sat": float((img.max(axis=2) - img.min(axis=2)).mean()),
            "cy": float(ndi.center_of_mass(m)[0] / SZ) if inside else 0.5, "cx": float(ndi.center_of_mass(m)[1] / SZ) if inside else 0.5}


def feature_table(imgs):
    return pd.DataFrame([extract(im) for im in imgs])
# ---- 판정 파이프라인: 결함 유형 분류 + 손상도 회귀(분류 확률 포함) -> 정비 등급 ----
def fit_pipeline(meta, F):
    """결함 유형 분류기와 손상도 회귀기를 학습한다. 회귀기 입력의 분류 확률은 교차 예측으로 만들어 누설을 막는다."""
    clf = RandomForestClassifier(n_estimators=150, random_state=0, n_jobs=1)
    P = cross_val_predict(clf, F, meta["cls"], cv=4, method="predict_proba")
    clf.fit(F, meta["cls"])
    reg = GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.06, random_state=0).fit(np.c_[F.values, P], meta["damage_idx"])
    return {"clf": clf, "reg": reg, "cols": list(F.columns)}


def predict_pipeline(pl, F):
    X = F[pl["cols"]]
    P = pl["clf"].predict_proba(X)
    idx = np.clip(pl["reg"].predict(np.c_[X.values, P]), 0, 100)
    return pl["clf"].classes_[P.argmax(axis=1)], P, idx, P.max(axis=1)
# ---- 사진 품질 게이트: 진흙·오염 가림 추정과 판정 신뢰도 지수 ----
def mud_est(img):
    """진흙(갈색, 채도 낮은 붉은 기) 화소 비율을 추정한다. 3x3 평균으로 잡음을 줄인 뒤 색 비율로 판단하며, 실제 가림 비율보다 작게 나오지만 순서는 유지된다."""
    sm = ndi.uniform_filter(img, size=(3, 3, 1))
    s = sm.sum(axis=2) + 1e-6
    rr, gg = sm[..., 0] / s, sm[..., 1] / s
    return float(((rr > 0.385) & (rr < 0.46) & (gg < 0.325)).mean())


def confidence(P, idx, F, mud):
    """판정 신뢰도 지수 0~100 = 50 x 분류 확률 최대값 + 35 x 등급 경계까지 거리(8점에서 포화) + 15 x 사진 품질. 오염 의심(mud 추정 1% 이상)이면 상한 75로 제한한다."""
    bd = np.minimum(np.abs(idx - 35), np.abs(idx - 65))
    qual = np.clip(1.0 - np.clip(0.55 - F["gain"].values, 0, None) * 2 - np.clip(0.9 - F["c_mean"].values, 0, None), 0, 1)
    c = 50 * P.max(axis=1) + 35 * np.clip(bd / 8, 0, 1) + 15 * qual
    return np.where(np.asarray(mud) >= 0.01, np.minimum(c, 75.0), c)

mtr, itr, _ = make_images(600, seed=1)
Ftr = feature_table(itr)
pl = fit_pipeline(mtr, Ftr)


def judge(seed, n, **kw):
    """사진 n장을 만들어 AI 판정(등급·신뢰도)과 정답 등급을 돌려준다."""
    m, im, _ = make_images(n, seed=seed, **kw)
    F = feature_table(im)
    cls, P, idx, _ = predict_pipeline(pl, F)
    conf = confidence(P, idx, F, [mud_est(x) for x in im])
    return pd.DataFrame({"true": m["grade"].values, "ai": grade_of(idx), "conf": conf, "idx": idx, "cls": cls, "id": m["img_id"].values})


SETS = {"평상(정상 조명)": judge(2, 300), "저조도 사진 많음": judge(7, 150, dark=True), "진흙 가림 20%": judge(8, 150, mud=0.2)}

# ---------------- 1) 비용 모델(교육용 가정, 만원/장) ----------------
C_FULL, C_QUICK, C_AI = 0.9, 0.25, 0.05            # 정밀 판독, 간이 승인(AI 판정 열람 후 승인), AI 판정 전산 비용
P_HUMAN, P_CATCH = 0.08, 0.5                        # 검사관 정밀 판독 오류율(+-1 등급), 간이 승인 시 AI 오판을 걸러내는 확률
LOSS_UNDER, LOSS_OVER = 20.0, 6.0                   # 과소 판정(재입고·고장 위험) / 과대 판정(과다 정비) 1등급당 손실
CAP = 120                                           # 검사관 일일 정밀 판독 한도(장)


def loss(true, grade):
    d = grade - true
    return np.where(d < 0, -d * LOSS_UNDER, d * LOSS_OVER)


def operate(df, T, cap=CAP, seed=0):
    """신뢰도 T 이상은 간이 승인, 미만은 정밀 판독(검사관 보정). 정밀 판독 한도를 넘으면 신뢰도가 낮은 순서대로만 정밀 판독한다."""
    rng = np.random.default_rng(seed)
    n = len(df)
    full = (df["conf"] < T).values
    if full.sum() > cap:
        order = np.argsort(df["conf"].values)
        full = np.zeros(n, bool); full[order[:cap]] = True
    final = df["ai"].values.copy()
    err = rng.random(n) < P_HUMAN
    human = np.clip(df["true"].values + np.where(err, rng.choice([-1, 1], n), 0), 1, 3)
    final[full] = human[full]
    wrong_ai = (df["ai"].values != df["true"].values) & ~full
    caught = wrong_ai & (rng.random(n) < P_CATCH)
    final[caught] = df["true"].values[caught]
    cost = full.sum() * C_FULL + (~full).sum() * C_QUICK + n * C_AI + loss(df["true"].values, final).sum()
    return cost, full.mean(), (final == df["true"].values).mean(), int(((final < df["true"].values)).sum())


def practice(df, seed=0):
    """관행: 모든 사진을 검사관이 정밀 판독(한도 없음, 검사관 오류율 P_HUMAN)."""
    rng = np.random.default_rng(seed)
    err = rng.random(len(df)) < P_HUMAN
    final = np.clip(df["true"].values + np.where(err, rng.choice([-1, 1], len(df)), 0), 1, 3)
    return len(df) * C_FULL + loss(df["true"].values, final).sum(), (final == df["true"].values).mean()


rows = []
for name, df in SETS.items():
    cp, ap = practice(df)
    co, fr, ao, un = operate(df, 80)
    ai_only = len(df) * C_AI + loss(df["true"].values, df["ai"].values).sum()
    rows.append((name, len(df), cp, ai_only, co, 1 - co / cp, fr, ap, ao, un))
res = pd.DataFrame(rows, columns=["시나리오", "장수", "관행 전수 판독 비용", "AI 단독 비용(금지안)", "HITL 비용(T=80)", "절감률", "정밀 판독 비율", "관행 일치율", "HITL 일치율", "HITL 과소 판정"])
print("[1] 시나리오별 검사 운영 비용(가정 단가, 만원)")
print(res.assign(절감률=res["절감률"].map("{:.1%}".format), **{"정밀 판독 비율": res["정밀 판독 비율"].map("{:.0%}".format), "관행 일치율": res["관행 일치율"].map("{:.1%}".format), "HITL 일치율": res["HITL 일치율"].map("{:.1%}".format)}).round(1).to_string(index=False))
r0 = res.iloc[0]
passed = [f"{r['시나리오']} {r['절감률']:.1%}" for _, r in res.iterrows() if r["절감률"] >= .15]
print(f"    평상 절감 {r0['절감률']:.1%} (목표 15% 이상: {'달성' if r0['절감률'] >= .15 else '미달'}), 15% 이상 달성 시나리오: {', '.join(passed)}")
print(f"    AI 단독 비용은 평상 {r0['AI 단독 비용(금지안)']:.0f}, 진흙 {res.iloc[2]['AI 단독 비용(금지안)']:.0f}로 오염 사진에서 과소 판정 손실이 폭증하므로 허용하지 않는다(모든 판정은 사람이 승인). 진흙 20%는 정밀 판독이 늘어 절감이 나지 않는다(미달).")

# ---------------- 2) 신뢰도 기준 T 탐색과 검사관 한도 ----------------
sw = []
for T in (60, 70, 80, 90, 95):
    c, fr, a, un = operate(SETS["평상(정상 조명)"], T)
    sw.append((T, c, fr, a, un))
sw = pd.DataFrame(sw, columns=["기준 T", "비용", "정밀 판독 비율", "일치율", "과소 판정"])
print("\n[2] 신뢰도 기준 T 민감도(평상 300장)\n" + sw.round(3).to_string(index=False))
best = sw.loc[sw["비용"].idxmin()]
print(f"    비용 최소 기준 T={int(best['기준 T'])}. 기준을 너무 높이면 정밀 판독이 늘어 비용이 오르고, 너무 낮으면 AI 오판이 통과한다.")
cp, _ = practice(SETS["진흙 가림 20%"])
for cap in (150, 60, 20):
    c, fr, a, un = operate(SETS["진흙 가림 20%"], 80, cap=cap)
    print(f"    진흙 20% 시나리오, 검사관 한도 {cap}장/일: 비용 {c:.0f} (관행 대비 절감 {1 - c / cp:+.1%}), 정밀 판독 {fr:.0%}, 일치율 {a:.1%}, 과소 판정 {un}장")
print("    검사관 한도가 줄면 신뢰도 낮은 사진까지 간이 승인으로 넘어가 AI 오판이 걸러지지 않아 손실이 커진다(비용 +). 오염 사진은 재촬영·사전 세척 안내로 줄여야 한다.")

# ---------------- 3) HITL 결재 워크플로우 ----------------
USERS = {"ai_bot": "AI", "ins_kim": "INS", "ins_lee": "INS", "sup_park": "SUP", "qa_choi": "QA", "aud_han": "AUD"}
PERM = {"AI": {"submit"}, "INS": {"review", "correct", "reject"}, "SUP": {"approve", "reject"}, "QA": {"approve", "reject"}, "AUD": {"read"}}


class Flow:
    def __init__(self):
        self.docs, self.log, self.blocked = {}, [], []

    def _audit(self, user, action, doc, detail):
        prev = self.log[-1]["hash"] if self.log else "GENESIS"
        rec = {"seq": len(self.log) + 1, "user": user, "action": action, "doc": doc, "detail": detail, "prev": prev}
        rec["hash"] = hashlib.sha256(json.dumps(rec, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:12]
        self.log.append(rec)

    def verify(self):
        prev = "GENESIS"
        for r in self.log:
            body = {k: v for k, v in r.items() if k != "hash"}
            if r["prev"] != prev or hashlib.sha256(json.dumps(body, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:12] != r["hash"]:
                return False, r["seq"]
            prev = r["hash"]
        return True, None

    def deny(self, user, act, doc, why):
        self.blocked.append((user, act, doc, why)); self._audit(user, "DENIED:" + act, doc, why); return False

    def submit(self, user, pid, grade, conf, parent=None):
        if "submit" not in PERM.get(USERS.get(user), set()):
            return self.deny(user, "submit", "-", "AI 판정 등록 권한 없음")
        did = f"INS{len(self.docs) + 1:02d}"
        self.docs[did] = {"photo": pid, "ai": grade, "grade": grade, "conf": conf, "status": "검사대기", "line": ["INS", "SUP"], "step": 0, "done": [], "parent": parent}
        self._audit(user, "submit", did, f"{pid} AI 등급 {GRADE_NAME[grade]} 신뢰도 {conf:.0f}")
        return did

    def decide(self, user, did, act, reason="", new_grade=None):
        role, d = USERS.get(user), self.docs.get(did)
        if role is None: return self.deny(user, act, did, "미등록 사용자")
        if d is None or d["status"] in ("확정", "반려"): return self.deny(user, act, did, "결재 대상 아님(처리 완료)")
        if act not in PERM[role]: return self.deny(user, act, did, f"{role} 역할은 {act} 불가")
        if d["line"][d["step"]] != role: return self.deny(user, act, did, "결재 순서 위반")
        if user in d["done"]: return self.deny(user, act, did, "기결재자 재결재 금지")
        if len(reason.strip()) < 10: return self.deny(user, act, did, "사유 10자 이상 필수")
        if act == "reject":
            d["status"] = "반려"
        else:
            if act == "correct":
                d["grade"] = new_grade
                if new_grade != d["ai"] and "QA" not in d["line"]:
                    d["line"] = d["line"] + ["QA"]                      # 검사관이 AI 판정을 고치면 품질보증관까지 결재
            if d["grade"] == 3 and "QA" not in d["line"]:
                d["line"] = d["line"] + ["QA"]                          # 3단계 정비 판정은 품질보증관까지 결재
            d["done"].append(user); d["step"] += 1
            d["status"] = "확정" if d["step"] == len(d["line"]) else ("감독대기" if d["step"] >= 1 else "검사대기")
        self._audit(user, act, did, reason + (f" -> {GRADE_NAME[new_grade]}" if new_grade else "")); return True

    def edit(self, user, did):
        if self.docs[did]["status"] == "확정": return self.deny(user, "edit", did, "확정 후 등급 변경 금지(재검사 등록)")
        return True


base = SETS["평상(정상 조명)"]
mix = pd.concat([base[base.conf >= 80].head(3), base[base.conf < 80].head(4), base[base.ai == 3].head(2)]).drop_duplicates("id").head(8).reset_index(drop=True)
wf = Flow()
ids = [wf.submit("ai_bot", r.id, int(r.ai), r.conf) for r in mix.itertuples()]
print(f"\n[3] AI 판정 {len(ids)}건 전부 '검사대기' 등록, 자동 확정 {sum(wf.docs[i]['status'] == '확정' for i in ids)}건 (목표 0건)")
low = [i for i, r in zip(ids, mix.itertuples()) if r.conf < 80][0]
first = ids[0]
wf.decide("ins_kim", first, "review", "AI 판정 열람, 사진과 일치 확인함")
wf.decide("sup_park", first, "approve", "검사관 의견 확인, 등급 확정")
wf.decide("ins_lee", low, "correct", "경계 부근 결함, 박스 재측정 후 등급 조정", new_grade=min(3, wf.docs[low]["ai"] + 1))
wf.decide("sup_park", low, "approve", "보정 사유 타당, 품질보증 상신")
wf.decide("qa_choi", low, "approve", "보정 근거 사진 대조 완료")
rj = ids[2]
wf.decide("ins_kim", rj, "reject", "오염 사진으로 판독 불가, 재촬영 요구")
new = wf.submit("ai_bot", mix.id[2], int(mix.ai[2]), float(mix.conf[2]), parent=rj)
tgt = ids[-1]
attacks = [("ai_bot", tgt, "review", "AI 계정이 직접 검토 처리함"), ("sup_park", tgt, "approve", "검사관 검토 없이 감독관이 승인함"), ("aud_han", tgt, "approve", "감사 계정으로 승인 시도함"),
           ("ghost", tgt, "review", "외부 계정으로 검토 시도함"), ("ins_kim", tgt, "review", ""), ("ins_kim", tgt, "correct", "짧음"), ("qa_choi", tgt, "approve", "품질보증관이 순서를 건너뛰어 승인"),
           ("ins_kim", first, "review", "이미 확정된 건을 다시 검토함"), ("sup_park", low, "reject", "확정된 건을 뒤집어 반려함")]
for u, doc, a, rs in attacks:
    wf.decide(u, doc, a, rs, new_grade=2 if a == "correct" else None)
wf.edit("ins_kim", first)
print(f"    권한 우회 시도 10건 중 차단 {len(wf.blocked)}건 (차단율 {len(wf.blocked) / 10:.0%}, 목표 100%)")
for u, a, doc, why in wf.blocked[:4]:
    print(f"      차단 {u:<9} {a:<8} {doc}: {why}")
ok, _ = wf.verify()
snap = json.loads(json.dumps(wf.log))
wf.log[3]["detail"] = "사후에 고쳐 쓴 사유"
ok2, at = wf.verify()
wf.log = snap
print(f"    감사 로그 {len(wf.log)}건 해시 체인 무결성 {'100%' if ok else '훼손'}; 4번 기록 사후 수정 시 {'통과' if ok2 else f'위변조 검출({at}번)'}")
print(f"    {low}: AI {GRADE_NAME[wf.docs[low]['ai']]} -> 검사관 보정 {GRADE_NAME[wf.docs[low]['grade']]}(보정 시 품질보증관까지 3단계 결재, 상태 {wf.docs[low]['status']}); {rj}(반려) -> {new}(재등록, parent 연결)")
print("    문서 상태:", pd.Series({k: v["status"] for k, v in wf.docs.items()}).value_counts().to_dict(), "| 최종 정비 등급은 검사관·정비감독관의 결재로 확정되며 AI는 확정 권한이 없다.")

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
x = np.arange(len(res)); ax[0].bar(x - .2, res["관행 전수 판독 비용"], .4, label="full inspection"); ax[0].bar(x + .2, res["HITL 비용(T=80)"], .4, label="HITL (T=80)")
ax[0].set_xticks(x); ax[0].set_xticklabels([f"S{i + 1}" for i in x]); ax[0].legend(); ax[0].set_title("Total cost by scenario (10k KRW)")
ax[1].plot(sw["기준 T"], sw["비용"], "o-"); ax[1].set_title("Cost vs confidence threshold T"); ax[1].set_xlabel("T")
plt.tight_layout(); plt.show()
