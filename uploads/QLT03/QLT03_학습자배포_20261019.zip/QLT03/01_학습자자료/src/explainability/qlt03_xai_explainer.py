"""장비 결함 사진을 업로드하면 결함 유형·면적·깊이·손상도·정비 등급·신뢰도와 손상 부위(박스·윤곽)를 시각화해 보여 주는 판정 인터페이스를 구현하고, 판정 건마다 근거 변수군 기여도 상위 3개를 자동 산출해 자연어 설명으로 제공한다(자동 확정 없이 검사 대기로 등록)."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.model_selection import cross_val_predict

# ---------------------------------------------------------------------------
# [교육용가상자료] 장비 외관 사진 생성기 (실제 장비·조직·위치 사진이 아니라 난수로 그린 64x64 합성 이미지)
# 도장된 금속 표면에 균열(crack)·부식(corrosion)·파손(damage)·누유(leak)를 그리고, 조명 편차와 진흙(mud) 오염을 섞는다.
# 이미지와 함께 장비 관리 기록(제원 요약)과 정답 결함 마스크·손상도·정비 등급을 만든다.
# ---------------------------------------------------------------------------
from scipy import ndimage as ndi

SZ = 64
CLASSES = ["none", "crack", "corrosion", "damage", "leak"]
KO_CLS = {"none": "결함 없음", "crack": "균열", "corrosion": "부식", "damage": "파손", "leak": "누유"}
CLS_W = {"none": 0.0, "crack": 1.4, "corrosion": 1.0, "damage": 1.6, "leak": 0.6}      # 손상도 계산용 결함 유형 가중치
GRADE_NAME = {1: "1단계 정비", 2: "2단계 정비", 3: "3단계 정비"}
YY, XX = np.mgrid[0:SZ, 0:SZ]


def grade_of(idx):
    return np.where(np.asarray(idx) >= 65, 3, np.where(np.asarray(idx) >= 35, 2, 1))


def blob(rng, cy, cx, r, rough=0.35):
    """불규칙한 원형 영역 마스크."""
    noise = ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 3)
    noise = noise / (np.abs(noise).max() + 1e-9)
    return (np.hypot(YY - cy, XX - cx) + rough * r * 2.2 * noise) < r


def draw(rng, cls, sev):
    """결함 유형·심각도 sev(0~1)에 맞는 정답 마스크와 색 정보를 만든다."""
    m = np.zeros((SZ, SZ), bool)
    if cls == "crack":
        y, x, ang = rng.uniform(12, 52), rng.uniform(12, 52), rng.uniform(0, np.pi)
        for _ in range(int(20 + 40 * sev)):
            ang += rng.normal(0, 0.35); y += np.sin(ang) * 1.2; x += np.cos(ang) * 1.2
            if 0 <= int(y) < SZ and 0 <= int(x) < SZ:
                m[int(y), int(x)] = True
        m = ndi.binary_dilation(m, iterations=1 + int(sev > 0.6))
    elif cls == "corrosion":
        for _ in range(int(rng.integers(1, 4))):
            m |= blob(rng, rng.uniform(14, 50), rng.uniform(14, 50), 3 + 9 * sev * rng.uniform(0.6, 1.1))
    elif cls == "damage":
        m = blob(rng, rng.uniform(20, 44), rng.uniform(20, 44), 6 + 12 * sev, 0.3)
    elif cls == "leak":
        x0, y0 = rng.uniform(16, 48), rng.uniform(8, 24)
        w, ln = 2 + 4 * sev, 12 + 26 * sev
        m = (np.abs(XX - x0 - 0.15 * (YY - y0)) < w * (1 - 0.4 * (YY - y0) / ln)) & (YY > y0) & (YY < y0 + ln)
    return m


def make_images(n=600, seed=0, mud=0.0, p_none=0.25, dark=False):
    """가상 외관 사진 n장(+진흙 오염 mud 비율)과 관리 기록·정답. 반환: meta(DataFrame), imgs(n,64,64,3), masks(n,64,64)."""
    rng = np.random.default_rng(seed)
    imgs, masks, rows = np.zeros((n, SZ, SZ, 3), np.float32), np.zeros((n, SZ, SZ), bool), []
    for i in range(n):
        cls = "none" if rng.random() < p_none else str(rng.choice(CLASSES[1:], p=[0.25, 0.3, 0.25, 0.2]))
        sev = 0.0 if cls == "none" else float(rng.beta(1.6, 2.0))
        base = np.array([0.42, 0.46, 0.40]) * (1 + 0.5 * ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 8)[..., None] * 3)
        img = base + rng.normal(0, 0.012, (SZ, SZ, 3))
        m = draw(rng, cls, sev)
        a = ndi.gaussian_filter(m.astype(float), 0.8)[..., None]                        # 경계를 부드럽게 섞는다
        if cls == "crack":
            col = img * rng.uniform(0.2, 0.45)
        elif cls == "corrosion":
            col = np.array([0.55, 0.30, 0.12]) * rng.uniform(0.75, 1.15) * (0.85 + 0.3 * rng.random((SZ, SZ, 1)))
        elif cls == "damage":
            col = np.ones_like(img) * np.array([0.34, 0.34, 0.36]) * (1.0 - 0.45 * sev) * rng.uniform(0.75, 1.0)
            rim = m & ~ndi.binary_erosion(m, iterations=2)
            a = np.maximum(a, 0.0); img = np.where(rim[..., None], 0.7, img)
        elif cls == "leak":
            col = np.ones_like(img) * np.array([0.10, 0.09, 0.08]) * rng.uniform(0.8, 2.6)
        else:
            col = img
        img = img * (1 - a) + col * a
        if rng.random() < 0.35:                                   # 무해한 얼룩(결함 아님): 옅은 갈색 번짐
            st = blob(rng, rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(6, 14), 0.5)
            al = ndi.gaussian_filter(st.astype(float), 2.5)[..., None] * rng.uniform(0.15, 0.4)
            img = img * (1 - al) + np.array([0.50, 0.40, 0.30]) * al
        if rng.random() < 0.3:                                    # 무해한 긴 스크래치(밝은 선)
            y0, x0, ang = rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(0, np.pi)
            for t in np.linspace(0, 25, 40):
                yy, xx = int(y0 + t * np.sin(ang)), int(x0 + t * np.cos(ang))
                if 0 <= yy < SZ and 0 <= xx < SZ:
                    img[yy, xx] = np.clip(img[yy, xx] * 1.5, 0, 1)
        if mud > 0:                                           # 진흙 오염: 결함 위를 덮을 수 있다(정답 마스크는 그대로)
            mm = np.zeros((SZ, SZ), bool)
            while mm.mean() < mud:
                mm |= blob(rng, rng.uniform(0, SZ), rng.uniform(0, SZ), rng.uniform(5, 11), 0.5)
            img[mm] = np.array([0.38, 0.30, 0.22]) * (0.85 + 0.3 * rng.random((mm.sum(), 1)))
        gain = rng.uniform(0.3, 0.55) if dark else rng.uniform(0.5, 1.15)
        ang = rng.uniform(0, 2 * np.pi)
        light = gain * (1 + 0.3 * (np.cos(ang) * (XX - 32) + np.sin(ang) * (YY - 32)) / 32)
        imgs[i] = np.clip(img * light[..., None] + rng.normal(0, 0.025, (SZ, SZ, 3)), 0, 1)
        masks[i] = m
        area = float(m.mean())
        depth = {"none": 0.0, "crack": 0.3 + 3.0 * sev, "corrosion": 0.1 + 1.5 * sev, "damage": 1.0 + 8.0 * sev, "leak": 0.0}[cls] * rng.lognormal(0, 0.1)
        idx = float(np.clip(100 * (1 - np.exp(-(CLS_W[cls] * area * 9 + 0.05 * depth))) + rng.normal(0, 1.5), 0, 100))
        rows.append({"img_id": f"IMG{seed:02d}{i:04d}", "cls": cls, "sev": sev, "area_frac": area, "depth_mm": depth, "damage_idx": idx,
                     "grade": int(grade_of(idx)), "gain": gain, "mud": mud})
    meta = pd.DataFrame(rows)
    # 장비 관리 기록(제원 요약): 사진 판정과 대조할 값
    age = rng.integers(1, 25, n)
    meta["day"] = np.sort(rng.integers(0, 90, n))
    meta["equip_type"] = rng.choice(["vehicle", "generator", "comm", "trailer"], n, p=[0.4, 0.2, 0.2, 0.2])
    meta["mfg_year"] = 2026 - age
    meta["op_hours"] = np.clip(rng.normal(180 * age, 400, n) + 8 * meta["damage_idx"], 10, 20000)
    meta["env"] = rng.choice(["coastal", "inland"], n, p=[0.3, 0.7])
    reg = np.clip(meta["grade"] + rng.choice([-1, 0, 0, 0, 0, 0, 1, 2], n), 1, 3)           # 장비 관리 기록상 직전 정비 등급
    meta["reg_grade"] = reg
    meta["emergency"] = rng.random(n) < 0.04                                               # 긴급 점검 요청(화질 불량이어도 보존)
    return meta, imgs, masks
# ---- 전처리(조명 보정·표준화)와 결함 후보 분할, 특징 추출 (cv2 대신 numpy·scipy 사용) ----
def correct(img):
    """조명 보정: 밝기에 평면(조명 기울기)을 적합해 나눈다. 어두운 결함 화소는 제외하고 두 번 반복 적합한다. 반환: 보정 밝기(정상 면 약 1), 색 비율."""
    g = img.mean(axis=2)
    A = np.c_[np.ones(SZ * SZ), XX.ravel() / SZ, YY.ravel() / SZ]
    keep = np.ones(SZ * SZ, bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(A[keep], g.ravel()[keep], rcond=None)
        plane = (A @ coef).reshape(SZ, SZ)
        keep = (np.abs(g - plane) < 0.08 * np.maximum(plane, 1e-3)).ravel()
        if keep.sum() < 200:
            keep[:] = True
    c = g / np.maximum(plane, 1e-3)
    chroma = img[..., 0] / (img.sum(axis=2) + 1e-6)
    return c, chroma


SEGP = {"dark": 0.7, "rust": 0.5, "rim": 1.45}            # 분할 임계값(어두움 보정 밝기, 붉은 비율, 밝은 테두리): 재보정 대상


def segment(img):
    """결함 후보 마스크: 어두운 영역(균열·누유·파손) + 붉은 갈색 영역(부식) + 밝은 테두리(파손)."""
    c, chroma = correct(img)
    dark = c < SEGP["dark"]
    rust = (chroma > SEGP["rust"]) & (c > 0.45)
    rim = c > SEGP["rim"]
    m = dark | rust | ndi.binary_dilation(rim, iterations=1) & ndi.binary_dilation(dark, iterations=3)
    m = ndi.binary_opening(m, structure=np.ones((2, 2))) if m.sum() > 12 else m
    return m, c, chroma, dark, rust, rim


def extract(img):
    """분할 결과와 색·모양에서 24개 특징을 만든다."""
    m, c, chroma, dark, rust, rim = segment(img)
    lab, n = ndi.label(m)
    area = float(m.sum())
    if n:
        sizes = ndi.sum(m, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        sl = ndi.find_objects(lab)[k - 1]
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        big = float(sizes.max())
        elong, fill = max(h, w) / max(min(h, w), 1), big / (h * w)
    else:
        big, elong, fill = 0.0, 1.0, 0.0
    gy, gx = np.gradient(c)
    mag = np.hypot(gx, gy)
    inside = m.sum() > 0
    return {"area_px": area, "area_frac": area / SZ ** 2, "n_comp": float(n), "big_px": big, "elong": elong, "fill": fill,
            "dark_frac": float(dark.mean()), "rust_frac": float(rust.mean()), "rim_frac": float(rim.mean()),
            "c_mean": float(c.mean()), "c_std": float(c.std()), "c_min": float(c.min()), "edge_mean": float(mag.mean()), "edge_p95": float(np.quantile(mag, 0.95)),
            "chroma_mean": float(chroma.mean()), "chroma_max": float(chroma.max()),
            "in_dark": float(c[m].mean()) if inside else 1.0, "in_chroma": float(chroma[m].mean()) if inside else float(chroma.mean()),
            "ring_contrast": float(c[ndi.binary_dilation(m, iterations=3) & ~m].mean() - c[m].mean()) if inside and (~m).any() else 0.0,
            "thin": float(1 - fill), "gain": float(img.mean()), "sat": float((img.max(axis=2) - img.min(axis=2)).mean()),
            "cy": float(ndi.center_of_mass(m)[0] / SZ) if inside else 0.5, "cx": float(ndi.center_of_mass(m)[1] / SZ) if inside else 0.5}


def feature_table(imgs):
    return pd.DataFrame([extract(im) for im in imgs])
# ---- 판정 파이프라인: 결함 유형 분류 + 손상도 회귀(분류 확률 포함) -> 정비 등급 ----
def fit_pipeline(meta, F):
    """결함 유형 분류기와 손상도 회귀기를 학습한다. 회귀기 입력의 분류 확률은 교차 예측으로 만들어 누설을 막는다."""
    clf = RandomForestClassifier(n_estimators=150, random_state=0, n_jobs=1)
    P = cross_val_predict(clf, F, meta["cls"], cv=4, method="predict_proba")
    clf.fit(F, meta["cls"])
    reg = GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.06, random_state=0).fit(np.c_[F.values, P], meta["damage_idx"])
    return {"clf": clf, "reg": reg, "cols": list(F.columns)}


def predict_pipeline(pl, F):
    X = F[pl["cols"]]
    P = pl["clf"].predict_proba(X)
    idx = np.clip(pl["reg"].predict(np.c_[X.values, P]), 0, 100)
    return pl["clf"].classes_[P.argmax(axis=1)], P, idx, P.max(axis=1)
# ---- 사진 품질 게이트: 진흙·오염 가림 추정과 판정 신뢰도 지수 ----
def mud_est(img):
    """진흙(갈색, 채도 낮은 붉은 기) 화소 비율을 추정한다. 3x3 평균으로 잡음을 줄인 뒤 색 비율로 판단하며, 실제 가림 비율보다 작게 나오지만 순서는 유지된다."""
    sm = ndi.uniform_filter(img, size=(3, 3, 1))
    s = sm.sum(axis=2) + 1e-6
    rr, gg = sm[..., 0] / s, sm[..., 1] / s
    return float(((rr > 0.385) & (rr < 0.46) & (gg < 0.325)).mean())


def confidence(P, idx, F, mud):
    """판정 신뢰도 지수 0~100 = 50 x 분류 확률 최대값 + 35 x 등급 경계까지 거리(8점에서 포화) + 15 x 사진 품질. 오염 의심(mud 추정 1% 이상)이면 상한 75로 제한한다."""
    bd = np.minimum(np.abs(idx - 35), np.abs(idx - 65))
    qual = np.clip(1.0 - np.clip(0.55 - F["gain"].values, 0, None) * 2 - np.clip(0.9 - F["c_mean"].values, 0, None), 0, 1)
    c = 50 * P.max(axis=1) + 35 * np.clip(bd / 8, 0, 1) + 15 * qual
    return np.where(np.asarray(mud) >= 0.01, np.minimum(c, 75.0), c)

mtr, itr, _ = make_images(600, seed=1)
Ftr = feature_table(itr)
pl = fit_pipeline(mtr, Ftr)
reg_p = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.07, random_state=0)
Xd = np.c_[Ftr[pl["cols"]].values, cross_val_predict(RandomForestClassifier(n_estimators=80, random_state=0, n_jobs=1), Ftr, mtr["cls"], cv=3, method="predict_proba")]
dm = mtr["depth_mm"].values > 0.2
depth_model = reg_p.fit(Xd[dm], mtr["depth_mm"].values[dm])
MM2 = 1.5 ** 2                                                    # 1화소 = 1.5mm 가정 -> 면적 mm2
GROUPS = {"결함 면적·모양": ["area_px", "area_frac", "n_comp", "big_px", "elong", "fill", "thin", "cy", "cx"], "명암 대비": ["dark_frac", "c_mean", "c_std", "c_min", "in_dark", "ring_contrast"],
          "붉은 갈색 색상": ["rust_frac", "chroma_mean", "chroma_max", "in_chroma", "sat"], "가장자리·테두리": ["edge_mean", "edge_p95", "rim_frac"], "조명 밝기": ["gain"]}
MEAN = Ftr.mean()


def contrib(F):
    """변수군을 평균값으로 대체했을 때 손상도 점수 변화(양수 = 그 변수군이 손상도를 높인 요인). 사진 여러 장을 한 번에 계산한다."""
    full = predict_pipeline(pl, F)[2]
    out = {}
    for g, cols in GROUPS.items():
        x = F.copy(); x[cols] = MEAN[cols].values
        out[g] = full - predict_pipeline(pl, x)[2]
    return pd.DataFrame(out, index=F.index)


def top3(F):
    return contrib(F).apply(lambda r: r.reindex(r.abs().sort_values(ascending=False).index)[:3].to_dict(), axis=1)


def inspect(img, pid):
    """업로드 사진 한 장을 판정한다. 결과는 항상 '검사 대기'이며 자동 확정하지 않는다."""
    F = feature_table([img])
    cls, P, idx, _ = predict_pipeline(pl, F)
    mud = mud_est(img)
    conf = float(confidence(P, idx, F, [mud])[0])
    m = segment(img)[0]
    lab, n = ndi.label(m)
    box = None
    if n:
        k = int(np.argmax(ndi.sum(m, lab, range(1, n + 1)))) + 1
        sl = ndi.find_objects(lab)[k - 1]
        box = (sl[1].start, sl[0].start, sl[1].stop - sl[1].start, sl[0].stop - sl[0].start)
    dep = float(np.clip(depth_model.predict(np.c_[F[pl["cols"]].values, P])[0], 0, None)) if cls[0] in ("crack", "corrosion", "damage") else 0.0
    if mud >= 0.03 or F["gain"].iloc[0] < 0.17:
        state = "재촬영 요구(오염·저조도)"
    elif conf >= 80:
        state = "검사 대기(신뢰도 높음, 검사관 확인 후 확정)"
    else:
        state = "검사 대기(신뢰도 낮음, 검사관 정밀 확인)"
    return {"id": pid, "cls": cls[0], "area_mm2": float(F["area_px"].iloc[0] * MM2), "depth": dep, "idx": float(idx[0]), "grade": int(grade_of(idx[0])), "conf": conf, "mud": mud, "box": box, "mask": m, "state": state, "F": F}


# ---------------- 1) 업로드 시뮬레이션: 조건이 다른 사진 8장 ----------------
mt, it, kt = make_images(300, seed=2)
mud_m, imud, kmud = make_images(30, seed=11, mud=0.2)
dark_m, idk, kdk = make_images(30, seed=12, dark=True)
picks = [("U01", it[next(i for i in range(300) if mt.cls[i] == "crack")], kt, mt, "crack"), ("U02", it[next(i for i in range(300) if mt.cls[i] == "corrosion")], kt, mt, "corrosion"),
         ("U03", it[next(i for i in range(300) if mt.cls[i] == "damage")], kt, mt, "damage"), ("U04", it[next(i for i in range(300) if mt.cls[i] == "leak")], kt, mt, "leak"),
         ("U05", it[next(i for i in range(300) if mt.cls[i] == "none")], kt, mt, "none"), ("U06", idk[0], kdk, dark_m, None), ("U07", imud[0], kmud, mud_m, None), ("U08", imud[1], kmud, mud_m, None)]
res = []
for pid, img, _, _, _ in picks:
    res.append(inspect(img, pid))
true_rows = [mt.loc[next(i for i in range(300) if mt.cls[i] == c)] for c in ("crack", "corrosion", "damage", "leak", "none")] + [dark_m.loc[0], mud_m.loc[0], mud_m.loc[1]]
tb = pd.DataFrame([{"사진": r["id"], "판정 유형": KO_CLS[r["cls"]], "실제 유형": KO_CLS[t["cls"]], "면적(mm2)": r["area_mm2"], "깊이(mm)": r["depth"], "손상도": r["idx"], "실제 손상도": t["damage_idx"],
                    "등급": GRADE_NAME[r["grade"]], "실제 등급": GRADE_NAME[int(t["grade"])], "신뢰도": r["conf"], "오염": r["mud"]} for r, t in zip(res, true_rows)])
print("[1] 업로드 판정 결과(8장, 면적은 1화소 1.5mm 가정) [교육용가상자료]")
print(tb.round(2).to_string(index=False))
for r in res:
    print(f"    {r['id']}: {r['state']}")

# ---------------- 2) 기여도 상위 3개 자동 산출(평가 150장) ----------------
mte, ite, _ = make_images(300, seed=2)
Fte = feature_table(ite)
T3 = top3(Fte)
ok = int(sum(len(t) == 3 and all(np.isfinite(v) for v in t.values()) for t in T3))
texts = list(T3)
print(f"\n[2] 평가 {len(ite)}장 중 기여도 상위 3개 요인 자동 산출 {ok}건 ({ok / len(ite):.0%}, 목표 100%)")
avg = pd.DataFrame(texts).abs().mean().sort_values(ascending=False)
print("    변수군별 평균 기여 크기(손상도 점):", ", ".join(f"{k} {v:.1f}" for k, v in avg.items()))


def explain(r):
    t3 = top3(r["F"]).iloc[0]
    why = {"결함 면적·모양": ("결함 면적·모양이 평균보다 커서", "결함 면적·모양이 평균보다 작아"), "명암 대비": ("표면과 크게 다른 어두운 영역이 있어", "어두운 영역이 적어"),
           "붉은 갈색 색상": ("붉은 갈색 부식 색상이 넓어", "붉은 갈색 색상이 적어"), "가장자리·테두리": ("뚜렷한 테두리가 있어", "테두리 단서가 약해"), "조명 밝기": ("조명 밝기 영향으로", "조명 밝기 영향으로")}
    main = list(t3)[0]
    return f"{r['id']}: {why[main][t3[main] < 0]} 손상도 {r['idx']:.0f}점({GRADE_NAME[r['grade']]}) 판정. 주요 요인 " + ", ".join(f"{g}({v:+.1f}점)" for g, v in t3.items())


print("[3] 판정 근거 자연어 설명(결함 있는 3장)")
for r in (res[0], res[1], res[2]):
    print("   -", explain(r))

# ---------------- 3) 손상 부위 시각화 정확도: 박스와 정답 마스크 겹침 ----------------
ious = []
for r, (pid, img, kk, mm, _) in zip(res[:4], picks[:4]):
    i = next(j for j in range(300) if mt.cls[j] == {"U01": "crack", "U02": "corrosion", "U03": "damage", "U04": "leak"}[pid])
    gt = kk[i]
    ious.append((pid, (r["mask"] & gt).sum() / max((r["mask"] | gt).sum(), 1)))
print("[4] 손상 부위 표시와 정답 마스크의 IoU:", ", ".join(f"{p} {v:.2f}" for p, v in ious))
print("    화면은 자동 확정 버튼 없이 '검사 대기 등록'만 제공하며, 최종 정비 등급은 검사관이 확정한다(M7).")

fig, ax = plt.subplots(2, 4, figsize=(14, 7))
for a, (pid, img, _, _, _), r in zip(ax.ravel(), picks, res):
    a.imshow(img)
    a.contour(r["mask"], levels=[0.5], colors="yellow", linewidths=1)
    if r["box"]:
        x, y, w, h = r["box"]; a.add_patch(plt.Rectangle((x - .5, y - .5), w, h, fill=False, ec="red", lw=1.5))
    a.set_title(f"{pid} {r['cls']} idx {r['idx']:.0f} grade {r['grade']} conf {r['conf']:.0f}", fontsize=9); a.axis("off")
plt.suptitle("Upload inspection view (synthetic photos): yellow = defect region, red = box"); plt.tight_layout(); plt.show()
