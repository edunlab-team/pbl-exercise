"""손상도 점수 회귀와 결함 유형 확률로 정비 등급(1단계 정비·2단계 정비·3단계 정비)을 자동 분류하고, 분류 확률·등급 경계까지의 거리·사진 품질로 판정 신뢰도 지수(0~100)를 산출하는 엔진을 만들어 기준 모델 대비 MAE·RMSE 개선과 신뢰도 보정, 저조도·진흙 사진 등 불규칙 상황에서의 안정성을 검증한다."""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import r2_score, confusion_matrix

# ---------------------------------------------------------------------------
# [교육용가상자료] 장비 외관 사진 생성기 (실제 장비·조직·위치 사진이 아니라 난수로 그린 64x64 합성 이미지)
# 도장된 금속 표면에 균열(crack)·부식(corrosion)·파손(damage)·누유(leak)를 그리고, 조명 편차와 진흙(mud) 오염을 섞는다.
# 이미지와 함께 장비 관리 기록(제원 요약)과 정답 결함 마스크·손상도·정비 등급을 만든다.
# ---------------------------------------------------------------------------
from scipy import ndimage as ndi

SZ = 64
CLASSES = ["none", "crack", "corrosion", "damage", "leak"]
KO_CLS = {"none": "결함 없음", "crack": "균열", "corrosion": "부식", "damage": "파손", "leak": "누유"}
CLS_W = {"none": 0.0, "crack": 1.4, "corrosion": 1.0, "damage": 1.6, "leak": 0.6}      # 손상도 계산용 결함 유형 가중치
GRADE_NAME = {1: "1단계 정비", 2: "2단계 정비", 3: "3단계 정비"}
YY, XX = np.mgrid[0:SZ, 0:SZ]


def grade_of(idx):
    return np.where(np.asarray(idx) >= 65, 3, np.where(np.asarray(idx) >= 35, 2, 1))


def blob(rng, cy, cx, r, rough=0.35):
    """불규칙한 원형 영역 마스크."""
    noise = ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 3)
    noise = noise / (np.abs(noise).max() + 1e-9)
    return (np.hypot(YY - cy, XX - cx) + rough * r * 2.2 * noise) < r


def draw(rng, cls, sev):
    """결함 유형·심각도 sev(0~1)에 맞는 정답 마스크와 색 정보를 만든다."""
    m = np.zeros((SZ, SZ), bool)
    if cls == "crack":
        y, x, ang = rng.uniform(12, 52), rng.uniform(12, 52), rng.uniform(0, np.pi)
        for _ in range(int(20 + 40 * sev)):
            ang += rng.normal(0, 0.35); y += np.sin(ang) * 1.2; x += np.cos(ang) * 1.2
            if 0 <= int(y) < SZ and 0 <= int(x) < SZ:
                m[int(y), int(x)] = True
        m = ndi.binary_dilation(m, iterations=1 + int(sev > 0.6))
    elif cls == "corrosion":
        for _ in range(int(rng.integers(1, 4))):
            m |= blob(rng, rng.uniform(14, 50), rng.uniform(14, 50), 3 + 9 * sev * rng.uniform(0.6, 1.1))
    elif cls == "damage":
        m = blob(rng, rng.uniform(20, 44), rng.uniform(20, 44), 6 + 12 * sev, 0.3)
    elif cls == "leak":
        x0, y0 = rng.uniform(16, 48), rng.uniform(8, 24)
        w, ln = 2 + 4 * sev, 12 + 26 * sev
        m = (np.abs(XX - x0 - 0.15 * (YY - y0)) < w * (1 - 0.4 * (YY - y0) / ln)) & (YY > y0) & (YY < y0 + ln)
    return m


def make_images(n=600, seed=0, mud=0.0, p_none=0.25, dark=False):
    """가상 외관 사진 n장(+진흙 오염 mud 비율)과 관리 기록·정답. 반환: meta(DataFrame), imgs(n,64,64,3), masks(n,64,64)."""
    rng = np.random.default_rng(seed)
    imgs, masks, rows = np.zeros((n, SZ, SZ, 3), np.float32), np.zeros((n, SZ, SZ), bool), []
    for i in range(n):
        cls = "none" if rng.random() < p_none else str(rng.choice(CLASSES[1:], p=[0.25, 0.3, 0.25, 0.2]))
        sev = 0.0 if cls == "none" else float(rng.beta(1.6, 2.0))
        base = np.array([0.42, 0.46, 0.40]) * (1 + 0.5 * ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 8)[..., None] * 3)
        img = base + rng.normal(0, 0.012, (SZ, SZ, 3))
        m = draw(rng, cls, sev)
        a = ndi.gaussian_filter(m.astype(float), 0.8)[..., None]                        # 경계를 부드럽게 섞는다
        if cls == "crack":
            col = img * rng.uniform(0.2, 0.45)
        elif cls == "corrosion":
            col = np.array([0.55, 0.30, 0.12]) * rng.uniform(0.75, 1.15) * (0.85 + 0.3 * rng.random((SZ, SZ, 1)))
        elif cls == "damage":
            col = np.ones_like(img) * np.array([0.34, 0.34, 0.36]) * (1.0 - 0.45 * sev) * rng.uniform(0.75, 1.0)
            rim = m & ~ndi.binary_erosion(m, iterations=2)
            a = np.maximum(a, 0.0); img = np.where(rim[..., None], 0.7, img)
        elif cls == "leak":
            col = np.ones_like(img) * np.array([0.10, 0.09, 0.08]) * rng.uniform(0.8, 2.6)
        else:
            col = img
        img = img * (1 - a) + col * a
        if rng.random() < 0.35:                                   # 무해한 얼룩(결함 아님): 옅은 갈색 번짐
            st = blob(rng, rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(6, 14), 0.5)
            al = ndi.gaussian_filter(st.astype(float), 2.5)[..., None] * rng.uniform(0.15, 0.4)
            img = img * (1 - al) + np.array([0.50, 0.40, 0.30]) * al
        if rng.random() < 0.3:                                    # 무해한 긴 스크래치(밝은 선)
            y0, x0, ang = rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(0, np.pi)
            for t in np.linspace(0, 25, 40):
                yy, xx = int(y0 + t * np.sin(ang)), int(x0 + t * np.cos(ang))
                if 0 <= yy < SZ and 0 <= xx < SZ:
                    img[yy, xx] = np.clip(img[yy, xx] * 1.5, 0, 1)
        if mud > 0:                                           # 진흙 오염: 결함 위를 덮을 수 있다(정답 마스크는 그대로)
            mm = np.zeros((SZ, SZ), bool)
            while mm.mean() < mud:
                mm |= blob(rng, rng.uniform(0, SZ), rng.uniform(0, SZ), rng.uniform(5, 11), 0.5)
            img[mm] = np.array([0.38, 0.30, 0.22]) * (0.85 + 0.3 * rng.random((mm.sum(), 1)))
        gain = rng.uniform(0.3, 0.55) if dark else rng.uniform(0.5, 1.15)
        ang = rng.uniform(0, 2 * np.pi)
        light = gain * (1 + 0.3 * (np.cos(ang) * (XX - 32) + np.sin(ang) * (YY - 32)) / 32)
        imgs[i] = np.clip(img * light[..., None] + rng.normal(0, 0.025, (SZ, SZ, 3)), 0, 1)
        masks[i] = m
        area = float(m.mean())
        depth = {"none": 0.0, "crack": 0.3 + 3.0 * sev, "corrosion": 0.1 + 1.5 * sev, "damage": 1.0 + 8.0 * sev, "leak": 0.0}[cls] * rng.lognormal(0, 0.1)
        idx = float(np.clip(100 * (1 - np.exp(-(CLS_W[cls] * area * 9 + 0.05 * depth))) + rng.normal(0, 1.5), 0, 100))
        rows.append({"img_id": f"IMG{seed:02d}{i:04d}", "cls": cls, "sev": sev, "area_frac": area, "depth_mm": depth, "damage_idx": idx,
                     "grade": int(grade_of(idx)), "gain": gain, "mud": mud})
    meta = pd.DataFrame(rows)
    # 장비 관리 기록(제원 요약): 사진 판정과 대조할 값
    age = rng.integers(1, 25, n)
    meta["day"] = np.sort(rng.integers(0, 90, n))
    meta["equip_type"] = rng.choice(["vehicle", "generator", "comm", "trailer"], n, p=[0.4, 0.2, 0.2, 0.2])
    meta["mfg_year"] = 2026 - age
    meta["op_hours"] = np.clip(rng.normal(180 * age, 400, n) + 8 * meta["damage_idx"], 10, 20000)
    meta["env"] = rng.choice(["coastal", "inland"], n, p=[0.3, 0.7])
    reg = np.clip(meta["grade"] + rng.choice([-1, 0, 0, 0, 0, 0, 1, 2], n), 1, 3)           # 장비 관리 기록상 직전 정비 등급
    meta["reg_grade"] = reg
    meta["emergency"] = rng.random(n) < 0.04                                               # 긴급 점검 요청(화질 불량이어도 보존)
    return meta, imgs, masks
# ---- 전처리(조명 보정·표준화)와 결함 후보 분할, 특징 추출 (cv2 대신 numpy·scipy 사용) ----
def correct(img):
    """조명 보정: 밝기에 평면(조명 기울기)을 적합해 나눈다. 어두운 결함 화소는 제외하고 두 번 반복 적합한다. 반환: 보정 밝기(정상 면 약 1), 색 비율."""
    g = img.mean(axis=2)
    A = np.c_[np.ones(SZ * SZ), XX.ravel() / SZ, YY.ravel() / SZ]
    keep = np.ones(SZ * SZ, bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(A[keep], g.ravel()[keep], rcond=None)
        plane = (A @ coef).reshape(SZ, SZ)
        keep = (np.abs(g - plane) < 0.08 * np.maximum(plane, 1e-3)).ravel()
        if keep.sum() < 200:
            keep[:] = True
    c = g / np.maximum(plane, 1e-3)
    chroma = img[..., 0] / (img.sum(axis=2) + 1e-6)
    return c, chroma


SEGP = {"dark": 0.7, "rust": 0.5, "rim": 1.45}            # 분할 임계값(어두움 보정 밝기, 붉은 비율, 밝은 테두리): 재보정 대상


def segment(img):
    """결함 후보 마스크: 어두운 영역(균열·누유·파손) + 붉은 갈색 영역(부식) + 밝은 테두리(파손)."""
    c, chroma = correct(img)
    dark = c < SEGP["dark"]
    rust = (chroma > SEGP["rust"]) & (c > 0.45)
    rim = c > SEGP["rim"]
    m = dark | rust | ndi.binary_dilation(rim, iterations=1) & ndi.binary_dilation(dark, iterations=3)
    m = ndi.binary_opening(m, structure=np.ones((2, 2))) if m.sum() > 12 else m
    return m, c, chroma, dark, rust, rim


def extract(img):
    """분할 결과와 색·모양에서 24개 특징을 만든다."""
    m, c, chroma, dark, rust, rim = segment(img)
    lab, n = ndi.label(m)
    area = float(m.sum())
    if n:
        sizes = ndi.sum(m, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        sl = ndi.find_objects(lab)[k - 1]
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        big = float(sizes.max())
        elong, fill = max(h, w) / max(min(h, w), 1), big / (h * w)
    else:
        big, elong, fill = 0.0, 1.0, 0.0
    gy, gx = np.gradient(c)
    mag = np.hypot(gx, gy)
    inside = m.sum() > 0
    return {"area_px": area, "area_frac": area / SZ ** 2, "n_comp": float(n), "big_px": big, "elong": elong, "fill": fill,
            "dark_frac": float(dark.mean()), "rust_frac": float(rust.mean()), "rim_frac": float(rim.mean()),
            "c_mean": float(c.mean()), "c_std": float(c.std()), "c_min": float(c.min()), "edge_mean": float(mag.mean()), "edge_p95": float(np.quantile(mag, 0.95)),
            "chroma_mean": float(chroma.mean()), "chroma_max": float(chroma.max()),
            "in_dark": float(c[m].mean()) if inside else 1.0, "in_chroma": float(chroma[m].mean()) if inside else float(chroma.mean()),
            "ring_contrast": float(c[ndi.binary_dilation(m, iterations=3) & ~m].mean() - c[m].mean()) if inside and (~m).any() else 0.0,
            "thin": float(1 - fill), "gain": float(img.mean()), "sat": float((img.max(axis=2) - img.min(axis=2)).mean()),
            "cy": float(ndi.center_of_mass(m)[0] / SZ) if inside else 0.5, "cx": float(ndi.center_of_mass(m)[1] / SZ) if inside else 0.5}


def feature_table(imgs):
    return pd.DataFrame([extract(im) for im in imgs])
# ---- 판정 파이프라인: 결함 유형 분류 + 손상도 회귀(분류 확률 포함) -> 정비 등급 ----
def fit_pipeline(meta, F):
    """결함 유형 분류기와 손상도 회귀기를 학습한다. 회귀기 입력의 분류 확률은 교차 예측으로 만들어 누설을 막는다."""
    clf = RandomForestClassifier(n_estimators=150, random_state=0, n_jobs=1)
    P = cross_val_predict(clf, F, meta["cls"], cv=4, method="predict_proba")
    clf.fit(F, meta["cls"])
    reg = GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.06, random_state=0).fit(np.c_[F.values, P], meta["damage_idx"])
    return {"clf": clf, "reg": reg, "cols": list(F.columns)}


def predict_pipeline(pl, F):
    X = F[pl["cols"]]
    P = pl["clf"].predict_proba(X)
    idx = np.clip(pl["reg"].predict(np.c_[X.values, P]), 0, 100)
    return pl["clf"].classes_[P.argmax(axis=1)], P, idx, P.max(axis=1)
# ---- 사진 품질 게이트: 진흙·오염 가림 추정과 판정 신뢰도 지수 ----
def mud_est(img):
    """진흙(갈색, 채도 낮은 붉은 기) 화소 비율을 추정한다. 3x3 평균으로 잡음을 줄인 뒤 색 비율로 판단하며, 실제 가림 비율보다 작게 나오지만 순서는 유지된다."""
    sm = ndi.uniform_filter(img, size=(3, 3, 1))
    s = sm.sum(axis=2) + 1e-6
    rr, gg = sm[..., 0] / s, sm[..., 1] / s
    return float(((rr > 0.385) & (rr < 0.46) & (gg < 0.325)).mean())


def confidence(P, idx, F, mud):
    """판정 신뢰도 지수 0~100 = 50 x 분류 확률 최대값 + 35 x 등급 경계까지 거리(8점에서 포화) + 15 x 사진 품질. 오염 의심(mud 추정 1% 이상)이면 상한 75로 제한한다."""
    bd = np.minimum(np.abs(idx - 35), np.abs(idx - 65))
    qual = np.clip(1.0 - np.clip(0.55 - F["gain"].values, 0, None) * 2 - np.clip(0.9 - F["c_mean"].values, 0, None), 0, 1)
    c = 50 * P.max(axis=1) + 35 * np.clip(bd / 8, 0, 1) + 15 * qual
    return np.where(np.asarray(mud) >= 0.01, np.minimum(c, 75.0), c)

mtr, itr, _ = make_images(600, seed=1)
mte, ite, _ = make_images(300, seed=2)
Ftr, Fte = feature_table(itr), feature_table(ite)
pl = fit_pipeline(mtr, Ftr)


def hist_feat(imgs):
    """기준 모델(M3) 특징: 밝기 히스토그램 16칸 + 채널 평균 비율 3 + 변동계수 1."""
    out = []
    for im in imgs:
        g = im.mean(axis=2)
        h, _ = np.histogram(g / max(g.max(), 1e-3), bins=16, range=(0, 1))
        out.append(np.r_[h / g.size, im.mean(axis=(0, 1)) / max(g.mean(), 1e-3), g.std() / max(g.mean(), 1e-3)])
    return np.array(out)


base = LinearRegression().fit(hist_feat(itr), mtr["damage_idx"])
rm = lambda y, p: float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))


# ---------------- 1) 평가 300장: 기준 모델 vs 제안 엔진 ----------------
cls, P, idx, _ = predict_pipeline(pl, Fte)
y = mte["damage_idx"].values
bp = np.clip(base.predict(hist_feat(ite)), 0, 100)
tab = pd.DataFrame({"기준(밝기 히스토그램 회귀)": [np.mean(np.abs(y - bp)), rm(y, bp), r2_score(y, bp)], "제안(분할 특징+유형 확률)": [np.mean(np.abs(y - idx)), rm(y, idx), r2_score(y, idx)]}, index=["MAE", "RMSE", "R2"])
print("[1] 손상도 점수 예측 성능(평가 300장)\n" + tab.round(3).to_string())
b, e = tab.iloc[:, 0], tab.iloc[:, 1]
ok = 1 - e["MAE"] / b["MAE"] >= .2 and 1 - e["RMSE"] / b["RMSE"] >= .2
print(f"    MAE 개선 {1 - e['MAE'] / b['MAE']:.1%}, RMSE 개선 {1 - e['RMSE'] / b['RMSE']:.1%} (목표 20% 이상: {'달성' if ok else '미달'}), R2 {e['R2']:.3f} (목표 0.85 이상: {'달성' if e['R2'] >= .85 else '미달'})")

# ---------------- 2) 정비 등급 분류 ----------------
g_true, g_pred = mte["grade"].values, grade_of(idx)
cm = pd.DataFrame(confusion_matrix(g_true, g_pred, labels=[1, 2, 3]), index=[f"실제 {GRADE_NAME[i]}" for i in (1, 2, 3)], columns=[f"판정 {GRADE_NAME[i]}" for i in (1, 2, 3)])
under = int(((g_pred < g_true)).sum())
print(f"\n[2] 정비 등급 판정: 일치율 {(g_true == g_pred).mean():.1%}, 한 단계 이내 {(np.abs(g_true - g_pred) <= 1).mean():.1%}, 과소 판정(실제보다 낮게) {under}장, 과대 판정 {int((g_pred > g_true).sum())}장\n" + cm.to_string())
print("    3단계 정비를 현장·현장으로 낮추는 과소 판정이 가장 위험하므로 경계 부근은 신뢰도로 걸러 검사관이 확인한다.")

# ---------------- 3) 판정 신뢰도 지수 보정 ----------------
mud_te = np.array([mud_est(im) for im in ite])
conf = confidence(P, idx, Fte, mud_te)
bins = pd.cut(conf, [0, 70, 80, 90, 101], labels=["70 미만", "70~80", "80~90", "90 이상"])
cal = pd.DataFrame({"bin": bins, "ok": g_true == g_pred, "near": np.abs(g_true - g_pred) <= 1}).groupby("bin", observed=True).agg(건수=("ok", "size"), 일치율=("ok", "mean"), 한단계이내=("near", "mean"))
print("\n[3] 신뢰도 지수 구간별 실제 일치율(높은 신뢰도일수록 높아야 한다)\n" + cal.round(3).to_string())
hi = conf >= 80
print(f"    신뢰도 80 이상 자동 통과 {hi.sum()}장({hi.mean():.0%}): 일치율 {(g_true == g_pred)[hi].mean():.1%} / 80 미만 {(~hi).sum()}장은 검사관 확인 대상(일치율 {(g_true == g_pred)[~hi].mean():.1%})")

# ---------------- 4) 불규칙 상황: 저조도, 진흙 가림, 작은 결함 ----------------
rows = []
for name, kw in [("정상 조명", dict(seed=2)), ("저조도", dict(seed=7, dark=True)), ("진흙 20% 가림", dict(seed=8, mud=0.2)), ("진흙 35% 가림", dict(seed=9, mud=0.35))]:
    mm, ii = (mte, ite) if name == "정상 조명" else make_images(150, **kw)[:2]
    FF = Fte if name == "정상 조명" else feature_table(ii)
    c2, P2, i2, _ = predict_pipeline(pl, FF)
    cf = confidence(P2, i2, FF, [mud_est(im) for im in ii])
    yy = mm["damage_idx"].values
    gg, gp = mm["grade"].values, grade_of(i2)
    rows.append((name, len(mm), np.mean(np.abs(yy - np.clip(base.predict(hist_feat(ii)), 0, 100))), np.mean(np.abs(yy - i2)), (gg == gp).mean(), cf.mean(), (gg == gp)[cf >= 80].mean() if (cf >= 80).any() else np.nan, (cf >= 80).mean()))
ir = pd.DataFrame(rows, columns=["조건", "장수", "기준 MAE", "제안 MAE", "등급 일치율", "평균 신뢰도", "신뢰도 80 이상 일치율", "80 이상 비율"])
print("\n[4] 불규칙 상황별 성능(- 는 해당 사진 없음)\n" + ir.round(2).to_string(index=False, na_rep="-"))
print("    진흙 가림이 커지면 오차와 과소 판정이 늘고 평균 신뢰도가 떨어진다. 이런 사진은 재촬영 요구 또는 검사관 확인으로 보낸다.")
print("    등급은 정비 소요의 1차 판정이며, 최종 정비 등급은 검사관이 확정한다(M7). 사진은 교육용 가상 자료이다.")
