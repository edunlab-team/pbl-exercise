# coding: utf-8
"""Distributed runtime: actual execution, plot export and evidence checks; no teacher answers."""
from pathlib import Path
import contextlib, io, json, re, runpy, sys, hashlib, platform, datetime, shutil, traceback
ROOT = Path(__file__).resolve().parent.parent

def execute(mission, variant=False):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    stem = f'm{mission:02d}'
    source = ROOT / ('work' if variant else 'src') / (stem + ('_challenge.py' if variant else '.py'))
    folder = ROOT / 'outputs' / stem / ('challenge' if variant else 'baseline')
    if folder.exists():
        archive=ROOT/'outputs/history'/stem/(folder.name+'-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
        archive.parent.mkdir(parents=True,exist_ok=True)
        shutil.move(str(folder),str(archive))
    folder.mkdir(parents=True, exist_ok=True)
    if not variant:
        checks=json.loads((ROOT/'configs/checks.json').read_text(encoding='utf-8'))[str(mission)]
        for alias in checks.get('aliases',[]):
            dest=ROOT/alias
            dest.parent.mkdir(parents=True,exist_ok=True)
            if not dest.exists():
                dest.write_bytes(source.read_bytes())
            elif dest.read_bytes()!=source.read_bytes():
                print('기존 원문 산출물 파일을 보존했습니다:',alias,'; 제출 전 baseline/work 중 의도한 코드와 대조하세요.')
    figures = []
    def save_figures(*args, **kwargs):
        for number in plt.get_fignums():
            dest = folder / f'figure_{len(figures)+1:02d}.png'
            plt.figure(number).savefig(dest, dpi=110, bbox_inches='tight')
            figures.append(str(dest.relative_to(ROOT)))
        plt.close('all')
    old_show = plt.show
    plt.show = save_figures
    out, err = io.StringIO(), io.StringIO()
    ok = False
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            runpy.run_path(str(source), run_name='__main__')
            save_figures()
        ok = True
    except BaseException:
        traceback.print_exc(file=err)
        raise
    finally:
        plt.show = old_show
        plt.close('all')
        (folder/'stdout.txt').write_text(out.getvalue(), encoding='utf-8')
        (folder/'stderr.txt').write_text(err.getvalue(), encoding='utf-8')
        meta = dict(completed=ok, source=str(source.relative_to(ROOT)), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), python=platform.python_version(), timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(), figures=figures)
        (folder/'execution.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print(out.getvalue())
    for f in figures: print('그래프 파일:', f)
    return folder

def check_baseline(mission):
    spec = json.loads((ROOT/'configs/checks.json').read_text(encoding='utf-8'))[str(mission)]
    folder=ROOT/'outputs'/f'm{mission:02d}'/'baseline'
    meta=json.loads((folder/'execution.json').read_text(encoding='utf-8'))
    assert meta['completed'], '실행이 완료되지 않았습니다. 오류를 먼저 확인하세요.'
    source=ROOT/meta['source']
    assert meta['source_sha256']==hashlib.sha256(source.read_bytes()).hexdigest(), '실행 후 코드가 변경되었습니다. 다시 실행하세요.'
    stdout=(folder/'stdout.txt').read_text(encoding='utf-8')
    missing=[p for p in spec['patterns'] if not re.search(p,stdout)]
    assert not missing, '기본 실행 확인 지표 불일치: '+repr(missing)+'; 원문 예시/환경/수정 이력을 대조하세요.'
    print('기본 실행 확인 PASS — 도전 과제 및 해석 완료 판정은 별도입니다.')
    return stdout

def check_action(mission):
    spec=json.loads((ROOT/'configs/checks.json').read_text(encoding='utf-8'))[str(mission)]
    if spec['explanation_only']:
        print('설명형 도전: 코드 변경 대신 기록지의 근거와 해석을 확인하세요.')
        return
    folder=ROOT/'outputs'/f'm{mission:02d}'/'challenge'
    assert (folder/'execution.json').exists(), '도전 코드를 수정하고 실행하세요.'
    meta=json.loads((folder/'execution.json').read_text(encoding='utf-8'))
    assert meta['completed'], '도전 실행이 완료되지 않았습니다.'
    target=ROOT/meta['source']
    assert hashlib.sha256(target.read_bytes()).hexdigest()==meta['source_sha256'], '수정 후 재실행이 필요합니다.'
    base=ROOT/'src'/f'm{mission:02d}.py'
    # AST comparison ignores cosmetic comments/whitespace while accepting valid independent solutions.
    import ast
    assert ast.dump(ast.parse(target.read_text(encoding='utf-8')))!=ast.dump(ast.parse(base.read_text(encoding='utf-8'))), '주석만 바꾼 상태입니다. 도전 과제의 설정 또는 로직을 수정하세요.'
    print('수정·재실행 증빙 확인 — 요구한 변경의 적합성과 해석은 채점자가 확인합니다. 출력 동일도 허용합니다.')

if __name__=='__main__':
    mission=int(sys.argv[1]); mode=sys.argv[2] if len(sys.argv)>2 else 'run'
    if mode=='run':execute(mission)
    elif mode=='challenge':execute(mission, True)
    elif mode=='check':check_baseline(mission)
    elif mode=='action':check_action(mission)
    else:raise SystemExit('unknown mode')
