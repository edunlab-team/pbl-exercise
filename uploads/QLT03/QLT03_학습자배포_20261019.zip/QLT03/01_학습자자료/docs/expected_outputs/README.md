# 기대 출력과 적용 기준

M9 현재 채점 기준은 `m09_revised_expected.txt`입니다. `m09_expected.txt`는 원문 보존 적용 기준 부록이며 현재 채점값이 아닙니다. 원문 값과 수정 이유는 `../M09_ROI_정오표.md`를 읽습니다. 다른 원문 기대 출력도 실측을 대신하지 않습니다.

- m09_expected.txt: 원문 예시(역사 비교용). 현재 비교는 m09_revised_expected.txt 및 적용 기준을 사용합니다.
