from pathlib import Path
import contextlib, io, runpy, json, hashlib, sys, datetime, shutil
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = Path(__file__).resolve().parents[1]
n = int(sys.argv[1])
source = ROOT / "work/revised" / f"m{n:02d}.py"
folder = ROOT / "outputs" / f"m{n:02d}" / "revised"
if folder.exists():
    archive = ROOT / "outputs/history" / f"m{n:02d}" / ("revised-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
    archive.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(folder), str(archive))
folder.mkdir(parents=True)
figures = []
def save(*args, **kwargs):
    for number in plt.get_fignums():
        dest = folder / f"figure_{len(figures)+1:02d}.png"
        plt.figure(number).savefig(dest, dpi=110, bbox_inches="tight")
        figures.append(str(dest.relative_to(ROOT)))
    plt.close("all")
plt.show = save
out, err = io.StringIO(), io.StringIO()
ok = False
try:
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        data = runpy.run_path(str(source), run_name="__main__")
        save()
        if n == 10:
            assert all(v == 0 for v in data["intersections"].values())
            assert len(data["y"]) == 240
        print("수정 실습 실행 확인 PASS — 성능 목표 달성·학습자 수행 완료는 별도")
    ok = True
finally:
    (folder/"stdout.txt").write_text(out.getvalue(), encoding="utf-8")
    (folder/"stderr.txt").write_text(err.getvalue(), encoding="utf-8")
    (folder/"execution.json").write_text(json.dumps(dict(completed=ok, timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=str(source.relative_to(ROOT)), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), figures=figures), ensure_ascii=False, indent=2), encoding="utf-8")
print(out.getvalue())
