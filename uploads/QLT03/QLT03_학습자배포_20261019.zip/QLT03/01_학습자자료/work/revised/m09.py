# 수정 실습본: 원문 코드는 별도 보존합니다.
"""운영 기간 외관 판정 로그로 AAR을 수행해 오판 사례를 원인별(오염 가림·저조도·작은 결함·경계 근처·유형 혼동)로 분류하고, 분할 임계값·학습 데이터·등급 경계(과소 판정 손실 반영)를 재보정해 보류 구간에서 개선을 검증한 뒤 비용 절감액·시간 단축률·투자 회수 기간 3대 효과 지표를 산식과 민감도로 산출한다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.model_selection import cross_val_predict

# ---------------------------------------------------------------------------
# [교육용가상자료] 장비 외관 사진 생성기 (실제 장비·조직·위치 사진이 아니라 난수로 그린 64x64 합성 이미지)
# 도장된 금속 표면에 균열(crack)·부식(corrosion)·파손(damage)·누유(leak)를 그리고, 조명 편차와 진흙(mud) 오염을 섞는다.
# 이미지와 함께 장비 관리 기록(제원 요약)과 정답 결함 마스크·손상도·정비 등급을 만든다.
# ---------------------------------------------------------------------------
from scipy import ndimage as ndi

SZ = 64
CLASSES = ["none", "crack", "corrosion", "damage", "leak"]
KO_CLS = {"none": "결함 없음", "crack": "균열", "corrosion": "부식", "damage": "파손", "leak": "누유"}
CLS_W = {"none": 0.0, "crack": 1.4, "corrosion": 1.0, "damage": 1.6, "leak": 0.6}      # 손상도 계산용 결함 유형 가중치
GRADE_NAME = {1: "1단계 정비", 2: "2단계 정비", 3: "3단계 정비"}
YY, XX = np.mgrid[0:SZ, 0:SZ]


def grade_of(idx):
    return np.where(np.asarray(idx) >= 65, 3, np.where(np.asarray(idx) >= 35, 2, 1))


def blob(rng, cy, cx, r, rough=0.35):
    """불규칙한 원형 영역 마스크."""
    noise = ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 3)
    noise = noise / (np.abs(noise).max() + 1e-9)
    return (np.hypot(YY - cy, XX - cx) + rough * r * 2.2 * noise) < r


def draw(rng, cls, sev):
    """결함 유형·심각도 sev(0~1)에 맞는 정답 마스크와 색 정보를 만든다."""
    m = np.zeros((SZ, SZ), bool)
    if cls == "crack":
        y, x, ang = rng.uniform(12, 52), rng.uniform(12, 52), rng.uniform(0, np.pi)
        for _ in range(int(20 + 40 * sev)):
            ang += rng.normal(0, 0.35); y += np.sin(ang) * 1.2; x += np.cos(ang) * 1.2
            if 0 <= int(y) < SZ and 0 <= int(x) < SZ:
                m[int(y), int(x)] = True
        m = ndi.binary_dilation(m, iterations=1 + int(sev > 0.6))
    elif cls == "corrosion":
        for _ in range(int(rng.integers(1, 4))):
            m |= blob(rng, rng.uniform(14, 50), rng.uniform(14, 50), 3 + 9 * sev * rng.uniform(0.6, 1.1))
    elif cls == "damage":
        m = blob(rng, rng.uniform(20, 44), rng.uniform(20, 44), 6 + 12 * sev, 0.3)
    elif cls == "leak":
        x0, y0 = rng.uniform(16, 48), rng.uniform(8, 24)
        w, ln = 2 + 4 * sev, 12 + 26 * sev
        m = (np.abs(XX - x0 - 0.15 * (YY - y0)) < w * (1 - 0.4 * (YY - y0) / ln)) & (YY > y0) & (YY < y0 + ln)
    return m


def make_images(n=600, seed=0, mud=0.0, p_none=0.25, dark=False):
    """가상 외관 사진 n장(+진흙 오염 mud 비율)과 관리 기록·정답. 반환: meta(DataFrame), imgs(n,64,64,3), masks(n,64,64)."""
    rng = np.random.default_rng(seed)
    imgs, masks, rows = np.zeros((n, SZ, SZ, 3), np.float32), np.zeros((n, SZ, SZ), bool), []
    for i in range(n):
        cls = "none" if rng.random() < p_none else str(rng.choice(CLASSES[1:], p=[0.25, 0.3, 0.25, 0.2]))
        sev = 0.0 if cls == "none" else float(rng.beta(1.6, 2.0))
        base = np.array([0.42, 0.46, 0.40]) * (1 + 0.5 * ndi.gaussian_filter(rng.normal(size=(SZ, SZ)), 8)[..., None] * 3)
        img = base + rng.normal(0, 0.012, (SZ, SZ, 3))
        m = draw(rng, cls, sev)
        a = ndi.gaussian_filter(m.astype(float), 0.8)[..., None]                        # 경계를 부드럽게 섞는다
        if cls == "crack":
            col = img * rng.uniform(0.2, 0.45)
        elif cls == "corrosion":
            col = np.array([0.55, 0.30, 0.12]) * rng.uniform(0.75, 1.15) * (0.85 + 0.3 * rng.random((SZ, SZ, 1)))
        elif cls == "damage":
            col = np.ones_like(img) * np.array([0.34, 0.34, 0.36]) * (1.0 - 0.45 * sev) * rng.uniform(0.75, 1.0)
            rim = m & ~ndi.binary_erosion(m, iterations=2)
            a = np.maximum(a, 0.0); img = np.where(rim[..., None], 0.7, img)
        elif cls == "leak":
            col = np.ones_like(img) * np.array([0.10, 0.09, 0.08]) * rng.uniform(0.8, 2.6)
        else:
            col = img
        img = img * (1 - a) + col * a
        if rng.random() < 0.35:                                   # 무해한 얼룩(결함 아님): 옅은 갈색 번짐
            st = blob(rng, rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(6, 14), 0.5)
            al = ndi.gaussian_filter(st.astype(float), 2.5)[..., None] * rng.uniform(0.15, 0.4)
            img = img * (1 - al) + np.array([0.50, 0.40, 0.30]) * al
        if rng.random() < 0.3:                                    # 무해한 긴 스크래치(밝은 선)
            y0, x0, ang = rng.uniform(5, 58), rng.uniform(5, 58), rng.uniform(0, np.pi)
            for t in np.linspace(0, 25, 40):
                yy, xx = int(y0 + t * np.sin(ang)), int(x0 + t * np.cos(ang))
                if 0 <= yy < SZ and 0 <= xx < SZ:
                    img[yy, xx] = np.clip(img[yy, xx] * 1.5, 0, 1)
        if mud > 0:                                           # 진흙 오염: 결함 위를 덮을 수 있다(정답 마스크는 그대로)
            mm = np.zeros((SZ, SZ), bool)
            while mm.mean() < mud:
                mm |= blob(rng, rng.uniform(0, SZ), rng.uniform(0, SZ), rng.uniform(5, 11), 0.5)
            img[mm] = np.array([0.38, 0.30, 0.22]) * (0.85 + 0.3 * rng.random((mm.sum(), 1)))
        gain = rng.uniform(0.3, 0.55) if dark else rng.uniform(0.5, 1.15)
        ang = rng.uniform(0, 2 * np.pi)
        light = gain * (1 + 0.3 * (np.cos(ang) * (XX - 32) + np.sin(ang) * (YY - 32)) / 32)
        imgs[i] = np.clip(img * light[..., None] + rng.normal(0, 0.025, (SZ, SZ, 3)), 0, 1)
        masks[i] = m
        area = float(m.mean())
        depth = {"none": 0.0, "crack": 0.3 + 3.0 * sev, "corrosion": 0.1 + 1.5 * sev, "damage": 1.0 + 8.0 * sev, "leak": 0.0}[cls] * rng.lognormal(0, 0.1)
        idx = float(np.clip(100 * (1 - np.exp(-(CLS_W[cls] * area * 9 + 0.05 * depth))) + rng.normal(0, 1.5), 0, 100))
        rows.append({"img_id": f"IMG{seed:02d}{i:04d}", "cls": cls, "sev": sev, "area_frac": area, "depth_mm": depth, "damage_idx": idx,
                     "grade": int(grade_of(idx)), "gain": gain, "mud": mud})
    meta = pd.DataFrame(rows)
    # 장비 관리 기록(제원 요약): 사진 판정과 대조할 값
    age = rng.integers(1, 25, n)
    meta["day"] = np.sort(rng.integers(0, 90, n))
    meta["equip_type"] = rng.choice(["vehicle", "generator", "comm", "trailer"], n, p=[0.4, 0.2, 0.2, 0.2])
    meta["mfg_year"] = 2026 - age
    meta["op_hours"] = np.clip(rng.normal(180 * age, 400, n) + 8 * meta["damage_idx"], 10, 20000)
    meta["env"] = rng.choice(["coastal", "inland"], n, p=[0.3, 0.7])
    reg = np.clip(meta["grade"] + rng.choice([-1, 0, 0, 0, 0, 0, 1, 2], n), 1, 3)           # 장비 관리 기록상 직전 정비 등급
    meta["reg_grade"] = reg
    meta["emergency"] = rng.random(n) < 0.04                                               # 긴급 점검 요청(화질 불량이어도 보존)
    return meta, imgs, masks
# ---- 전처리(조명 보정·표준화)와 결함 후보 분할, 특징 추출 (cv2 대신 numpy·scipy 사용) ----
def correct(img):
    """조명 보정: 밝기에 평면(조명 기울기)을 적합해 나눈다. 어두운 결함 화소는 제외하고 두 번 반복 적합한다. 반환: 보정 밝기(정상 면 약 1), 색 비율."""
    g = img.mean(axis=2)
    A = np.c_[np.ones(SZ * SZ), XX.ravel() / SZ, YY.ravel() / SZ]
    keep = np.ones(SZ * SZ, bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(A[keep], g.ravel()[keep], rcond=None)
        plane = (A @ coef).reshape(SZ, SZ)
        keep = (np.abs(g - plane) < 0.08 * np.maximum(plane, 1e-3)).ravel()
        if keep.sum() < 200:
            keep[:] = True
    c = g / np.maximum(plane, 1e-3)
    chroma = img[..., 0] / (img.sum(axis=2) + 1e-6)
    return c, chroma


SEGP = {"dark": 0.7, "rust": 0.5, "rim": 1.45}            # 분할 임계값(어두움 보정 밝기, 붉은 비율, 밝은 테두리): 재보정 대상


def segment(img):
    """결함 후보 마스크: 어두운 영역(균열·누유·파손) + 붉은 갈색 영역(부식) + 밝은 테두리(파손)."""
    c, chroma = correct(img)
    dark = c < SEGP["dark"]
    rust = (chroma > SEGP["rust"]) & (c > 0.45)
    rim = c > SEGP["rim"]
    m = dark | rust | ndi.binary_dilation(rim, iterations=1) & ndi.binary_dilation(dark, iterations=3)
    m = ndi.binary_opening(m, structure=np.ones((2, 2))) if m.sum() > 12 else m
    return m, c, chroma, dark, rust, rim


def extract(img):
    """분할 결과와 색·모양에서 24개 특징을 만든다."""
    m, c, chroma, dark, rust, rim = segment(img)
    lab, n = ndi.label(m)
    area = float(m.sum())
    if n:
        sizes = ndi.sum(m, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        sl = ndi.find_objects(lab)[k - 1]
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        big = float(sizes.max())
        elong, fill = max(h, w) / max(min(h, w), 1), big / (h * w)
    else:
        big, elong, fill = 0.0, 1.0, 0.0
    gy, gx = np.gradient(c)
    mag = np.hypot(gx, gy)
    inside = m.sum() > 0
    return {"area_px": area, "area_frac": area / SZ ** 2, "n_comp": float(n), "big_px": big, "elong": elong, "fill": fill,
            "dark_frac": float(dark.mean()), "rust_frac": float(rust.mean()), "rim_frac": float(rim.mean()),
            "c_mean": float(c.mean()), "c_std": float(c.std()), "c_min": float(c.min()), "edge_mean": float(mag.mean()), "edge_p95": float(np.quantile(mag, 0.95)),
            "chroma_mean": float(chroma.mean()), "chroma_max": float(chroma.max()),
            "in_dark": float(c[m].mean()) if inside else 1.0, "in_chroma": float(chroma[m].mean()) if inside else float(chroma.mean()),
            "ring_contrast": float(c[ndi.binary_dilation(m, iterations=3) & ~m].mean() - c[m].mean()) if inside and (~m).any() else 0.0,
            "thin": float(1 - fill), "gain": float(img.mean()), "sat": float((img.max(axis=2) - img.min(axis=2)).mean()),
            "cy": float(ndi.center_of_mass(m)[0] / SZ) if inside else 0.5, "cx": float(ndi.center_of_mass(m)[1] / SZ) if inside else 0.5}


def feature_table(imgs):
    return pd.DataFrame([extract(im) for im in imgs])
# ---- 판정 파이프라인: 결함 유형 분류 + 손상도 회귀(분류 확률 포함) -> 정비 등급 ----
def fit_pipeline(meta, F):
    """결함 유형 분류기와 손상도 회귀기를 학습한다. 회귀기 입력의 분류 확률은 교차 예측으로 만들어 누설을 막는다."""
    clf = RandomForestClassifier(n_estimators=150, random_state=0, n_jobs=1)
    P = cross_val_predict(clf, F, meta["cls"], cv=4, method="predict_proba")
    clf.fit(F, meta["cls"])
    reg = GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.06, random_state=0).fit(np.c_[F.values, P], meta["damage_idx"])
    return {"clf": clf, "reg": reg, "cols": list(F.columns)}


def predict_pipeline(pl, F):
    X = F[pl["cols"]]
    P = pl["clf"].predict_proba(X)
    idx = np.clip(pl["reg"].predict(np.c_[X.values, P]), 0, 100)
    return pl["clf"].classes_[P.argmax(axis=1)], P, idx, P.max(axis=1)
# ---- 사진 품질 게이트: 진흙·오염 가림 추정과 판정 신뢰도 지수 ----
def mud_est(img):
    """진흙(갈색, 채도 낮은 붉은 기) 화소 비율을 추정한다. 3x3 평균으로 잡음을 줄인 뒤 색 비율로 판단하며, 실제 가림 비율보다 작게 나오지만 순서는 유지된다."""
    sm = ndi.uniform_filter(img, size=(3, 3, 1))
    s = sm.sum(axis=2) + 1e-6
    rr, gg = sm[..., 0] / s, sm[..., 1] / s
    return float(((rr > 0.385) & (rr < 0.46) & (gg < 0.325)).mean())


def confidence(P, idx, F, mud):
    """판정 신뢰도 지수 0~100 = 50 x 분류 확률 최대값 + 35 x 등급 경계까지 거리(8점에서 포화) + 15 x 사진 품질. 오염 의심(mud 추정 1% 이상)이면 상한 75로 제한한다."""
    bd = np.minimum(np.abs(idx - 35), np.abs(idx - 65))
    qual = np.clip(1.0 - np.clip(0.55 - F["gain"].values, 0, None) * 2 - np.clip(0.9 - F["c_mean"].values, 0, None), 0, 1)
    c = 50 * P.max(axis=1) + 35 * np.clip(bd / 8, 0, 1) + 15 * qual
    return np.where(np.asarray(mud) >= 0.01, np.minimum(c, 75.0), c)

mtr, itr, _ = make_images(600, seed=1)
Ftr = feature_table(itr)
pl0 = fit_pipeline(mtr, Ftr)
LOSS_UNDER, LOSS_OVER = 20.0, 6.0                                   # 과소/과대 판정 1등급당 손실(만원, 가정)


def ops(seed, n):
    """운영 사진 묶음: 저조도 1/3 + 진흙 5% 1/3 + 정상 1/3 (학습 때와 분포가 다르다)."""
    parts = [make_images(n // 3, seed=seed, dark=True), make_images(n // 3, seed=seed + 1, mud=0.05), make_images(n // 3, seed=seed + 2)]
    return pd.concat([p[0] for p in parts], ignore_index=True), np.concatenate([p[1] for p in parts]), np.concatenate([p[2] for p in parts])


def loss(true, g):
    d = np.asarray(g) - np.asarray(true)
    return np.where(d < 0, -d * LOSS_UNDER, d * LOSS_OVER)


def grade_shift(idx, delta):
    """과소 판정을 줄이기 위해 등급 경계를 delta만큼 낮춘다(35 -> 35-delta, 65 -> 65-delta)."""
    return np.where(np.asarray(idx) >= 65 - delta, 3, np.where(np.asarray(idx) >= 35 - delta, 2, 1))


def evaluate(pl, F, m, ims, delta=0):
    cls, P, idx, _ = predict_pipeline(pl, F)
    mud = np.array([mud_est(x) for x in ims])
    conf = confidence(P, idx, F, mud)
    g = grade_shift(idx, delta)
    auto = (conf >= 80) & (mud < 0.03) & (F["gain"].values >= 0.17)
    ok = g == m["grade"].values
    return {"cls": cls, "idx": idx, "g": g, "mud": mud, "conf": conf, "ok": ok, "mae": float(np.mean(np.abs(idx - m["damage_idx"].values))), "under": int((g < m["grade"].values).sum()),
            "loss": float(loss(m["grade"].values, g).mean()), "auto_n": int(auto.sum()), "auto_acc": float(ok[auto].mean()) if auto.any() else np.nan}


# ---------------- 1) AAR: 운영 로그 분석(이동 구간 A, 360장) ----------------
mA, iA, kA = ops(60, 360)
rng = np.random.default_rng(0)
perm = rng.permutation(len(mA))
FA = feature_table(iA)
ev = evaluate(pl0, FA, mA, iA)
print(f"[1] AAR 대상 운영 사진 {len(mA)}장(저조도·진흙 5%·정상 혼합): 등급 일치율 {ev['ok'].mean():.1%}, 손상도 MAE {ev['mae']:.2f}, 과소 판정 {ev['under']}장, 장당 오판 손실 {ev['loss']:.2f}만원")
wrong = np.where(~ev["ok"])[0]


def cause(i):
    if ev["mud"][i] >= 0.01: return "오염 가림"
    if FA["gain"].iloc[i] < 0.2: return "저조도"
    if mA["cls"][i] != "none" and mA["area_frac"][i] < 0.02: return "작은 결함 누락·과소"
    if ev["cls"][i] != mA["cls"][i]: return "결함 유형 혼동"
    if min(abs(ev["idx"][i] - 35), abs(ev["idx"][i] - 65)) < 6: return "등급 경계 근처"
    return "기타"


cs = pd.Series([cause(i) for i in wrong]).value_counts()
print(f"    오판 {len(wrong)}장의 원인 분류:", ", ".join(f"{k} {v}장({v / len(wrong):.0%})" for k, v in cs.items()))
print(f"    오판 중 과소 판정(실제보다 낮은 등급) {ev['under']}장 / 과대 {int((ev['g'] > mA['grade'].values).sum())}장 -> 과소 판정이 손실 단가가 {LOSS_UNDER / LOSS_OVER:.1f}배 높아 우선 교정 대상")

# ---------------- 2) 재보정: 분할 임계값 -> 운영 데이터 재학습 -> 등급 경계 이동 ----------------
A1, A2 = perm[:240], perm[240:]
cache = [correct(iA[i]) for i in A1]


def mask_from(c, chroma, dt, rt, rim=1.45):
    dark, rust, r = c < dt, (chroma > rt) & (c > 0.45), c > rim
    m = dark | rust | ndi.binary_dilation(r, iterations=1) & ndi.binary_dilation(dark, iterations=3)
    return ndi.binary_opening(m, structure=np.ones((2, 2))) if m.sum() > 12 else m


grid = []
for dt in (0.6, 0.7, 0.75, 0.8):
    for rt in (0.44, 0.5, 0.54):
        iou = np.mean([(mask_from(c, ch, dt, rt) & kA[i]).sum() / max((mask_from(c, ch, dt, rt) | kA[i]).sum(), 1) for (c, ch), i in zip(cache, A1)])
        grid.append((dt, rt, iou))
gd = pd.DataFrame(grid, columns=["dark 임계값", "rust 임계값", "평균 IoU"])
bst = gd.loc[gd["평균 IoU"].idxmax()]
cur = gd[(gd["dark 임계값"] == 0.7) & (gd["rust 임계값"] == 0.5)]["평균 IoU"].iloc[0]
print(f"\n[2] 분할 임계값 재보정(운영 사진 240장 IoU): 현행(0.70, 0.50) {cur:.3f} -> 최적({bst['dark 임계값']:.2f}, {bst['rust 임계값']:.2f}) {bst['평균 IoU']:.3f}")
SEGP["dark"], SEGP["rust"] = float(bst["dark 임계값"]), float(bst["rust 임계값"])
FA2 = feature_table(iA)
mm = pd.concat([mtr, mA.iloc[A1]], ignore_index=True)
pl1 = fit_pipeline(mm, pd.concat([Ftr, FA2.iloc[A1]], ignore_index=True))                   # 운영 분포 사진 240장을 추가 학습
ev2 = evaluate(pl1, FA2.iloc[A2].reset_index(drop=True), mA.iloc[A2].reset_index(drop=True), iA[A2])
costs = []
for dlt in (0, 2, 4, 6, 8):
    r = evaluate(pl1, FA2.iloc[A2].reset_index(drop=True), mA.iloc[A2].reset_index(drop=True), iA[A2], delta=dlt)
    costs.append((dlt, r["loss"], r["under"], r["ok"].mean()))
cd = pd.DataFrame(costs, columns=["경계 이동 delta", "장당 손실(만원)", "과소 판정", "일치율"])
best_d = int(cd.loc[cd["장당 손실(만원)"].idxmin(), "경계 이동 delta"])
print("    등급 경계 이동(보정용 120장, 과소 판정 손실 반영)\n" + cd.round(3).to_string(index=False))
if best_d == 0:
    print("    경계를 낮추면 과대 판정이 늘어 손실이 오히려 커지므로 경계 이동은 채택하지 않는다(delta=0 유지). 과소 판정은 경계가 아니라 오염 가림에서 주로 발생한다.")
else:
    print(f"    손실이 가장 작은 경계 이동 delta={best_d}점 채택(과소 판정을 줄이는 방향이며 사람 승인 후 적용)")

# ---------------- 3) 보류 구간 B(360장, 재보정에 쓰지 않음) 검증 ----------------
mB, iB, kB = ops(70, 360)
SEGP["dark"], SEGP["rust"] = 0.7, 0.5
FB0 = feature_table(iB)
e0 = evaluate(pl0, FB0, mB, iB)
SEGP["dark"], SEGP["rust"] = float(bst["dark 임계값"]), float(bst["rust 임계값"])
FB1 = feature_table(iB)
e1 = evaluate(pl1, FB1, mB, iB, delta=best_d)
tab = pd.DataFrame({"재보정 전": [e0["ok"].mean(), e0["mae"], e0["under"], e0["loss"], e0["auto_n"], e0["auto_acc"]], "재보정 후": [e1["ok"].mean(), e1["mae"], e1["under"], e1["loss"], e1["auto_n"], e1["auto_acc"]]},
                   index=["등급 일치율", "손상도 MAE", "과소 판정(장)", "장당 오판 손실(만원)", "자동 처리 건수", "자동 처리 일치율"])
print("\n[3] 보류 구간 B 검증\n" + tab.round(3).to_string())
print(f"    오판 손실 {1 - e1['loss'] / e0['loss']:.1%} 감소, 과소 판정 {e0['under']} -> {e1['under']}장. 오염 가림 사진은 정보 자체가 가려져 재보정으로 해결되지 않으므로 재촬영이 필요하다.")

# ---------------- 4) ROI 3대 지표(교육용 가정) ----------------
N_YR, MIN_FULL, MIN_QUICK = 20000, 15.0, 4.0                         # 연 판정 사진 수, 정밀 판독/간이 승인 소요(분)
WAGE, INV, OPEX = 1.2, 2500.0, 150.0                                 # 검사관 인건비(만원/시), 도입 비용, 연 운영비(만원)
full_b, full_a = 1 - e0["auto_n"] / len(mB), 1 - e1["auto_n"] / len(mB)


def roi(loss_b, loss_a, fb, fa, n=N_YR, inv=INV):
    t_b = fb * MIN_FULL + (1 - fb) * MIN_QUICK
    t_a = fa * MIN_FULL + (1 - fa) * MIN_QUICK
    save_loss = (loss_b - loss_a) * n
    save_time = (t_b - t_a) / 60 * WAGE * n                      # 기존 AI 대비 개선 AI 판독 인건비 절감(만원/년)
    save = save_loss + save_time - OPEX
    return save, 1 - t_a / t_b, (inv / (save / 12) if save > 0 else float("inf")), save_loss, save_time


sv, tr, pb, sl, st = roi(e0["loss"], e1["loss"], full_b, full_a)
t_b = full_b * MIN_FULL + (1 - full_b) * MIN_QUICK
t_a = full_a * MIN_FULL + (1 - full_a) * MIN_QUICK
roi_table = pd.DataFrame({
    "기존 AI": [len(mB), N_YR, t_b, e0["loss"], t_b / 60 * WAGE * N_YR, e0["loss"] * N_YR, 0.0],
    "개선 AI": [len(mB), N_YR, t_a, e1["loss"], t_a / 60 * WAGE * N_YR, e1["loss"] * N_YR, OPEX],
}, index=["관측 B 표본(장)", "연간 물량(장/년)", "평균 판독(분/장)", "오판 손실(만원/장)", "연 판독 인건비(만원/년)", "연 오판 손실(만원/년)", "추가 운영비(만원/년)"])
roi_table.loc["연 총비용(만원/년)"] = roi_table.iloc[4:7].sum()
assert np.isclose(roi_table.loc["연 총비용(만원/년)", "기존 AI"] - roi_table.loc["연 총비용(만원/년)", "개선 AI"], sv)
print("\n수정 실습본: 동일 기준 전후 비교표 [교육용 가정]\n" + roi_table.round(6).to_string())
print("추가 투자비 2500만원은 기존 AI에서 개선 AI로 전환하는 증분 투자 가정이다. 운영비 150만원/년 역시 증분이며 공통비용은 상쇄한다.")
print("회수기간은 순절감액이 0 이하이면 inf(회수 불가)로 표시한다. B 표본의 평균 손실·시간을 연 물량으로 외삽한 가정이며 실제 현장 관측이 아니다.")
print(f"\n[4] ROI 3대 지표 [교육용 가정: 연 {N_YR}장, 정밀 판독 {MIN_FULL:.0f}분, 간이 승인 {MIN_QUICK:.0f}분, 인건비 {WAGE}만원/시, 도입 {INV:.0f}만원, 운영 {OPEX:.0f}만원/년]")
print(f"    (1) 연간 비용 절감액 {sv:,.0f}만원(오판 손실 감소 {sl:,.0f} + 판독 인건비 {st:,.0f} - 운영비)  (2) 판독 시간 단축률 {tr:.1%}(기존 AI 대비 개선 AI; 같은 B 360장 기준)  (3) 투자 회수 기간 {pb:.1f}개월")
print("    산식: 절감액 = (재보정 전 - 후 장당 오판 손실) x 연 장수 + (기존 AI 평균 분/장 - 개선 AI 평균 분/장)/60 x 인건비 x 연 장수 - 운영비")
print("    장수 민감도:", "; ".join(f"{n}장 -> 절감 {roi(e0['loss'], e1['loss'], full_b, full_a, n=n)[0]:,.0f}만원, 회수 {roi(e0['loss'], e1['loss'], full_b, full_a, n=n)[2]:.0f}개월" for n in (5000, 10000, 20000, 40000)))
print("    비관(재보정 효과 없음, 판독 시간 절감만):", f"절감 {roi(e0['loss'], e0['loss'], full_b, full_a)[0]:,.0f}만원, 회수 {roi(e0['loss'], e0['loss'], full_b, full_a)[2]:.0f}개월")
print("    가정값이므로 재정·기획 부서와 실제 단가로 다시 산정해야 한다. 재보정된 임계값·경계는 정비감독관 승인 후 적용한다.")

fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
ax[0].bar(range(len(cs)), cs.values); ax[0].set_xticks(range(len(cs))); ax[0].set_xticklabels([f"C{i + 1}" for i in range(len(cs))]); ax[0].set_title("AAR: misjudgment causes (count)")
ax[1].plot(cd["경계 이동 delta"], cd["장당 손실(만원)"], "o-"); ax[1].set_title("Loss per photo vs grade-boundary shift"); ax[1].set_xlabel("delta")
x = np.arange(3); ax[2].bar(x - .2, [e0["ok"].mean() * 100, e0["under"], e0["loss"]], .4, label="before"); ax[2].bar(x + .2, [e1["ok"].mean() * 100, e1["under"], e1["loss"]], .4, label="after")
ax[2].set_xticks(x); ax[2].set_xticklabels(["accuracy %", "under-grade n", "loss/photo"]); ax[2].legend(); ax[2].set_title("Hold-out B: before vs after")
plt.tight_layout(); plt.show()
