"""SUP02 최소 로컬 웹앱 [교육용가상자료]. import 시 서버를 시작하지 않는다."""
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[2]

def load_data(path=None):
    path = Path(path) if path else ROOT / "data/samples/dashboard_fleet.csv"
    data = pd.read_csv(path)
    required = {"eq_id", "unit", "rul_days", "kit_expiry_days"}
    if not required.issubset(data.columns):
        raise ValueError("필수 열: eq_id, unit, rul_days, kit_expiry_days")
    for c in ("rul_days", "kit_expiry_days"):
        data[c] = pd.to_numeric(data[c], errors="raise")
        if data[c].isna().any() or (data[c] < 0).any(): raise ValueError(c + ": 0 이상 숫자가 필요합니다")
    return data

def filter_data(data, unit="전체"):
    return data.copy() if unit == "전체" else data.loc[data.unit == unit].copy()

def summary(data):
    return {"장비 수": len(data), "180일 미만 고위험": int((data.rul_days < 180).sum()),
            "키트 잔여 90일 미만": int((data.kit_expiry_days < 90).sum())}

def main():
    try:
        import streamlit as st
    except ImportError:
        print("Streamlit이 준비되지 않았습니다. 관리자에게 requirements-dashboard.txt 환경 준비를 요청하세요. 설치 제한 환경에서는 src/m08_corrected.py(원문 src/m08.py의 수정 실습 시뮬레이터)의 표·그래프·시간 기록을 대체 산출물로 인정합니다.")
        return 0
    st.set_page_config(page_title="SUP02 잔여수명·키트", layout="wide")
    st.title("SUP02 잔여수명·시효성 키트")
    st.caption("[교육용가상자료] 작은 UI 시연 데이터. M8의 1만 대 성능시험과 별도이며 승인 전 판단 보조입니다.")
    if st.button("M8 시뮬레이터 실행 결과 불러오기"):
        import runpy, contextlib, io
        import matplotlib.pyplot as plt
        log = io.StringIO()
        with contextlib.redirect_stdout(log): result = runpy.run_path(str(ROOT / "src/m08_corrected.py"))
        plt.close("all")
        frame = result["a10"][["eq_id", "unit"]].copy()
        frame["rul_days"] = result["pred10"]
        st.session_state["m8_result"] = frame
        st.session_state["m8_log"] = log.getvalue()
    if "m8_result" in st.session_state:
        frame = st.session_state["m8_result"]
        st.subheader("M8 실제 실행 결과")
        st.dataframe(frame)
        st.download_button("M8 결과 CSV",frame.to_csv(index=False).encode("utf-8-sig"),"sup02_m8.csv")
        st.text_area("M8 실행 로그",st.session_state["m8_log"])
    try: data = load_data()
    except (OSError, ValueError) as exc:
        st.error(str(exc)); return 1
    unit = st.selectbox("조직 필터", ["전체", *sorted(data.unit.unique())])
    selected = filter_data(data, unit)
    for column, (name, value) in zip(st.columns(3), summary(selected).items()): column.metric(name, value)
    st.dataframe(selected.rename(columns={"eq_id":"장비 ID", "unit":"조직", "rul_days":"잔여수명(일)", "kit_expiry_days":"키트 잔여일"}), hide_index=True)
    st.bar_chart(selected.set_index("eq_id")[["rul_days", "kit_expiry_days"]].rename(columns={"rul_days":"잔여수명(일)", "kit_expiry_days":"키트 잔여일"}))
    st.info("FEFO: 정비일+안전여유를 충족하는 로트 중 만료가 빠른 순서로 배정합니다. 이 표의 키트 잔여일 자체는 배정 완료를 의미하지 않습니다.")
    return 0

if __name__ == "__main__": main()
