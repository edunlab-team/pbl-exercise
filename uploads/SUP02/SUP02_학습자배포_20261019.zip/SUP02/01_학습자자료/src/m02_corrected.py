import sys
from pathlib import Path
_support_root = Path(__file__).resolve().parents[1] / 'src'
if str(_support_root) not in sys.path: sys.path.insert(0, str(_support_root))
"""표기·단위·모순·결측·중복 오류를 주입한 가상 장비 운용 기록에 운용 환경 가중치를 반영한 노후화 지표 산출을 포함한 정제 규칙 11종을 적용하고, 긴급 운용·다수 비계획 정비 같은 물자 특수 예외는 삭제하지 않고 보존하며 정합성 검증 통과율과 정제 전후 통계를 확인한다."""
import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 장비 보유 현황·고장 이력 생성기 (실제 조직·장비·수치 없음)
# 가상 조직 6개(U1~U6)의 장비가 운용 환경(normal/rough/salt/cold)에 따라 다른 속도로 노후화한다. 3단계 정비 후 운용시간(h_since)이
# 장비마다 숨은 수명(t_fail)을 넘으면 고장(event=1) 이력, 넘지 않았으면 현재까지 생존(event=0, 관측 중도절단)이다.
# ---------------------------------------------------------------------------
ENVS = ["normal", "rough", "salt", "cold"]
ENV_W = {"normal": 1.00, "rough": 1.35, "salt": 1.25, "cold": 1.12}              # 환경 가중치(숨은 정답, 가정값): 클수록 수명이 짧다
ENV_KO = {"normal": "일반", "rough": "험지", "salt": "염분", "cold": "혹한"}
UNITS = ["U1", "U2", "U3", "U4", "U5", "U6"]
UNIT_ENV = {"U1": [.7, .1, .1, .1], "U2": [.2, .6, .1, .1], "U3": [.2, .1, .6, .1], "U4": [.3, .1, .1, .5], "U5": [.5, .3, .1, .1], "U6": [.4, .1, .4, .1]}
ETYPES = ["truck", "generator", "trailer", "radio"]
CYCLE = 8000.0                                                                    # 규정 3단계 정비 주기(운용시간 h, 가정값)
KSHAPE = 12.0                                                                     # 수명 분포 와이블 형상(마모형 고장, 클수록 수명이 모여 있다)
INSP_NOISE = 0.025                                                                # 정비 점검 마모 비율 측정 오차(가정값)


def make_fleet(n=900, seed=0, env_w=None, shift=1.0):
    """장비 n대. env_w로 숨은 환경 가중치를 바꿔 운영 분포 변화를 모의할 수 있다. shift>1이면 가동률이 높아진다."""
    rng = np.random.default_rng(seed)
    w = env_w or ENV_W
    unit = rng.choice(UNITS, n)
    env = np.array([rng.choice(ENVS, p=UNIT_ENV[u]) for u in unit])
    et = rng.choice(ETYPES, n, p=[.4, .2, .2, .2])
    rate = rng.lognormal(np.log(3.0 * shift), 0.25, n)                            # 일 평균 운용시간(h/일)
    h_since = rng.uniform(300, 11500, n)                                          # 마지막 3단계 정비 이후 운용시간
    n_ovh = rng.integers(0, 3, n)
    hours = h_since + n_ovh * rng.uniform(5000, 8000, n)                          # 누적 운용시간
    km = hours * rng.normal(17, 3, n) * np.where(env == "rough", 0.8, 1.0)         # 누적 기동거리(km)
    age_y = np.clip(hours / (rate * 365) * rng.uniform(0.9, 1.15, n), 0.5, 25)
    unpl = rng.poisson(0.35 * h_since / 1000 * np.array([w[e] for e in env]) / 1.3)  # 비계획 정비 건수(환경이 가혹할수록 많다)
    n_maint = rng.poisson(0.6 * h_since / 1000 + 1)                                # 계획 정비 건수
    scale = 9600 / np.array([w[e] for e in env]) * 0.985 ** unpl * np.exp(rng.normal(0, 0.04, n))
    t_fail = scale * rng.weibull(KSHAPE, n)                                       # 3단계 정비 후 고장까지 운용시간(숨은 정답)
    event = (t_fail <= h_since).astype(int)
    dur = np.where(event == 1, t_fail, h_since)
    df = pd.DataFrame({"eq_id": [f"EQ{seed:02d}{i:04d}" for i in range(n)], "unit": unit, "env": env, "etype": et, "rate": rate, "hours": hours, "km": km, "age_y": age_y, "n_ovh": n_ovh,
                       "h_since": h_since, "unpl": unpl, "n_maint": n_maint, "t_fail": t_fail, "event": event, "dur": dur})
    df["insp"] = np.clip(dur / t_fail + rng.normal(0, INSP_NOISE, n), 0, 1.3)       # 마지막 정비 점검에서 측정한 마모 비율(소모 수명/총 수명, 오차 포함)
    df["rul_h"] = np.where(event == 0, t_fail - h_since, np.nan)                  # 생존 장비의 남은 운용시간(정답)
    df["rul_d"] = df["rul_h"] / df["rate"]                                        # 남은 일수(정답)
    return df


def mape(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return float(np.mean(np.abs(y - p) / np.abs(y)) * 100)


def mae(y, p):
    return float(np.mean(np.abs(np.asarray(y, float) - np.asarray(p, float))))


def rmse(y, p):
    return float(np.sqrt(np.mean((np.asarray(y, float) - np.asarray(p, float)) ** 2)))
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 노후화 파생 피처와 학습 표본 만들기. 환경 가중치 W0는 도입 시점의 전문가 추정값이며(실제 가중치와 다름) M9에서 재보정한다.
# ---------------------------------------------------------------------------
W0 = {"normal": 1.00, "rough": 1.15, "salt": 1.10, "cold": 1.05}
FEATS = ["h_since", "hours", "km", "age_y", "rate", "n_maint", "unpl", "unpl_per_kh", "km_per_h", "n_ovh", "k_rough", "k_salt", "k_cold", "k_truck", "k_gen", "k_trailer",
         "aging_idx", "lin_rul_d", "hs_frac", "insp", "insp_eta_h"]


def add_features(df, w=None):
    d = df.copy()
    w = w or W0
    d["unpl_per_kh"] = d["unpl"] / (d["h_since"] / 1000 + 0.5)
    d["km_per_h"] = d["km"] / d["hours"]
    for e in ("rough", "salt", "cold"):
        d["k_" + e] = (d["env"] == e).astype(int)
    d["k_truck"], d["k_gen"], d["k_trailer"] = (d["etype"] == "truck").astype(int), (d["etype"] == "generator").astype(int), (d["etype"] == "trailer").astype(int)
    d["aging_idx"] = d["h_since"] * d["env"].map(w) / CYCLE                      # 환경 가중 노후 지수(1이면 3단계 정비 주기에 도달)
    d["lin_rul_d"] = (CYCLE - d["h_since"]) / d["rate"]                           # 선형 감가상각 잔여 일수(Baseline)
    d["hs_frac"] = d["h_since"] / CYCLE
    d["insp_eta_h"] = d["h_since"] / np.maximum(d["insp"], 0.05)                  # 점검 마모 비율로 환산한 총 수명 추정(h)
    return d


def snapshots(df, k=4, seed=0):
    """고장 이력 장비의 과거 시점 표본: 고장 전 임의 시점의 점검값·운용시간과 그때의 남은 일수. (생존 장비의 미래는 알 수 없으므로 고장 이력만 쓴다)"""
    rng = np.random.default_rng(seed)
    f = df[df["event"] == 1]
    out = []
    for _ in range(k):
        s = f.copy()
        h = s["t_fail"] * rng.uniform(0.2, 0.98, len(s))
        ratio = h / s["h_since"]
        s["hours"] = s["hours"] - (s["h_since"] - h)
        s["km"] = s["km"] * ratio.clip(upper=1)
        s["unpl"] = np.floor(s["unpl"] * ratio)
        s["n_maint"] = np.floor(s["n_maint"] * ratio)
        s["insp"] = np.clip(h / s["t_fail"] + rng.normal(0, INSP_NOISE, len(s)), 0, 1.3)
        s["h_since"] = h
        s["rul_d"] = (s["t_fail"] - h) / s["rate"]
        s["event"] = 0
        out.append(s)
    return pd.concat(out, ignore_index=True)
# ---------------------------------------------------------------------------

truth = make_fleet(220, seed=5)
rng = np.random.default_rng(2)
raw = truth.drop(columns=["t_fail", "event", "dur", "rul_h", "rul_d"]).copy()
raw["urgent_ops"] = False
# 긴급 운용(가동률이 비정상적으로 높지만 실제 사실인 기록): 삭제하면 안 된다
urg = rng.choice(len(raw), 8, replace=False)
raw.loc[urg, "rate"] = rng.uniform(13, 17, 8)
raw.loc[urg, "urgent_ops"] = True
# 오류 주입
errs = {}
i = rng.choice(len(raw), 12, replace=False); raw.loc[i, "env"] = rng.choice(["험지", "ROUGH", "Salt ", "혹한", "일반", "normal "], 12); errs["환경 표기"] = 12
i = rng.choice(len(raw), 8, replace=False); raw.loc[i, "unit"] = rng.choice(["u3", "U 2", "U9", "u5"], 8); errs["조직 코드"] = 8
i = rng.choice(len(raw), 6, replace=False); raw.loc[i, "hours"] = -raw.loc[i, "hours"]; errs["운용시간 음수"] = 6
i = rng.choice(len(raw), 7, replace=False); raw.loc[i, "h_since"] = raw.loc[i, "hours"] * rng.uniform(1.3, 2.0, 7); errs["3단계 정비 후 시간 > 누적"] = 7
i = rng.choice(len(raw), 6, replace=False); raw.loc[i, "km"] = raw.loc[i, "km"] * 1000; errs["km 단위(m)"] = 6
i = rng.choice(len(raw), 9, replace=False); raw.loc[i, "rate"] = np.nan; errs["가동률 결측"] = 9
i = rng.choice(len(raw), 9, replace=False); raw.loc[i, "insp"] = np.nan; errs["점검 마모 결측"] = 9
i = rng.choice(len(raw), 5, replace=False); raw.loc[i, "insp"] = rng.uniform(1.8, 3.0, 5); errs["점검 마모 범위 초과"] = 5
raw = pd.concat([raw, raw.iloc[rng.choice(len(raw), 7, replace=False)]], ignore_index=True); errs["중복 행"] = 7
raw["eq_id"] = raw["eq_id"].where(rng.random(len(raw)) > 0.05, raw["eq_id"].str.lower()); errs["ID 표기"] = int((raw["eq_id"].str.islower()).sum())
print(f"[0] 오염 데이터 {len(raw)}행(원본 {len(truth)}행), 주입 오류: " + ", ".join(f"{k} {v}" for k, v in errs.items()) + f", 긴급 운용 정상 기록 {len(urg)}행")

# ---------------- 정제 규칙 ----------------
log = []
d = raw.copy()


def rule(no, desc, n):
    log.append((no, desc, int(n)))


n0 = len(d)
d["eq_id"] = d["eq_id"].str.upper().str.strip()
rule(1, "장비 ID 대문자·공백 통일", (raw["eq_id"] != d["eq_id"]).sum())
d = d.drop_duplicates("eq_id").reset_index(drop=True)
rule(2, "중복 장비 행 제거", n0 - len(d))
d["unit"] = d["unit"].astype(str).str.upper().str.replace(" ", "")
d["env"] = d["env"].astype(str).str.strip()
EMAP = {"험지": "rough", "rough": "rough", "salt": "salt", "혹한": "cold", "cold": "cold", "일반": "normal", "normal": "normal", "염분": "salt"}
env_fix = d["env"].str.lower().map(EMAP)
rule(3, "운용 환경 표기 표준화(한글·대소문자·공백)", (env_fix != d["env"]).sum())
d["env"] = env_fix.fillna("normal")
iso = ~d["unit"].isin(UNITS)
quarantine = d[iso].copy()
d = d[~iso].reset_index(drop=True)
rule(4, "미등록 조직 코드 행 격리(삭제하지 않고 별도 보관)", iso.sum())
neg = d["hours"] < 0
d.loc[neg, "hours"] = -d.loc[neg, "hours"]
rule(5, "누적 운용시간 부호 오류 보정", neg.sum())
bad_hs = d["h_since"] > d["hours"]
d.loc[bad_hs, "h_since"] = d.loc[bad_hs, "hours"]
rule(6, "3단계 정비 후 운용시간 > 누적 운용시간 모순 보정", bad_hs.sum())
unit_km = d["km"] / d["hours"].clip(lower=1) > 100
d.loc[unit_km, "km"] = d.loc[unit_km, "km"] / 1000
rule(7, "기동거리 단위 오류(m -> km) 보정", unit_km.sum())
nan_rate = d["rate"].isna()
d["rate"] = d["rate"].fillna(d.groupby(["etype"])["rate"].transform("median"))
rule(8, "일 평균 운용시간 결측을 장비 구분 중앙값으로 보정", nan_rate.sum())
out_i = d["insp"] > 1.3
d.loc[out_i, "insp"] = np.nan
miss_i = d["insp"].isna()
d["insp_flag"] = np.where(miss_i, "추정", "측정")
d["insp"] = d["insp"].fillna((d["h_since"] / CYCLE * d["env"].map(W0)).clip(0, 1.3))
rule(9, "점검 마모 비율 범위 초과 제거 후 결측을 환경 가중 노후 지수로 대체(추정 표시)", miss_i.sum())
RATE_THRESHOLD = 12
exc = (d["rate"] > RATE_THRESHOLD) | d["urgent_ops"]
d["exception"] = np.where(exc, "가동률 또는 긴급 예외", "")
rule(10, f"가동률 {RATE_THRESHOLD}h/일 초과 또는 원천 urgent_ops 예외 표시 후 보존", exc.sum())
d["aging_idx"] = d["h_since"] * d["env"].map(W0) / CYCLE
d["eff_hours"] = d["h_since"] * d["env"].map(W0)
rule(11, "환경 가중치 반영 노후화 지표(aging_idx, eff_hours) 산출", len(d))
print("\n[1] 정제 규칙 적용 로그")
print(pd.DataFrame(log, columns=["규칙", "내용", "처리 건수"]).to_string(index=False))
print(f"    정제 규칙 {len(log)}종 적용(목표 10종 이상: {'달성' if len(log) >= 10 else '미달'}), 격리 {len(quarantine)}행은 담당자 확인 대기")

# ---------------- 정합성 검증 ----------------
checks = {"장비 ID 유일": not d["eq_id"].duplicated().any(), "조직 코드 등록": bool(d["unit"].isin(UNITS).all()), "환경 값 4종": bool(d["env"].isin(ENVS).all()),
          "운용시간 0 이상": bool((d["hours"] >= 0).all()), "3단계 정비 후 <= 누적": bool((d["h_since"] <= d["hours"] + 1e-6).all()), "기동 속도 5~40km/h": bool((d["km"] / d["hours"].clip(lower=1)).between(5, 40).all()),
          "점검 마모 0~1.3": bool(d["insp"].between(0, 1.3).all()), "필수 컬럼 결측 0": int(d[["rate", "insp", "aging_idx"]].isna().sum().sum()) == 0}
print("\n[2] 정합성 검증")
for k, v in checks.items():
    print(f"  [{'PASS' if v else 'FAIL'}] {k}")
print(f"    통과율 {sum(checks.values()) / len(checks):.0%} (목표 100%)")

# ---------------- 복원 정확도·예외 보존·전후 통계 ----------------
t = truth.set_index("eq_id").loc[d["eq_id"].isin(truth["eq_id"]).pipe(lambda m: d.loc[m, "eq_id"])]
dd = d.set_index("eq_id").loc[t.index]
print(f"\n[3] 복원 정확도(원본과 비교): 누적 운용시간 오차 {np.abs(dd['hours'] - t['hours']).mean():.1f}h, 기동거리 오차 {np.abs(dd['km'] - t['km']).mean():.1f}km, 가동률 오차 {np.abs(dd['rate'] - t['rate'])[dd['exception'] == ''].mean():.3f}h/일(가동률·긴급 예외 제외)")
from sup02_revision_support import preservation
print(f"    예외 표시 {int(exc.sum())}행(원천 긴급 운용과 가동률 예외를 구분)")
for label, mask in [("긴급 운용", raw["urgent_ops"]), ("비계획 정비(unpl>0)", raw["unpl"] > 0)]:
    audit = preservation(raw, d, quarantine, mask)
    print(f"    {label} 기록: 원천 고유ID {audit['source']}, 정제 보존 {audit['kept']}, 격리 보존 {audit['isolated']}, 삭제 {audit['lost']}, 누락ID {audit['lost_ids']}")
print(f"    점검 마모 추정 대체 {int((d['insp_flag'] == '추정').sum())}행은 추정 표시")
rows = [("운용시간 최솟값(h)", raw["hours"].min(), d["hours"].min(), truth["hours"].min()), ("운용시간 평균(h)", raw["hours"].mean(), d["hours"].mean(), truth["hours"].mean()),
        ("기동거리 최댓값(km)", raw["km"].max(), d["km"].max(), truth["km"].max()), ("가동률 유효 건수", raw["rate"].notna().sum(), d["rate"].notna().sum(), truth["rate"].notna().sum()),
        ("가동률 최댓값(h/일)", raw["rate"].max(), d["rate"].max(), truth["rate"].max()), ("점검 마모 최댓값", raw["insp"].max(), d["insp"].max(), truth["insp"].max())]
print("[4] 전후 기술통계(오염 / 정제 후 / 원본)")
print(pd.DataFrame(rows, columns=["항목", "오염", "정제 후", "원본"]).round(2).to_string(index=False))
w = d.groupby("env")["aging_idx"].mean().round(3)
print("    환경별 평균 노후 지수(가중치 W0 적용):", w.to_dict())
