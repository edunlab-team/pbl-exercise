import sys
from pathlib import Path
_support_root = Path(__file__).resolve().parents[1] / 'src'
if str(_support_root) not in sys.path: sys.path.insert(0, str(_support_root))
"""선형 감가상각(규정 3단계 정비 주기 - 경과 운용시간) 기반 잔여 수명(RUL) Baseline을 구현해 오차와 환경별 편향·한계를 확인하고, EDA 차트 8종·상관분석(p-value)·환경별 차이 검정·조직별 위험 파레토로 핵심 노후화 요인을 찾는다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.metrics import r2_score

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 장비 보유 현황·고장 이력 생성기 (실제 조직·장비·수치 없음)
# 가상 조직 6개(U1~U6)의 장비가 운용 환경(normal/rough/salt/cold)에 따라 다른 속도로 노후화한다. 3단계 정비 후 운용시간(h_since)이
# 장비마다 숨은 수명(t_fail)을 넘으면 고장(event=1) 이력, 넘지 않았으면 현재까지 생존(event=0, 관측 중도절단)이다.
# ---------------------------------------------------------------------------
ENVS = ["normal", "rough", "salt", "cold"]
ENV_W = {"normal": 1.00, "rough": 1.35, "salt": 1.25, "cold": 1.12}              # 환경 가중치(숨은 정답, 가정값): 클수록 수명이 짧다
ENV_KO = {"normal": "일반", "rough": "험지", "salt": "염분", "cold": "혹한"}
UNITS = ["U1", "U2", "U3", "U4", "U5", "U6"]
UNIT_ENV = {"U1": [.7, .1, .1, .1], "U2": [.2, .6, .1, .1], "U3": [.2, .1, .6, .1], "U4": [.3, .1, .1, .5], "U5": [.5, .3, .1, .1], "U6": [.4, .1, .4, .1]}
ETYPES = ["truck", "generator", "trailer", "radio"]
CYCLE = 8000.0                                                                    # 규정 3단계 정비 주기(운용시간 h, 가정값)
KSHAPE = 12.0                                                                     # 수명 분포 와이블 형상(마모형 고장, 클수록 수명이 모여 있다)
INSP_NOISE = 0.025                                                                # 정비 점검 마모 비율 측정 오차(가정값)


def make_fleet(n=900, seed=0, env_w=None, shift=1.0):
    """장비 n대. env_w로 숨은 환경 가중치를 바꿔 운영 분포 변화를 모의할 수 있다. shift>1이면 가동률이 높아진다."""
    rng = np.random.default_rng(seed)
    w = env_w or ENV_W
    unit = rng.choice(UNITS, n)
    env = np.array([rng.choice(ENVS, p=UNIT_ENV[u]) for u in unit])
    et = rng.choice(ETYPES, n, p=[.4, .2, .2, .2])
    rate = rng.lognormal(np.log(3.0 * shift), 0.25, n)                            # 일 평균 운용시간(h/일)
    h_since = rng.uniform(300, 11500, n)                                          # 마지막 3단계 정비 이후 운용시간
    n_ovh = rng.integers(0, 3, n)
    hours = h_since + n_ovh * rng.uniform(5000, 8000, n)                          # 누적 운용시간
    km = hours * rng.normal(17, 3, n) * np.where(env == "rough", 0.8, 1.0)         # 누적 기동거리(km)
    age_y = np.clip(hours / (rate * 365) * rng.uniform(0.9, 1.15, n), 0.5, 25)
    unpl = rng.poisson(0.35 * h_since / 1000 * np.array([w[e] for e in env]) / 1.3)  # 비계획 정비 건수(환경이 가혹할수록 많다)
    n_maint = rng.poisson(0.6 * h_since / 1000 + 1)                                # 계획 정비 건수
    scale = 9600 / np.array([w[e] for e in env]) * 0.985 ** unpl * np.exp(rng.normal(0, 0.04, n))
    t_fail = scale * rng.weibull(KSHAPE, n)                                       # 3단계 정비 후 고장까지 운용시간(숨은 정답)
    event = (t_fail <= h_since).astype(int)
    dur = np.where(event == 1, t_fail, h_since)
    df = pd.DataFrame({"eq_id": [f"EQ{seed:02d}{i:04d}" for i in range(n)], "unit": unit, "env": env, "etype": et, "rate": rate, "hours": hours, "km": km, "age_y": age_y, "n_ovh": n_ovh,
                       "h_since": h_since, "unpl": unpl, "n_maint": n_maint, "t_fail": t_fail, "event": event, "dur": dur})
    df["insp"] = np.clip(dur / t_fail + rng.normal(0, INSP_NOISE, n), 0, 1.3)       # 마지막 정비 점검에서 측정한 마모 비율(소모 수명/총 수명, 오차 포함)
    df["rul_h"] = np.where(event == 0, t_fail - h_since, np.nan)                  # 생존 장비의 남은 운용시간(정답)
    df["rul_d"] = df["rul_h"] / df["rate"]                                        # 남은 일수(정답)
    return df


def mape(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return float(np.mean(np.abs(y - p) / np.abs(y)) * 100)


def mae(y, p):
    return float(np.mean(np.abs(np.asarray(y, float) - np.asarray(p, float))))


def rmse(y, p):
    return float(np.sqrt(np.mean((np.asarray(y, float) - np.asarray(p, float)) ** 2)))
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 노후화 파생 피처와 학습 표본 만들기. 환경 가중치 W0는 도입 시점의 전문가 추정값이며(실제 가중치와 다름) M9에서 재보정한다.
# ---------------------------------------------------------------------------
W0 = {"normal": 1.00, "rough": 1.15, "salt": 1.10, "cold": 1.05}
FEATS = ["h_since", "hours", "km", "age_y", "rate", "n_maint", "unpl", "unpl_per_kh", "km_per_h", "n_ovh", "k_rough", "k_salt", "k_cold", "k_truck", "k_gen", "k_trailer",
         "aging_idx", "lin_rul_d", "hs_frac", "insp", "insp_eta_h"]


def add_features(df, w=None):
    d = df.copy()
    w = w or W0
    d["unpl_per_kh"] = d["unpl"] / (d["h_since"] / 1000 + 0.5)
    d["km_per_h"] = d["km"] / d["hours"]
    for e in ("rough", "salt", "cold"):
        d["k_" + e] = (d["env"] == e).astype(int)
    d["k_truck"], d["k_gen"], d["k_trailer"] = (d["etype"] == "truck").astype(int), (d["etype"] == "generator").astype(int), (d["etype"] == "trailer").astype(int)
    d["aging_idx"] = d["h_since"] * d["env"].map(w) / CYCLE                      # 환경 가중 노후 지수(1이면 3단계 정비 주기에 도달)
    d["lin_rul_d"] = (CYCLE - d["h_since"]) / d["rate"]                           # 선형 감가상각 잔여 일수(Baseline)
    d["hs_frac"] = d["h_since"] / CYCLE
    d["insp_eta_h"] = d["h_since"] / np.maximum(d["insp"], 0.05)                  # 점검 마모 비율로 환산한 총 수명 추정(h)
    return d


def snapshots(df, k=4, seed=0):
    """고장 이력 장비의 과거 시점 표본: 고장 전 임의 시점의 점검값·운용시간과 그때의 남은 일수. (생존 장비의 미래는 알 수 없으므로 고장 이력만 쓴다)"""
    rng = np.random.default_rng(seed)
    f = df[df["event"] == 1]
    out = []
    for _ in range(k):
        s = f.copy()
        h = s["t_fail"] * rng.uniform(0.2, 0.98, len(s))
        ratio = h / s["h_since"]
        s["hours"] = s["hours"] - (s["h_since"] - h)
        s["km"] = s["km"] * ratio.clip(upper=1)
        s["unpl"] = np.floor(s["unpl"] * ratio)
        s["n_maint"] = np.floor(s["n_maint"] * ratio)
        s["insp"] = np.clip(h / s["t_fail"] + rng.normal(0, INSP_NOISE, len(s)), 0, 1.3)
        s["h_since"] = h
        s["rul_d"] = (s["t_fail"] - h) / s["rate"]
        s["event"] = 0
        out.append(s)
    return pd.concat(out, ignore_index=True)
# ---------------------------------------------------------------------------

df = make_fleet(900, seed=1)
d = add_features(df)
al = d[d.event == 0].copy()
al["err"] = al["lin_rul_d"] - al["rul_d"]                       # 양수 = Baseline이 수명을 길게 본다(위험한 과대 예측)
big = al["rul_d"] >= 90
print(f"[1] 가상 장비 {len(d)}대(고장 이력 {int(d.event.sum())}대, 생존 {len(al)}대). Baseline RUL(일) = (규정 주기 {CYCLE:.0f}h - 3단계 정비 후 운용시간) / 일 가동률")
print(f"    생존 장비 평가: MAE {mae(al.rul_d, al.lin_rul_d):.0f}일, RMSE {rmse(al.rul_d, al.lin_rul_d):.0f}일, MAPE(참 RUL 90일 이상) {mape(al.rul_d[big], al.lin_rul_d[big]):.1f}%, R2 {r2_score(al.rul_d, al.lin_rul_d):.3f}, 평균 편향 {al.err.mean():+.0f}일")
over = (al["lin_rul_d"] > al["rul_d"] + 30)
print(f"    Baseline이 실제보다 30일 넘게 길게 본 장비 {int(over.sum())}대({over.mean():.0%}) - 고장 전에 정비 시점을 놓칠 위험")
fail_before = d[(d.event == 1) & (d.t_fail < CYCLE)]
print(f"    고장 이력 {int(d.event.sum())}대 중 규정 주기({CYCLE:.0f}h) 이전에 고장 난 장비 {len(fail_before)}대({len(fail_before) / d.event.sum():.0%}) -> 고정 주기는 가혹 환경 장비를 지키지 못한다")

# 조건별 오차
conds = {"일반 환경": al.env == "normal", "험지": al.env == "rough", "염분": al.env == "salt", "혹한": al.env == "cold", "비계획 정비율 상위 25%": al.unpl_per_kh >= al.unpl_per_kh.quantile(.75),
         "일 가동률 4h 이상": al.rate >= 4, "점검 마모 0.8 이상(노후)": al.insp >= 0.8}
ct = pd.DataFrame([(k, int(m.sum()), mae(al.rul_d[m], al.lin_rul_d[m]), al.err[m].mean()) for k, m in conds.items()], columns=["조건", "대수", "MAE(일)", "평균 편향(일)"])
print("\n[2] 조건별 Baseline 오차(양수 = 과대 예측)\n" + ct.round(0).to_string(index=False))
print("    -> 험지·염분 장비는 수명을 길게(위험), 일반 환경 장비는 짧게(과잉 정비) 보아 환경별 편향 방향이 반대다. 환경 가중치 미반영이 한계다.")

# 상관분석
rows = []
for c in FEATS:
    if al[c].nunique() < 2: continue
    r, p = stats.spearmanr(al[c], al["err"])
    rows.append((c, r, p))
cr = pd.DataFrame(rows, columns=["피처", "스피어만 상관", "p-value"]).assign(abs_r=lambda x: x["스피어만 상관"].abs()).sort_values("abs_r", ascending=False)
sig = cr[(cr["abs_r"] >= 0.2) & (cr["p-value"] < 0.05)]
print(f"\n[3] Baseline 오차(부호 있음: 양수 = 과대 예측)와 유의한 상관(|r|>=0.2, p<0.05) 피처 {len(sig)}개 (목표 5개 이상: {'달성' if len(sig) >= 5 else '미달'})")
print(sig.head(8)[["피처", "스피어만 상관", "p-value"]].round(4).to_string(index=False))
print("    (lin_rul_d·h_since·hs_frac는 Baseline 산식과 직접 겹치므로 해석에서는 환경 더미·점검 마모·기동 강도 같은 독립 요인을 본다)")
hi, lo = al[al.env.isin(["rough", "salt"])]["err"], al[al.env.isin(["normal"])]["err"]
u = stats.mannwhitneyu(hi, lo)
kw = stats.kruskal(*[g["insp_eta_h"].values for _, g in al.groupby("env")])
print(f"    가설검정: 험지·염분 vs 일반 환경 Baseline 편향 평균 {hi.mean():+.0f}일 vs {lo.mean():+.0f}일(Mann-Whitney p={u.pvalue:.1e}), 환경별 점검 환산 총 수명 차이 Kruskal p={kw.pvalue:.1e}")

# 파레토: 조직별 고위험(참 RUL 180일 미만) 장비
risk = al[al.rul_d < 180].groupby("unit").size().sort_values(ascending=False)
cum = risk.cumsum() / risk.sum()
print(f"\n[4] 파레토: 참 RUL 180일 미만 고위험 장비 {int(risk.sum())}대, 상위 {int((cum <= 0.8).sum() + 1)}개 조직이 80% 차지 -> " + ", ".join(f"{u} {n}대" for u, n in risk.items()))
print("    핵심 발견: 환경 가중치와 정비 이력·점검 마모가 Baseline이 놓치는 요인이며, 이는 M4 피처 설계(환경 더미, 비계획 정비율, 점검 마모)의 근거가 된다.")

from matplotlib import font_manager
_available = {f.name for f in font_manager.fontManager.ttflist}
_korean = next((f for f in ("AppleGothic", "Malgun Gothic", "NanumGothic", "Noto Sans CJK KR") if f in _available), None)
if _korean:
    plt.rcParams["font.family"] = _korean
    plt.rcParams["axes.unicode_minus"] = False
def chart_label(ko, ascii_text): return ko if _korean else ascii_text

fig, ax = plt.subplots(2, 4, figsize=(18, 8))
ax[0, 0].boxplot([d.loc[d.env == e, "insp_eta_h"] for e in ENVS]); ax[0, 0].set_xticklabels([chart_label(ENV_KO[e], e) for e in ENVS]); ax[0, 0].set_title(chart_label('1 환경별 추정 총수명(h)', '1 Estimated total life by environment (h)'))
ax[0, 1].scatter(d.h_since, d.dur, c=d.event, s=6, cmap="coolwarm"); ax[0, 1].set_title(chart_label('2 3단계 정비 후 시간과 관측 시간(빨강=고장)', '2 Hours since overhaul vs observed (red = failed)'))
ax[0, 2].hist(d.rate, 30); ax[0, 2].set_title(chart_label('3 일 가동률(h/일)', '3 Daily usage rate (h/day)'))
ax[0, 3].scatter(d.h_since, d.unpl, s=6, c=d.env.map({e: i for i, e in enumerate(ENVS)})); ax[0, 3].set_title(chart_label('4 운용시간별 비계획 정비', '4 Unplanned maintenance vs hours'))
ax[1, 0].bar(range(len(ct)), ct["평균 편향(일)"]); ax[1, 0].set_xticks(range(len(ct))); ax[1, 0].set_xticklabels([f"C{i + 1}" for i in range(len(ct))]); ax[1, 0].set_title(chart_label('5 조건별 기준모델 편향(일)', '5 Baseline bias by condition (days)'))
ax[1, 1].scatter(al.insp, al.hs_frac, s=6, c=al.env.map({e: i for i, e in enumerate(ENVS)})); ax[1, 1].set_title(chart_label('6 점검 마모와 운용시간 비율', '6 Inspection wear vs hours fraction'))
ax[1, 2].scatter(al.rul_d, al.lin_rul_d, s=6); ax[1, 2].plot([0, 4000], [0, 4000], "k--"); ax[1, 2].set_title(chart_label('7 실제 잔여수명과 기준 예측(일)', '7 True RUL vs Baseline RUL (days)'))
ax[1, 3].bar(risk.index, risk.values); ax[1, 3].set_title(chart_label('8 조직별 고위험 장비(파레토)', '8 High-risk equipment by unit (Pareto)'))

for panel in (ax[0, 3], ax[1, 1]):
    handles, labels = panel.collections[0].legend_elements()
    panel.legend(handles, [chart_label(ENV_KO[e], e) for e in ENVS], title=chart_label('환경', 'Environment'), fontsize=7)
legend = "; ".join(f"C{i+1}={name}" for i, name in enumerate(ct["조건"]))
print("차트 조건 범례:", legend)
fig.text(.5, .01, legend if _korean else "C1 normal; C2 rough; C3 salt; C4 cold; C5 high unplanned rate; C6 usage >=4h/day; C7 wear >=0.8", ha="center", fontsize=9)

for _ax, (_xko, _xen, _yko, _yen) in zip(ax.flat, [('환경', 'Environment', '추정 총수명(h)', 'Life (h)'), ('3단계 정비 후 시간(h)', 'Hours since overhaul', '관측 시간(h)', 'Observed (h)'), ('일 가동률(h/일)', 'Usage (h/day)', '장비 수', 'Count'), ('3단계 정비 후 시간(h)', 'Hours since overhaul', '비계획 정비 횟수', 'Unplanned count'), ('조건 코드', 'Condition', '평균 편향(일)', 'Bias (days)'), ('점검 마모', 'Wear', '운용시간 비율', 'Hours fraction'), ('실제 잔여수명(일)', 'True RUL (days)', '기준 예측(일)', 'Baseline RUL (days)'), ('조직', 'Unit', '고위험 장비 수', 'High-risk count')]):
    _ax.set_xlabel(chart_label(_xko, _xen)); _ax.set_ylabel(chart_label(_yko, _yen))
print("차트 한국어 제목 대응:", ['1 환경별 추정 총수명(h)', '2 3단계 정비 후 시간과 관측 시간(빨강=고장)', '3 일 가동률(h/일)', '4 운용시간별 비계획 정비', '5 조건별 기준모델 편향(일)', '6 점검 마모와 운용시간 비율', '7 실제 잔여수명과 기준 예측(일)', '8 조직별 고위험 장비(파레토)'])
plt.tight_layout(rect=(0, .04, 1, 1)); plt.show()
print("\nEDA 차트 8종 생성 완료(목표 8종 이상: 달성)")
