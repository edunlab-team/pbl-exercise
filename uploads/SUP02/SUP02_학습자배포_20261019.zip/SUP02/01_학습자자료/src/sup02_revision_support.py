"""SUP02 수정 실습의 실제 대조 함수. Streamlit 및 실행 부작용 없음."""
from pathlib import Path
import re
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
DOC_SECTIONS = ("데이터 사전", "정제 규칙", "Baseline·EDA", "생존 분석", "RUL·일정", "대시보드·설명", "승인·권한", "부하 시험", "AAR·ROI", "재학습 절차", "장애 대응", "인터페이스")

def document_checks(path):
    text = Path(path).read_text(encoding="utf-8") if Path(path).is_file() else ""
    blocks = re.split(r"(?m)^## +", text)
    sections = {}
    for block in blocks[1:]:
        title, _, body = block.partition("\n")
        sections[title.strip()] = body.strip()
    return {title: bool(sections.get(title)) and len(sections[title]) >= 30
            and not re.search(r"TODO|\(작성\)|미작성|여기에 작성", sections[title], re.I)
            for title in DOC_SECTIONS}

def preservation(raw, clean, quarantine, mask):
    norm = lambda s: set(s.astype(str).str.strip().str.upper())
    source = norm(raw.loc[mask, "eq_id"])
    kept = norm(clean["eq_id"]) & source
    isolated = norm(quarantine["eq_id"]) & source
    lost = source - kept - isolated
    return dict(source=len(source), kept=len(kept), isolated=len(isolated), lost=len(lost), lost_ids=sorted(lost))

def sensitivity_text(sens):
    ordered = sorted(sens)
    delta = np.diff([s for _, s in ordered])
    if np.all(np.abs(delta) < 1e-9): trend = "동일"
    elif np.all(delta >= -1e-9): trend = "단조 증가(비감소)"
    elif np.all(delta <= 1e-9): trend = "단조 감소(비증가)"
    else: trend = "비단조"
    values = "; ".join(f"x{m:g}: {s:.1%}" for m, s in ordered)
    return f"실측 민감도 {values}. 단가 증가 방향의 절감률은 {trend}. 각 단가에서 일정을 다시 최적화하므로 단가와 절감률의 방향을 일반화하지 않는다."

def retraining_checks(train_ids, holdout_ids, y, pc, ph, ac, bc, promote, threshold, selected, champ, chall):
    y, pc, ph = [np.asarray(v, dtype=float) for v in (y, pc, ph)]
    valid = y.size > 0 and y.shape == pc.shape == ph.shape and all(np.isfinite(v).all() for v in (y, pc, ph))
    errors = valid and np.isclose(np.mean(np.abs(y-pc)), ac) and np.isclose(np.mean(np.abs(y-ph)), bc)
    decision = bool(valid and np.isfinite(ac) and np.isfinite(bc) and ac > 0 and promote == ((ac-bc)/ac >= threshold))
    return {"학습·검증 ID 분리": bool(train_ids) and bool(holdout_ids) and not (set(train_ids) & set(holdout_ids)),
            "예측 길이·유한값": bool(valid), "MAE 재계산 일치": bool(errors),
            "승격 문턱 판정 일치": decision,
            "선택 모델 연결": selected is (chall if promote else champ) and champ is not chall}

def stability_table(frame, overall_mae, min_n=30, max_ratio=1.30):
    result = frame.copy()
    result["전체 대비 MAE 배수"] = result["앙상블 MAE"] / overall_mae
    result["안정성 판정"] = ["판정 유보(표본 부족)" if n < min_n else ("기준 충족" if r <= max_ratio else "기준 미달")
                           for n, r in zip(result["대수"], result["전체 대비 MAE 배수"])]
    return result
