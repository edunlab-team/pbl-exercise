import sys
from pathlib import Path
_support_root = Path(__file__).resolve().parents[1] / 'src'
if str(_support_root) not in sys.path: sys.path.insert(0, str(_support_root))
"""조직별 장비 노후도 현황과 권장 정비 캘린더 대시보드를 구현하고, 장비마다 잔여 수명(RUL) 예측의 기여도 상위 3개 요인을 변수군 평균 대체 방식으로 자동 산출해 자연어 설명으로 보여 준다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 장비 보유 현황·고장 이력 생성기 (실제 조직·장비·수치 없음)
# 가상 조직 6개(U1~U6)의 장비가 운용 환경(normal/rough/salt/cold)에 따라 다른 속도로 노후화한다. 3단계 정비 후 운용시간(h_since)이
# 장비마다 숨은 수명(t_fail)을 넘으면 고장(event=1) 이력, 넘지 않았으면 현재까지 생존(event=0, 관측 중도절단)이다.
# ---------------------------------------------------------------------------
ENVS = ["normal", "rough", "salt", "cold"]
ENV_W = {"normal": 1.00, "rough": 1.35, "salt": 1.25, "cold": 1.12}              # 환경 가중치(숨은 정답, 가정값): 클수록 수명이 짧다
ENV_KO = {"normal": "일반", "rough": "험지", "salt": "염분", "cold": "혹한"}
UNITS = ["U1", "U2", "U3", "U4", "U5", "U6"]
UNIT_ENV = {"U1": [.7, .1, .1, .1], "U2": [.2, .6, .1, .1], "U3": [.2, .1, .6, .1], "U4": [.3, .1, .1, .5], "U5": [.5, .3, .1, .1], "U6": [.4, .1, .4, .1]}
ETYPES = ["truck", "generator", "trailer", "radio"]
CYCLE = 8000.0                                                                    # 규정 3단계 정비 주기(운용시간 h, 가정값)
KSHAPE = 12.0                                                                     # 수명 분포 와이블 형상(마모형 고장, 클수록 수명이 모여 있다)
INSP_NOISE = 0.025                                                                # 정비 점검 마모 비율 측정 오차(가정값)


def make_fleet(n=900, seed=0, env_w=None, shift=1.0):
    """장비 n대. env_w로 숨은 환경 가중치를 바꿔 운영 분포 변화를 모의할 수 있다. shift>1이면 가동률이 높아진다."""
    rng = np.random.default_rng(seed)
    w = env_w or ENV_W
    unit = rng.choice(UNITS, n)
    env = np.array([rng.choice(ENVS, p=UNIT_ENV[u]) for u in unit])
    et = rng.choice(ETYPES, n, p=[.4, .2, .2, .2])
    rate = rng.lognormal(np.log(3.0 * shift), 0.25, n)                            # 일 평균 운용시간(h/일)
    h_since = rng.uniform(300, 11500, n)                                          # 마지막 3단계 정비 이후 운용시간
    n_ovh = rng.integers(0, 3, n)
    hours = h_since + n_ovh * rng.uniform(5000, 8000, n)                          # 누적 운용시간
    km = hours * rng.normal(17, 3, n) * np.where(env == "rough", 0.8, 1.0)         # 누적 기동거리(km)
    age_y = np.clip(hours / (rate * 365) * rng.uniform(0.9, 1.15, n), 0.5, 25)
    unpl = rng.poisson(0.35 * h_since / 1000 * np.array([w[e] for e in env]) / 1.3)  # 비계획 정비 건수(환경이 가혹할수록 많다)
    n_maint = rng.poisson(0.6 * h_since / 1000 + 1)                                # 계획 정비 건수
    scale = 9600 / np.array([w[e] for e in env]) * 0.985 ** unpl * np.exp(rng.normal(0, 0.04, n))
    t_fail = scale * rng.weibull(KSHAPE, n)                                       # 3단계 정비 후 고장까지 운용시간(숨은 정답)
    event = (t_fail <= h_since).astype(int)
    dur = np.where(event == 1, t_fail, h_since)
    df = pd.DataFrame({"eq_id": [f"EQ{seed:02d}{i:04d}" for i in range(n)], "unit": unit, "env": env, "etype": et, "rate": rate, "hours": hours, "km": km, "age_y": age_y, "n_ovh": n_ovh,
                       "h_since": h_since, "unpl": unpl, "n_maint": n_maint, "t_fail": t_fail, "event": event, "dur": dur})
    df["insp"] = np.clip(dur / t_fail + rng.normal(0, INSP_NOISE, n), 0, 1.3)       # 마지막 정비 점검에서 측정한 마모 비율(소모 수명/총 수명, 오차 포함)
    df["rul_h"] = np.where(event == 0, t_fail - h_since, np.nan)                  # 생존 장비의 남은 운용시간(정답)
    df["rul_d"] = df["rul_h"] / df["rate"]                                        # 남은 일수(정답)
    return df


def mape(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return float(np.mean(np.abs(y - p) / np.abs(y)) * 100)


def mae(y, p):
    return float(np.mean(np.abs(np.asarray(y, float) - np.asarray(p, float))))


def rmse(y, p):
    return float(np.sqrt(np.mean((np.asarray(y, float) - np.asarray(p, float)) ** 2)))
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 노후화 파생 피처와 학습 표본 만들기. 환경 가중치 W0는 도입 시점의 전문가 추정값이며(실제 가중치와 다름) M9에서 재보정한다.
# ---------------------------------------------------------------------------
W0 = {"normal": 1.00, "rough": 1.15, "salt": 1.10, "cold": 1.05}
FEATS = ["h_since", "hours", "km", "age_y", "rate", "n_maint", "unpl", "unpl_per_kh", "km_per_h", "n_ovh", "k_rough", "k_salt", "k_cold", "k_truck", "k_gen", "k_trailer",
         "aging_idx", "lin_rul_d", "hs_frac", "insp", "insp_eta_h"]


def add_features(df, w=None):
    d = df.copy()
    w = w or W0
    d["unpl_per_kh"] = d["unpl"] / (d["h_since"] / 1000 + 0.5)
    d["km_per_h"] = d["km"] / d["hours"]
    for e in ("rough", "salt", "cold"):
        d["k_" + e] = (d["env"] == e).astype(int)
    d["k_truck"], d["k_gen"], d["k_trailer"] = (d["etype"] == "truck").astype(int), (d["etype"] == "generator").astype(int), (d["etype"] == "trailer").astype(int)
    d["aging_idx"] = d["h_since"] * d["env"].map(w) / CYCLE                      # 환경 가중 노후 지수(1이면 3단계 정비 주기에 도달)
    d["lin_rul_d"] = (CYCLE - d["h_since"]) / d["rate"]                           # 선형 감가상각 잔여 일수(Baseline)
    d["hs_frac"] = d["h_since"] / CYCLE
    d["insp_eta_h"] = d["h_since"] / np.maximum(d["insp"], 0.05)                  # 점검 마모 비율로 환산한 총 수명 추정(h)
    return d


def snapshots(df, k=4, seed=0):
    """고장 이력 장비의 과거 시점 표본: 고장 전 임의 시점의 점검값·운용시간과 그때의 남은 일수. (생존 장비의 미래는 알 수 없으므로 고장 이력만 쓴다)"""
    rng = np.random.default_rng(seed)
    f = df[df["event"] == 1]
    out = []
    for _ in range(k):
        s = f.copy()
        h = s["t_fail"] * rng.uniform(0.2, 0.98, len(s))
        ratio = h / s["h_since"]
        s["hours"] = s["hours"] - (s["h_since"] - h)
        s["km"] = s["km"] * ratio.clip(upper=1)
        s["unpl"] = np.floor(s["unpl"] * ratio)
        s["n_maint"] = np.floor(s["n_maint"] * ratio)
        s["insp"] = np.clip(h / s["t_fail"] + rng.normal(0, INSP_NOISE, len(s)), 0, 1.3)
        s["h_since"] = h
        s["rul_d"] = (s["t_fail"] - h) / s["rate"]
        s["event"] = 0
        out.append(s)
    return pd.concat(out, ignore_index=True)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 생존 분석 도구(scipy만 사용): 와이블 AFT(가속 수명) 모형과 Cox 비례위험 모형
# ---------------------------------------------------------------------------
from scipy.optimize import minimize


def aft_x(d):
    return np.c_[np.ones(len(d)), d["env"].eq("rough"), d["env"].eq("salt"), d["env"].eq("cold"), d["unpl"] / (d["h_since"] / 1000 + 0.5)].astype(float)


AFT_COLS = ["절편", "험지", "염분", "혹한", "비계획 정비율"]


def fit_aft(d):
    """3단계 정비 후 운용시간 dur(고장이면 event=1, 생존이면 중도절단)에 대한 와이블 AFT 최대우도 추정. 반환: 계수(마지막은 log 형상)."""
    x, t, e = aft_x(d), d["dur"].values, d["event"].values

    def nll(p):
        lam, k = np.exp(x @ p[:-1]), np.exp(p[-1])
        z = (t / lam) ** k
        return -(e * (np.log(k) - np.log(lam) + (k - 1) * (np.log(t) - np.log(lam))) - z).sum()

    r = minimize(nll, np.r_[np.log(8000), np.zeros(x.shape[1] - 1), np.log(5)], method="BFGS")
    return r.x


def aft_pred(p, d, q=0.5, h=None):
    """이미 h(운용시간)까지 생존했다는 조건에서 분위수 q 생존 시점(운용시간 h 기준 총 수명)을 돌려준다. q=0.5가 조건부 중앙값."""
    lam, k = np.exp(aft_x(d) @ p[:-1]), np.exp(p[-1])
    h = d["h_since"].values if h is None else h
    return lam * ((h / lam) ** k - np.log(q)) ** (1 / k)


def aft_fail_prob(p, d, h0, h1):
    """h0까지 생존한 장비가 h0~h1 사이에 고장 날 조건부 확률."""
    lam, k = np.exp(aft_x(d) @ p[:-1]), np.exp(p[-1])
    s0, s1 = np.exp(-(h0 / lam) ** k), np.exp(-(h1 / lam) ** k)
    return 1 - s1 / s0


def fit_cox(d, iters=25):
    """Cox 비례위험(Breslow 근사) 뉴턴-랩슨. 공변량: 험지·염분·혹한·비계획 정비율. 반환: 계수."""
    x = aft_x(d)[:, 1:]
    o = np.argsort(-d["dur"].values)
    x, e = x[o], d["event"].values[o]
    b = np.zeros(x.shape[1])
    for _ in range(iters):
        r = np.exp(x @ b)
        S0 = np.cumsum(r)
        S1 = np.cumsum(r[:, None] * x, axis=0)
        S2 = np.cumsum(r[:, None, None] * x[:, :, None] * x[:, None, :], axis=0)
        m1 = S1 / S0[:, None]
        g = ((x - m1) * e[:, None]).sum(axis=0)
        H = -sum(e[i] * (S2[i] / S0[i] - np.outer(m1[i], m1[i])) for i in np.where(e == 1)[0])
        step = np.linalg.solve(H - 1e-6 * np.eye(len(b)), g)
        b = b - step
        if np.abs(step).max() < 1e-7:
            break
    return b


def cindex(time, event, risk):
    """일치도 C-index: 위험 점수가 높은 쪽이 먼저 고장 났는가(관측 가능한 쌍만)."""
    t, e, r = np.asarray(time), np.asarray(event), np.asarray(risk)
    num = den = 0.0
    for i in np.where(e == 1)[0]:
        m = t > t[i]
        den += m.sum()
        num += (r[m] < r[i]).sum() + 0.5 * (r[m] == r[i]).sum()
    return num / max(den, 1)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 잔여 수명(RUL, 일) 예측 엔진: 와이블 AFT 조건부 중앙값 + 그래디언트 부스팅(고장 이력 시점 표본 학습)의 평균
# ---------------------------------------------------------------------------
from sklearn.ensemble import GradientBoostingRegressor


def fit_engine(train, seed=0):
    p = fit_aft(train)
    sn = add_features(snapshots(train, 5, seed))
    sn["aft"] = (aft_pred(p, sn) - sn["h_since"]) / sn["rate"]
    g = GradientBoostingRegressor(n_estimators=250, max_depth=3, learning_rate=0.06, random_state=0).fit(sn[FEATS + ["aft"]], sn["rul_d"])
    return {"p": p, "g": g}


def predict_rul(eng, d):
    """d는 add_features를 거친 표. 반환: (앙상블 RUL, AFT RUL, GBR RUL) - 일 단위."""
    aft = ((aft_pred(eng["p"], d) - d["h_since"]) / d["rate"]).values
    x = d[FEATS].copy()
    x["aft"] = aft
    gb = eng["g"].predict(x)
    return np.clip(0.5 * aft + 0.5 * gb, 1, None), aft, gb
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 계획정비(3단계 정비) 일정 추천: 월별 정비센터 능력·예산·시효성 부품 키트(유효기한) 제약 아래 기대 비용 최소화 (비용 단가는 교육용 가정값, 만원)
# ---------------------------------------------------------------------------
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.stats import norm

C_PLAN, C_FAIL, C_WASTE_KH, C_KIT = 600.0, 2400.0, 40.0, 120.0       # 계획 3단계 정비, 비계획 고장(긴급 정비 포함), 미사용 수명 1000h당 손실, 시효성 부품 키트
HORIZON, MDAYS = 12, 30                                                # 계획 12개월, 월 30일
CAP_M, BUDGET_M = 22, 15000.0                                          # 월별 정비센터 능력(대), 월별 예산
LOTS = [(30, 70), (45, 170), (45, 390), (70, 800)]                     # 시효성 키트 로트(수량, 유효기한까지 남은 일수)
KIT_MARGIN = 14                                                        # 정비일 기준 최소 유효기간 여유(일)


def exp_cost_matrix(pred, rate, month_days):
    """장비 i를 월 m에 정비할 때의 기대 비용. 참 RUL ~ N(pred, sigma), sigma = 35일 + 0.12 x pred (가정). 마지막 열은 계획 기간 밖(미정비)."""
    sig = 35 + 0.12 * pred
    C = np.zeros((len(pred), len(month_days) + 1))
    for j, day in enumerate(month_days):
        z = (day - pred) / sig
        pf = norm.cdf(z)
        unused = np.maximum(pred - day, 0) * rate * 0.6                                   # 정비를 앞당긴 만큼 버리는 운용시간 h(근사)
        C[:, j] = C_PLAN + C_KIT + pf * (C_FAIL - C_PLAN) + C_WASTE_KH * unused / 1000 * (1 - pf)
    C[:, -1] = norm.cdf((HORIZON * MDAYS - pred) / sig) * C_FAIL
    return C


def plan_milp(pred, rate, cap=CAP_M, budget=BUDGET_M, lots=LOTS, use_kit=True):
    """정수계획으로 장비별 정비 월(0~11) 또는 미정비(-1)를 배정한다. 후보는 예측 RUL이 계획 기간 +90일 이내인 장비."""
    md = np.arange(1, HORIZON + 1) * MDAYS
    cand = np.where(pred < HORIZON * MDAYS + 90)[0]
    n, M = len(cand), HORIZON
    C = exp_cost_matrix(pred[cand], rate[cand], md)
    c = C.ravel()
    A, lo, hi = [], [], []
    for i in range(n):                                              # 장비당 한 번만 배정(월 12칸 + 미정비)
        row = np.zeros(n * (M + 1)); row[i * (M + 1):(i + 1) * (M + 1)] = 1; A.append(row); lo.append(1); hi.append(1)
    for m in range(M):                                              # 월별 능력·예산
        row = np.zeros(n * (M + 1)); row[m::(M + 1)] = 1
        A.append(row); lo.append(0); hi.append(cap)
        A.append(row * (C_PLAN + C_KIT)); lo.append(0); hi.append(budget)
    if use_kit:                                                     # 시효성 키트: m월 이후 정비 수요는 그 시점에 유효기간이 남은 로트 수량을 넘을 수 없다
        for m in range(M):
            sup = sum(q for q, e in lots if e >= md[m] + KIT_MARGIN)
            row = np.zeros(n * (M + 1))
            for mm in range(m, M):
                row[mm::(M + 1)] = 1
            A.append(row); lo.append(0); hi.append(sup)
    r = milp(c, constraints=LinearConstraint(np.array(A), lo, hi), integrality=np.ones(len(c)), bounds=Bounds(0, 1), options={"time_limit": 20})
    month = np.full(len(pred), -1)
    if r.x is not None:
        x = np.round(r.x).reshape(n, M + 1)
        assign = np.where(x[:, :M].sum(axis=1) > 0.5, x[:, :M].argmax(axis=1), -1)
        month[cand] = assign
    return month


def plan_greedy(pred, margin=45, cap=CAP_M, budget=BUDGET_M):
    """간단한 탐욕 배정: 정비 목표일(예측 RUL - margin)이 빠른 순으로 목표일 이전 가장 늦은 빈 월, 없으면 가장 이른 빈 월에 배정."""
    cap = min(cap, int(budget // (C_PLAN + C_KIT)))                 # 월 예산이 허용하는 대수로 능력을 제한
    month = np.full(len(pred), -1)
    left = np.full(HORIZON, cap)
    for i in np.argsort(pred):
        if pred[i] > HORIZON * MDAYS + 60: break
        tgt = int(np.clip((pred[i] - margin) // MDAYS - 1, 0, HORIZON - 1))
        for m in list(range(tgt, -1, -1)) + list(range(tgt + 1, HORIZON)):
            if left[m] > 0:
                month[i] = m; left[m] -= 1; break
    return month


def plan_fixed(lin_rul, cap=CAP_M, budget=BUDGET_M):
    """관행: 규정 주기 도달 순서대로(선형 잔여 일수) 월별 능력 안에서 배정."""
    return plan_greedy(np.asarray(lin_rul, float), margin=0, cap=cap, budget=budget)


def evaluate_plan(month, true_rul, rate, cost_kit=True):
    """참 RUL로 계획의 실제 비용을 계산한다: 정비일 이전에 고장 -> 비계획 고장 비용, 아니면 계획 비용 + 미사용 수명 손실."""
    day = np.where(month >= 0, (month + 1) * MDAYS, 10 ** 9)
    fail = (true_rul < day) & (true_rul < HORIZON * MDAYS)
    planned = (month >= 0) & ~fail
    waste = np.where(planned, (true_rul - day) * rate * 0.6, 0) * C_WASTE_KH / 1000
    cost = fail * C_FAIL + planned * (C_PLAN + (C_KIT if cost_kit else 0)) + waste
    return {"total": float(cost.sum()), "fail": int(fail.sum()), "planned": int(planned.sum()), "waste": float(waste.sum()), "unsched_fail": int(((month < 0) & fail).sum())}


def kit_fefo(month, lots=LOTS):
    """유효기한이 빠른 로트부터 쓰는 FEFO로 키트를 배정하고 정비일에 유효기간이 부족한 배정 수와 만료 폐기 수량을 센다."""
    q = [[qty, e] for qty, e in sorted(lots, key=lambda t: t[1])]
    short = 0
    for m in sorted(month[month >= 0]):
        day = (m + 1) * MDAYS
        for lot in q:
            if lot[1] >= day + KIT_MARGIN and lot[0] > 0:
                lot[0] -= 1; break
        else:
            short += 1
    expired = sum(l[0] for l in q if l[1] < HORIZON * MDAYS)
    return {"short": short, "expired_unused": expired, "left": sum(l[0] for l in q)}
# ---------------------------------------------------------------------------

tr = make_fleet(900, seed=1)
eng = fit_engine(tr)
fl = add_features(make_fleet(900, seed=3))
al = fl[fl.event == 0].reset_index(drop=True)
al["rul_pred"], _, _ = predict_rul(eng, al)
al["month"] = plan_milp(al["rul_pred"].values, al["rate"].values)
al["p90"] = aft_fail_prob(eng["p"], al, al["h_since"].values, al["h_since"].values + 90 * al["rate"].values)

# ---------------- 1) 조직별 노후도 현황 ----------------
g = al.groupby("unit")
board = pd.DataFrame({"장비 수": g.size(), "평균 노후 지수": g["aging_idx"].mean(), "평균 예측 RUL(일)": g["rul_pred"].mean(), "180일 내 고위험": g["rul_pred"].apply(lambda x: int((x < 180).sum())),
                      "험지·염분 비율": g["env"].apply(lambda x: x.isin(["rough", "salt"]).mean()), "12개월 내 권장 정비": g["month"].apply(lambda x: int((x >= 0).sum()))})
board["고위험 비율"] = board["180일 내 고위험"] / board["장비 수"]
print(f"[1] 조직별 노후도 현황(생존 장비 {len(al)}대, 가상 조직 6개) [교육용가상자료]")
print(board.round(2).to_string())
worst = board["고위험 비율"].idxmax()
print(f"    고위험 비율이 가장 높은 조직 {worst}({board.loc[worst, '고위험 비율']:.0%}), 환경 구성(험지·염분 {board.loc[worst, '험지·염분 비율']:.0%})과 함께 본다.")

# ---------------- 2) 권장 정비 캘린더 ----------------
cal = pd.crosstab(al.loc[al.month >= 0, "unit"], al.loc[al.month >= 0, "month"] + 1).reindex(columns=range(1, HORIZON + 1), fill_value=0)
print("\n[2] 권장 정비 캘린더(조직 x 월, 대수; 월 예산·능력·키트 유효기간 반영)")
print(cal.to_string())
print(f"    월 합계: " + " ".join(f"{m}월 {int(c)}" for m, c in cal.sum().items()) + f" / 정비 일정이 잡히지 않은 고위험(RUL 180일 미만) 장비 {int(((al.month < 0) & (al.rul_pred < 180)).sum())}대")
top = al.sort_values("rul_pred").head(8)
print("\n    위험 상위 8대 [권장 월은 승인 전 추천안]")
print(pd.DataFrame({"장비": top.eq_id, "조직": top.unit, "환경": top.env.map(ENV_KO), "예측 RUL(일)": top.rul_pred, "90일 내 고장 확률": top.p90, "권장 월": top.month.map(lambda m: f"{m + 1}월" if m >= 0 else "-")}).round(2).to_string(index=False))

# ---------------- 3) 기여도 상위 3개(변수군 평균 대체) ----------------
GROUPS = {"운용 이력(경과 시간·거리·연수)": ["h_since", "hours", "km", "age_y"], "운용 환경": ["env"], "정비 이력(비계획·계획 정비)": ["unpl", "n_maint"], "점검 마모 비율": ["insp"], "일 가동률": ["rate"]}
MEAN = tr[["h_since", "hours", "km", "age_y", "unpl", "n_maint", "insp", "rate"]].mean()
raw_cols = ["eq_id", "unit", "env", "etype", "rate", "hours", "km", "age_y", "n_ovh", "h_since", "unpl", "n_maint", "insp"]
base_raw = al[raw_cols].copy()
full = al["rul_pred"].values
contrib = {}
for gname, cols in GROUPS.items():
    x = base_raw.copy()
    for c in cols:
        x[c] = "normal" if c == "env" else MEAN[c]
    xf = add_features(x.assign(event=0, t_fail=0.0, dur=x["h_since"]))
    contrib[gname] = full - predict_rul(eng, xf)[0]                          # 음수 = 이 요인 때문에 평균 장비보다 잔여 수명이 짧다
C = pd.DataFrame(contrib)
t3 = C.apply(lambda r: r.reindex(r.abs().sort_values(ascending=False).index)[:3], axis=1)
okn = int(sum(t3.iloc[i].notna().sum() == 3 and np.isfinite(t3.iloc[i].dropna().values).all() for i in range(len(t3))))
print(f"\n[3] 장비 {len(al)}대 중 기여도 상위 3개 요인 자동 산출 {okn}대 ({okn / len(al):.0%}, 목표 100%)")
print("    요인군별 평균 기여 크기(일):", ", ".join(f"{k} {v:.0f}" for k, v in C.abs().mean().sort_values(ascending=False).items()))


def explain(i):
    r, row = al.loc[i], C.loc[i]
    ordered = row.reindex(row.abs().sort_values(ascending=False).index)[:3]
    main = ordered.index[0]
    why = {"운용 이력(경과 시간·거리·연수)": "3단계 정비 이후 운용 시간이 길어", "운용 환경": f"{ENV_KO[r.env]} 환경 가혹도 때문에", "정비 이력(비계획·계획 정비)": "비계획 정비가 잦아", "점검 마모 비율": "점검 마모 비율이 높아", "일 가동률": "일 가동률이 높아"}[main]
    return f"{r.eq_id}({r.unit}, {ENV_KO[r.env]}): {why} 잔여 수명 {r.rul_pred:.0f}일 예측. 주요 요인 " + ", ".join(f"{k.split('(')[0]}({v:+.0f}일)" for k, v in ordered.items())


print("[4] 위험 상위 3대 자연어 설명(음수 = 평균 장비보다 잔여 수명이 짧아지는 요인)")
for i in top.index[:3]:
    print("   -", explain(i))
print("    대시보드와 설명은 정비계획관의 판단 보조이며 일정 확정과 장비 도태 건의는 물자 책임자 승인(M7)에 따른다.")

from matplotlib import font_manager
_available = {f.name for f in font_manager.fontManager.ttflist}
_korean = next((f for f in ("AppleGothic", "Malgun Gothic", "NanumGothic", "Noto Sans CJK KR") if f in _available), None)
if _korean:
    plt.rcParams["font.family"] = _korean
    plt.rcParams["axes.unicode_minus"] = False
def chart_label(ko, ascii_text): return ko if _korean else ascii_text

fig, ax = plt.subplots(2, 2, figsize=(13, 8))
ax[0, 0].bar(board.index, board["고위험 비율"] * 100); ax[0, 0].set_title(chart_label('1 조직별 고위험 비율(%, 잔여수명<180일)', '1 High-risk share by unit (%, RUL < 180 days)'))
im = ax[0, 1].imshow(cal.values, aspect="auto", cmap="YlOrRd"); ax[0, 1].set_xticks(range(HORIZON)); ax[0, 1].set_xticklabels(range(1, HORIZON + 1)); ax[0, 1].set_yticks(range(len(cal))); ax[0, 1].set_yticklabels(cal.index)
ax[0, 1].set_title(chart_label('2 권장 정비 캘린더(조직×월)', '2 Recommended overhaul calendar (unit x month)')); plt.colorbar(im, ax=ax[0, 1])
ax[1, 0].bar(board.index, board["평균 노후 지수"]); ax[1, 0].axhline(1, c="r", ls="--"); ax[1, 0].set_title(chart_label('3 조직별 평균 노후 지수', '3 Mean aging index by unit'))
r0 = C.loc[top.index[0]]
ax[1, 1].barh([chart_label(ko, en) for ko, en in zip(["운용 이력", "운용 환경", "정비 이력", "점검 마모", "일 가동률"], ["usage history", "environment", "maintenance history", "inspection wear", "daily usage"])][::-1], r0.values[::-1]); ax[1, 1].set_title(chart_label('4 최고위험 장비의 잔여수명 기여도(일)', '4 Contribution to RUL, riskiest equipment (days)'))

print("차트4 대상 장비 ID:", top.iloc[0].eq_id, "(조직 평균이 아닌 단일 장비)")

for _ax, (_xko, _xen, _yko, _yen) in zip(ax.flat, [('조직', 'Unit', '고위험 비율(%)', 'High risk (%)'), ('권장 월', 'Month', '조직', 'Unit'), ('조직', 'Unit', '평균 노후 지수', 'Aging index'), ('기여도(일)', 'Contribution (days)', '요인', 'Factor')]):
    _ax.set_xlabel(chart_label(_xko, _xen)); _ax.set_ylabel(chart_label(_yko, _yen))
print("차트 한국어 제목 대응:", ['1 조직별 고위험 비율(%, 잔여수명<180일)', '2 권장 정비 캘린더(조직×월)', '3 조직별 평균 노후 지수', '4 최고위험 장비의 잔여수명 기여도(일)'])
plt.tight_layout(rect=(0, .04, 1, 1)); plt.show()
