"""운영 기간 수명 예측 오차를 AAR로 환경별·원인별 분석하고, 환경 가중치를 운영 고장 이력의 AFT 계수로 재보정하고 운영 데이터로 예측 엔진을 재학습해 보류 장비 집단에서 개선을 검증한 뒤 비용 절감액·가동 중단일수 단축률·투자 회수 기간 3대 효과 지표를 산식과 민감도로 산출한다."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 장비 보유 현황·고장 이력 생성기 (실제 조직·장비·수치 없음)
# 가상 조직 6개(U1~U6)의 장비가 운용 환경(normal/rough/salt/cold)에 따라 다른 속도로 노후화한다. 3단계 정비 후 운용시간(h_since)이
# 장비마다 숨은 수명(t_fail)을 넘으면 고장(event=1) 이력, 넘지 않았으면 현재까지 생존(event=0, 관측 중도절단)이다.
# ---------------------------------------------------------------------------
ENVS = ["normal", "rough", "salt", "cold"]
ENV_W = {"normal": 1.00, "rough": 1.35, "salt": 1.25, "cold": 1.12}              # 환경 가중치(숨은 정답, 가정값): 클수록 수명이 짧다
ENV_KO = {"normal": "일반", "rough": "험지", "salt": "염분", "cold": "혹한"}
UNITS = ["U1", "U2", "U3", "U4", "U5", "U6"]
UNIT_ENV = {"U1": [.7, .1, .1, .1], "U2": [.2, .6, .1, .1], "U3": [.2, .1, .6, .1], "U4": [.3, .1, .1, .5], "U5": [.5, .3, .1, .1], "U6": [.4, .1, .4, .1]}
ETYPES = ["truck", "generator", "trailer", "radio"]
CYCLE = 8000.0                                                                    # 규정 3단계 정비 주기(운용시간 h, 가정값)
KSHAPE = 12.0                                                                     # 수명 분포 와이블 형상(마모형 고장, 클수록 수명이 모여 있다)
INSP_NOISE = 0.025                                                                # 정비 점검 마모 비율 측정 오차(가정값)


def make_fleet(n=900, seed=0, env_w=None, shift=1.0):
    """장비 n대. env_w로 숨은 환경 가중치를 바꿔 운영 분포 변화를 모의할 수 있다. shift>1이면 가동률이 높아진다."""
    rng = np.random.default_rng(seed)
    w = env_w or ENV_W
    unit = rng.choice(UNITS, n)
    env = np.array([rng.choice(ENVS, p=UNIT_ENV[u]) for u in unit])
    et = rng.choice(ETYPES, n, p=[.4, .2, .2, .2])
    rate = rng.lognormal(np.log(3.0 * shift), 0.25, n)                            # 일 평균 운용시간(h/일)
    h_since = rng.uniform(300, 11500, n)                                          # 마지막 3단계 정비 이후 운용시간
    n_ovh = rng.integers(0, 3, n)
    hours = h_since + n_ovh * rng.uniform(5000, 8000, n)                          # 누적 운용시간
    km = hours * rng.normal(17, 3, n) * np.where(env == "rough", 0.8, 1.0)         # 누적 기동거리(km)
    age_y = np.clip(hours / (rate * 365) * rng.uniform(0.9, 1.15, n), 0.5, 25)
    unpl = rng.poisson(0.35 * h_since / 1000 * np.array([w[e] for e in env]) / 1.3)  # 비계획 정비 건수(환경이 가혹할수록 많다)
    n_maint = rng.poisson(0.6 * h_since / 1000 + 1)                                # 계획 정비 건수
    scale = 9600 / np.array([w[e] for e in env]) * 0.985 ** unpl * np.exp(rng.normal(0, 0.04, n))
    t_fail = scale * rng.weibull(KSHAPE, n)                                       # 3단계 정비 후 고장까지 운용시간(숨은 정답)
    event = (t_fail <= h_since).astype(int)
    dur = np.where(event == 1, t_fail, h_since)
    df = pd.DataFrame({"eq_id": [f"EQ{seed:02d}{i:04d}" for i in range(n)], "unit": unit, "env": env, "etype": et, "rate": rate, "hours": hours, "km": km, "age_y": age_y, "n_ovh": n_ovh,
                       "h_since": h_since, "unpl": unpl, "n_maint": n_maint, "t_fail": t_fail, "event": event, "dur": dur})
    df["insp"] = np.clip(dur / t_fail + rng.normal(0, INSP_NOISE, n), 0, 1.3)       # 마지막 정비 점검에서 측정한 마모 비율(소모 수명/총 수명, 오차 포함)
    df["rul_h"] = np.where(event == 0, t_fail - h_since, np.nan)                  # 생존 장비의 남은 운용시간(정답)
    df["rul_d"] = df["rul_h"] / df["rate"]                                        # 남은 일수(정답)
    return df


def mape(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return float(np.mean(np.abs(y - p) / np.abs(y)) * 100)


def mae(y, p):
    return float(np.mean(np.abs(np.asarray(y, float) - np.asarray(p, float))))


def rmse(y, p):
    return float(np.sqrt(np.mean((np.asarray(y, float) - np.asarray(p, float)) ** 2)))
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 노후화 파생 피처와 학습 표본 만들기. 환경 가중치 W0는 도입 시점의 전문가 추정값이며(실제 가중치와 다름) M9에서 재보정한다.
# ---------------------------------------------------------------------------
W0 = {"normal": 1.00, "rough": 1.15, "salt": 1.10, "cold": 1.05}
FEATS = ["h_since", "hours", "km", "age_y", "rate", "n_maint", "unpl", "unpl_per_kh", "km_per_h", "n_ovh", "k_rough", "k_salt", "k_cold", "k_truck", "k_gen", "k_trailer",
         "aging_idx", "lin_rul_d", "hs_frac", "insp", "insp_eta_h"]


def add_features(df, w=None):
    d = df.copy()
    w = w or W0
    d["unpl_per_kh"] = d["unpl"] / (d["h_since"] / 1000 + 0.5)
    d["km_per_h"] = d["km"] / d["hours"]
    for e in ("rough", "salt", "cold"):
        d["k_" + e] = (d["env"] == e).astype(int)
    d["k_truck"], d["k_gen"], d["k_trailer"] = (d["etype"] == "truck").astype(int), (d["etype"] == "generator").astype(int), (d["etype"] == "trailer").astype(int)
    d["aging_idx"] = d["h_since"] * d["env"].map(w) / CYCLE                      # 환경 가중 노후 지수(1이면 3단계 정비 주기에 도달)
    d["lin_rul_d"] = (CYCLE - d["h_since"]) / d["rate"]                           # 선형 감가상각 잔여 일수(Baseline)
    d["hs_frac"] = d["h_since"] / CYCLE
    d["insp_eta_h"] = d["h_since"] / np.maximum(d["insp"], 0.05)                  # 점검 마모 비율로 환산한 총 수명 추정(h)
    return d


def snapshots(df, k=4, seed=0):
    """고장 이력 장비의 과거 시점 표본: 고장 전 임의 시점의 점검값·운용시간과 그때의 남은 일수. (생존 장비의 미래는 알 수 없으므로 고장 이력만 쓴다)"""
    rng = np.random.default_rng(seed)
    f = df[df["event"] == 1]
    out = []
    for _ in range(k):
        s = f.copy()
        h = s["t_fail"] * rng.uniform(0.2, 0.98, len(s))
        ratio = h / s["h_since"]
        s["hours"] = s["hours"] - (s["h_since"] - h)
        s["km"] = s["km"] * ratio.clip(upper=1)
        s["unpl"] = np.floor(s["unpl"] * ratio)
        s["n_maint"] = np.floor(s["n_maint"] * ratio)
        s["insp"] = np.clip(h / s["t_fail"] + rng.normal(0, INSP_NOISE, len(s)), 0, 1.3)
        s["h_since"] = h
        s["rul_d"] = (s["t_fail"] - h) / s["rate"]
        s["event"] = 0
        out.append(s)
    return pd.concat(out, ignore_index=True)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 생존 분석 도구(scipy만 사용): 와이블 AFT(가속 수명) 모형과 Cox 비례위험 모형
# ---------------------------------------------------------------------------
from scipy.optimize import minimize


def aft_x(d):
    return np.c_[np.ones(len(d)), d["env"].eq("rough"), d["env"].eq("salt"), d["env"].eq("cold"), d["unpl"] / (d["h_since"] / 1000 + 0.5)].astype(float)


AFT_COLS = ["절편", "험지", "염분", "혹한", "비계획 정비율"]


def fit_aft(d):
    """3단계 정비 후 운용시간 dur(고장이면 event=1, 생존이면 중도절단)에 대한 와이블 AFT 최대우도 추정. 반환: 계수(마지막은 log 형상)."""
    x, t, e = aft_x(d), d["dur"].values, d["event"].values

    def nll(p):
        lam, k = np.exp(x @ p[:-1]), np.exp(p[-1])
        z = (t / lam) ** k
        return -(e * (np.log(k) - np.log(lam) + (k - 1) * (np.log(t) - np.log(lam))) - z).sum()

    r = minimize(nll, np.r_[np.log(8000), np.zeros(x.shape[1] - 1), np.log(5)], method="BFGS")
    return r.x


def aft_pred(p, d, q=0.5, h=None):
    """이미 h(운용시간)까지 생존했다는 조건에서 분위수 q 생존 시점(운용시간 h 기준 총 수명)을 돌려준다. q=0.5가 조건부 중앙값."""
    lam, k = np.exp(aft_x(d) @ p[:-1]), np.exp(p[-1])
    h = d["h_since"].values if h is None else h
    return lam * ((h / lam) ** k - np.log(q)) ** (1 / k)


def aft_fail_prob(p, d, h0, h1):
    """h0까지 생존한 장비가 h0~h1 사이에 고장 날 조건부 확률."""
    lam, k = np.exp(aft_x(d) @ p[:-1]), np.exp(p[-1])
    s0, s1 = np.exp(-(h0 / lam) ** k), np.exp(-(h1 / lam) ** k)
    return 1 - s1 / s0


def fit_cox(d, iters=25):
    """Cox 비례위험(Breslow 근사) 뉴턴-랩슨. 공변량: 험지·염분·혹한·비계획 정비율. 반환: 계수."""
    x = aft_x(d)[:, 1:]
    o = np.argsort(-d["dur"].values)
    x, e = x[o], d["event"].values[o]
    b = np.zeros(x.shape[1])
    for _ in range(iters):
        r = np.exp(x @ b)
        S0 = np.cumsum(r)
        S1 = np.cumsum(r[:, None] * x, axis=0)
        S2 = np.cumsum(r[:, None, None] * x[:, :, None] * x[:, None, :], axis=0)
        m1 = S1 / S0[:, None]
        g = ((x - m1) * e[:, None]).sum(axis=0)
        H = -sum(e[i] * (S2[i] / S0[i] - np.outer(m1[i], m1[i])) for i in np.where(e == 1)[0])
        step = np.linalg.solve(H - 1e-6 * np.eye(len(b)), g)
        b = b - step
        if np.abs(step).max() < 1e-7:
            break
    return b


def cindex(time, event, risk):
    """일치도 C-index: 위험 점수가 높은 쪽이 먼저 고장 났는가(관측 가능한 쌍만)."""
    t, e, r = np.asarray(time), np.asarray(event), np.asarray(risk)
    num = den = 0.0
    for i in np.where(e == 1)[0]:
        m = t > t[i]
        den += m.sum()
        num += (r[m] < r[i]).sum() + 0.5 * (r[m] == r[i]).sum()
    return num / max(den, 1)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 잔여 수명(RUL, 일) 예측 엔진: 와이블 AFT 조건부 중앙값 + 그래디언트 부스팅(고장 이력 시점 표본 학습)의 평균
# ---------------------------------------------------------------------------
from sklearn.ensemble import GradientBoostingRegressor


def fit_engine(train, seed=0):
    p = fit_aft(train)
    sn = add_features(snapshots(train, 5, seed))
    sn["aft"] = (aft_pred(p, sn) - sn["h_since"]) / sn["rate"]
    g = GradientBoostingRegressor(n_estimators=250, max_depth=3, learning_rate=0.06, random_state=0).fit(sn[FEATS + ["aft"]], sn["rul_d"])
    return {"p": p, "g": g}


def predict_rul(eng, d):
    """d는 add_features를 거친 표. 반환: (앙상블 RUL, AFT RUL, GBR RUL) - 일 단위."""
    aft = ((aft_pred(eng["p"], d) - d["h_since"]) / d["rate"]).values
    x = d[FEATS].copy()
    x["aft"] = aft
    gb = eng["g"].predict(x)
    return np.clip(0.5 * aft + 0.5 * gb, 1, None), aft, gb
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 계획정비(3단계 정비) 일정 추천: 월별 정비센터 능력·예산·시효성 부품 키트(유효기한) 제약 아래 기대 비용 최소화 (비용 단가는 교육용 가정값, 만원)
# ---------------------------------------------------------------------------
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.stats import norm

C_PLAN, C_FAIL, C_WASTE_KH, C_KIT = 600.0, 2400.0, 40.0, 120.0       # 계획 3단계 정비, 비계획 고장(긴급 정비 포함), 미사용 수명 1000h당 손실, 시효성 부품 키트
HORIZON, MDAYS = 12, 30                                                # 계획 12개월, 월 30일
CAP_M, BUDGET_M = 22, 15000.0                                          # 월별 정비센터 능력(대), 월별 예산
LOTS = [(30, 70), (45, 170), (45, 390), (70, 800)]                     # 시효성 키트 로트(수량, 유효기한까지 남은 일수)
KIT_MARGIN = 14                                                        # 정비일 기준 최소 유효기간 여유(일)


def exp_cost_matrix(pred, rate, month_days):
    """장비 i를 월 m에 정비할 때의 기대 비용. 참 RUL ~ N(pred, sigma), sigma = 35일 + 0.12 x pred (가정). 마지막 열은 계획 기간 밖(미정비)."""
    sig = 35 + 0.12 * pred
    C = np.zeros((len(pred), len(month_days) + 1))
    for j, day in enumerate(month_days):
        z = (day - pred) / sig
        pf = norm.cdf(z)
        unused = np.maximum(pred - day, 0) * rate * 0.6                                   # 정비를 앞당긴 만큼 버리는 운용시간 h(근사)
        C[:, j] = C_PLAN + C_KIT + pf * (C_FAIL - C_PLAN) + C_WASTE_KH * unused / 1000 * (1 - pf)
    C[:, -1] = norm.cdf((HORIZON * MDAYS - pred) / sig) * C_FAIL
    return C


def plan_milp(pred, rate, cap=CAP_M, budget=BUDGET_M, lots=LOTS, use_kit=True):
    """정수계획으로 장비별 정비 월(0~11) 또는 미정비(-1)를 배정한다. 후보는 예측 RUL이 계획 기간 +90일 이내인 장비."""
    md = np.arange(1, HORIZON + 1) * MDAYS
    cand = np.where(pred < HORIZON * MDAYS + 90)[0]
    n, M = len(cand), HORIZON
    C = exp_cost_matrix(pred[cand], rate[cand], md)
    c = C.ravel()
    A, lo, hi = [], [], []
    for i in range(n):                                              # 장비당 한 번만 배정(월 12칸 + 미정비)
        row = np.zeros(n * (M + 1)); row[i * (M + 1):(i + 1) * (M + 1)] = 1; A.append(row); lo.append(1); hi.append(1)
    for m in range(M):                                              # 월별 능력·예산
        row = np.zeros(n * (M + 1)); row[m::(M + 1)] = 1
        A.append(row); lo.append(0); hi.append(cap)
        A.append(row * (C_PLAN + C_KIT)); lo.append(0); hi.append(budget)
    if use_kit:                                                     # 시효성 키트: m월 이후 정비 수요는 그 시점에 유효기간이 남은 로트 수량을 넘을 수 없다
        for m in range(M):
            sup = sum(q for q, e in lots if e >= md[m] + KIT_MARGIN)
            row = np.zeros(n * (M + 1))
            for mm in range(m, M):
                row[mm::(M + 1)] = 1
            A.append(row); lo.append(0); hi.append(sup)
    r = milp(c, constraints=LinearConstraint(np.array(A), lo, hi), integrality=np.ones(len(c)), bounds=Bounds(0, 1), options={"time_limit": 20})
    month = np.full(len(pred), -1)
    if r.x is not None:
        x = np.round(r.x).reshape(n, M + 1)
        assign = np.where(x[:, :M].sum(axis=1) > 0.5, x[:, :M].argmax(axis=1), -1)
        month[cand] = assign
    return month


def plan_greedy(pred, margin=45, cap=CAP_M, budget=BUDGET_M):
    """간단한 탐욕 배정: 정비 목표일(예측 RUL - margin)이 빠른 순으로 목표일 이전 가장 늦은 빈 월, 없으면 가장 이른 빈 월에 배정."""
    cap = min(cap, int(budget // (C_PLAN + C_KIT)))                 # 월 예산이 허용하는 대수로 능력을 제한
    month = np.full(len(pred), -1)
    left = np.full(HORIZON, cap)
    for i in np.argsort(pred):
        if pred[i] > HORIZON * MDAYS + 60: break
        tgt = int(np.clip((pred[i] - margin) // MDAYS - 1, 0, HORIZON - 1))
        for m in list(range(tgt, -1, -1)) + list(range(tgt + 1, HORIZON)):
            if left[m] > 0:
                month[i] = m; left[m] -= 1; break
    return month


def plan_fixed(lin_rul, cap=CAP_M, budget=BUDGET_M):
    """관행: 규정 주기 도달 순서대로(선형 잔여 일수) 월별 능력 안에서 배정."""
    return plan_greedy(np.asarray(lin_rul, float), margin=0, cap=cap, budget=budget)


def evaluate_plan(month, true_rul, rate, cost_kit=True):
    """참 RUL로 계획의 실제 비용을 계산한다: 정비일 이전에 고장 -> 비계획 고장 비용, 아니면 계획 비용 + 미사용 수명 손실."""
    day = np.where(month >= 0, (month + 1) * MDAYS, 10 ** 9)
    fail = (true_rul < day) & (true_rul < HORIZON * MDAYS)
    planned = (month >= 0) & ~fail
    waste = np.where(planned, (true_rul - day) * rate * 0.6, 0) * C_WASTE_KH / 1000
    cost = fail * C_FAIL + planned * (C_PLAN + (C_KIT if cost_kit else 0)) + waste
    return {"total": float(cost.sum()), "fail": int(fail.sum()), "planned": int(planned.sum()), "waste": float(waste.sum()), "unsched_fail": int(((month < 0) & fail).sum())}


def kit_fefo(month, lots=LOTS):
    """유효기한이 빠른 로트부터 쓰는 FEFO로 키트를 배정하고 정비일에 유효기간이 부족한 배정 수와 만료 폐기 수량을 센다."""
    q = [[qty, e] for qty, e in sorted(lots, key=lambda t: t[1])]
    short = 0
    for m in sorted(month[month >= 0]):
        day = (m + 1) * MDAYS
        for lot in q:
            if lot[1] >= day + KIT_MARGIN and lot[0] > 0:
                lot[0] -= 1; break
        else:
            short += 1
    expired = sum(l[0] for l in q if l[1] < HORIZON * MDAYS)
    return {"short": short, "expired_unused": expired, "left": sum(l[0] for l in q)}
# ---------------------------------------------------------------------------

OPS_W = {"normal": 1.00, "rough": 1.55, "salt": 1.15, "cold": 1.30}            # 운영 기간의 숨은 환경 가중치(도입 당시와 달라진 가정)
tr = make_fleet(900, seed=1)
eng0 = fit_engine(tr)
A = make_fleet(700, seed=60, env_w=OPS_W, shift=1.2)                              # AAR 대상 운영 장비
B = make_fleet(700, seed=70, env_w=OPS_W, shift=1.2)                              # 재보정에 쓰지 않는 보류 장비

# ---------------- 1) AAR: 운영 예측 오차 분석 ----------------
Af = add_features(A)
al = Af[Af.event == 0].reset_index(drop=True)
pred, _, _ = predict_rul(eng0, al)
y = al["rul_d"].values
al["err"] = pred - y                                                              # 양수 = 수명을 길게 예측(위험)
big = y >= 90
print(f"[1] AAR 대상 운영 장비 {len(A)}대(생존 {len(al)}대, 고장 {int(A.event.sum())}대): 현행 엔진 MAE {mae(y, pred):.0f}일, RMSE {rmse(y, pred):.0f}일, MAPE {mape(y[big], pred[big]):.1f}%, R2 {r2_score(y, pred):.3f}, 평균 편향 {al.err.mean():+.0f}일")
ct = pd.DataFrame([(k, int(m.sum()), mae(y[m.values], pred[m.values]), al.err[m].mean()) for k, m in {"일반": al.env == "normal", "험지": al.env == "rough", "염분": al.env == "salt", "혹한": al.env == "cold",
                   "일 가동률 4h 이상": al.rate >= 4, "비계획 정비율 상위 25%": al.unpl_per_kh >= al.unpl_per_kh.quantile(.75)}.items()], columns=["조건", "대수", "MAE(일)", "평균 편향(일)"])
print(ct.round(0).to_string(index=False))
worst = al.reindex(al.err.abs().sort_values(ascending=False).index).head(40)


def cause(r):
    if r.env == "rough" and r.err > 0: return "험지 가혹도 과소 반영"
    if r.env == "cold" and r.err > 0: return "혹한 가혹도 과소 반영"
    if r.env == "salt" and r.err < 0: return "염분 가혹도 과대 반영"
    if r.rate >= 4: return "가동률 상승(운용 강도 변화)"
    if r.unpl_per_kh >= 1.2: return "비계획 정비 다수"
    return "기타(개체 편차)"


cs = worst.apply(cause, axis=1).value_counts()
print("    오차 큰 상위 40대의 원인 분류:", ", ".join(f"{k} {v}대({v / 40:.0%})" for k, v in cs.items()))

# ---------------- 2) 재보정: 환경 가중치 -> 운영 데이터 재학습 ----------------
pa = fit_aft(A)
life_ratio = np.exp(pa[1:4])
W1 = {"normal": 1.0, "rough": 1 / life_ratio[0], "salt": 1 / life_ratio[1], "cold": 1 / life_ratio[2]}
wt = pd.DataFrame({"도입 시 추정(W0)": W0, "재보정(운영 AFT)": W1, "숨은 정답(운영)": OPS_W}).loc[ENVS]
wt["변화율"] = wt["재보정(운영 AFT)"] / wt["도입 시 추정(W0)"] - 1
print("\n[2] 환경 가중치 매트릭스(클수록 빨리 노후)")
print(wt.round(3).to_string())
flag = wt[wt["변화율"].abs() > 0.2].index.tolist()
print(f"    변화율 20% 초과 환경 {flag or '없음'}는 정비계획관 검토·물자 책임자 승인 뒤 적용한다(자동 반영 금지).")
eng1 = fit_engine(A, seed=1)
Bf0, Bf1 = add_features(B, W0), add_features(B, W1)
bl0, bl1 = Bf0[Bf0.event == 0].reset_index(drop=True), Bf1[Bf1.event == 0].reset_index(drop=True)
p0, _, _ = predict_rul(eng0, bl0)
p1, _, _ = predict_rul(eng1, bl1)
yb = bl0["rul_d"].values
bb = yb >= 90
tab = pd.DataFrame({"재보정 전": [mae(yb, p0), rmse(yb, p0), mape(yb[bb], p0[bb]), r2_score(yb, p0), (p0 - yb).mean()], "재보정 후": [mae(yb, p1), rmse(yb, p1), mape(yb[bb], p1[bb]), r2_score(yb, p1), (p1 - yb).mean()]},
                   index=["MAE(일)", "RMSE(일)", "MAPE(%)", "R2", "평균 편향(일)"])
print(f"\n[3] 보류 장비 {len(bl0)}대(재보정에 쓰지 않음) 검증\n" + tab.round(3).to_string())
print(f"    MAE {1 - tab.loc['MAE(일)', '재보정 후'] / tab.loc['MAE(일)', '재보정 전']:.1%} 감소, 환경별 편향(전 -> 후):", ", ".join(f"{e} {(p0 - yb)[(bl0.env == e).values].mean():+.0f} -> {(p1 - yb)[(bl0.env == e).values].mean():+.0f}" for e in ENVS))

# ---------------- 3) ROI 3대 지표(교육용 가정) ----------------
rate_b, true_b = bl0["rate"].values, yb
m0, m1 = plan_milp(p0, rate_b), plan_milp(p1, rate_b)
r0, r1 = evaluate_plan(m0, true_b, rate_b), evaluate_plan(m1, true_b, rate_b)
D_FAIL, D_PLAN = 45, 12                                                           # 비계획 고장/계획 3단계 정비 가동 중단 일수(가정)
down0, down1 = r0["fail"] * D_FAIL + r0["planned"] * D_PLAN, r1["fail"] * D_FAIL + r1["planned"] * D_PLAN
SCALE, INV, OPEX = 1.0, 12000.0, 1200.0                                           # 관리 장비 규모 배수(연), 도입 비용, 연 운영비(만원)


def roi(c0, c1, d0, d1, scale=SCALE, inv=INV):
    save = (c0 - c1) * scale - OPEX
    return save, 1 - d1 / d0, inv / max(save / 12, 1e-9)


sv, tr_, pb = roi(r0["total"], r1["total"], down0, down1)
print(f"\n[4] 12개월 계획 비교(보류 장비): 비용 {r0['total']:,.0f} -> {r1['total']:,.0f}만원, 비계획 고장 {r0['fail']} -> {r1['fail']}대, 계획 정비 {r0['planned']} -> {r1['planned']}대")
print(f"    ROI 3대 지표 [교육용 가정: 관리 규모 x{SCALE:.0f}, 도입 {INV:.0f}만원, 운영 {OPEX:.0f}만원/년, 고장 중단 {D_FAIL}일·3단계 정비 {D_PLAN}일]")
print(f"    (1) 연간 비용 절감액 {sv:,.0f}만원  (2) 가동 중단일수 단축률 {tr_:.1%}({down0:,}일 -> {down1:,}일)  (3) 투자 회수 기간 {pb:.1f}개월")
print("    산식: 절감액 = (재보정 전 - 후 12개월 비용) x 규모 - 운영비, 단축률 = 1 - 후 중단일수/전 중단일수, 회수 기간 = 도입비 / (월 절감액)")
print("    관리 규모 민감도:", "; ".join(f"x{s} -> 절감 {roi(r0['total'], r1['total'], down0, down1, scale=s)[0]:,.0f}만원, 회수 {roi(r0['total'], r1['total'], down0, down1, scale=s)[2]:.0f}개월" for s in (0.5, 1, 2, 3)))
half = r0["total"] - (r0["total"] - r1["total"]) / 2
print(f"    비관(재보정 효과 절반만 실현, x1): 절감 {roi(r0['total'], half, down0, down1, scale=1)[0]:,.0f}만원, 회수 {roi(r0['total'], half, down0, down1, scale=1)[2]:.0f}개월")
print("    가정값이므로 재정·기획 부서와 실제 단가로 다시 산정해야 한다. 재보정 가중치는 물자 책임자 승인 후 운영에 반영한다.")

fig, ax = plt.subplots(1, 3, figsize=(15, 4.3))
ax[0].bar(range(len(ct)), ct["평균 편향(일)"]); ax[0].set_xticks(range(len(ct))); ax[0].set_xticklabels([f"C{i + 1}" for i in range(len(ct))]); ax[0].set_title("AAR: mean bias by condition (days)")
x = np.arange(4); ax[1].bar(x - .27, wt["도입 시 추정(W0)"], .27, label="initial W0"); ax[1].bar(x, wt["재보정(운영 AFT)"], .27, label="recalibrated"); ax[1].bar(x + .27, wt["숨은 정답(운영)"], .27, label="hidden truth")
ax[1].set_xticks(x); ax[1].set_xticklabels(ENVS); ax[1].legend(); ax[1].set_title("Environment weight matrix")
ax[2].scatter(yb, p0, s=6, alpha=.5, label="before"); ax[2].scatter(yb, p1, s=6, alpha=.5, label="after"); ax[2].plot([0, 4000], [0, 4000], "k--"); ax[2].legend(); ax[2].set_title("Hold-out RUL: true vs predicted (days)")
plt.tight_layout(); plt.show()
