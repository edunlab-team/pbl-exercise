"""장비 운용 시간·기동 거리·정비 이력·3단계 정비 주기와 시효성 부품 키트 로트의 데이터셋 스키마를 설계하고 데이터 사전(피처 20개 이상)을 실제 생성 데이터와 대조하며, 허용값 검증기에 오류 6종을 주입해 검출하고 장비 수명관리 업무 프로세스 맵을 만든다."""
import copy
import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# [교육용가상자료] 가상 장비 보유 현황·고장 이력 생성기 (실제 조직·장비·수치 없음)
# 가상 조직 6개(U1~U6)의 장비가 운용 환경(normal/rough/salt/cold)에 따라 다른 속도로 노후화한다. 3단계 정비 후 운용시간(h_since)이
# 장비마다 숨은 수명(t_fail)을 넘으면 고장(event=1) 이력, 넘지 않았으면 현재까지 생존(event=0, 관측 중도절단)이다.
# ---------------------------------------------------------------------------
ENVS = ["normal", "rough", "salt", "cold"]
ENV_W = {"normal": 1.00, "rough": 1.35, "salt": 1.25, "cold": 1.12}              # 환경 가중치(숨은 정답, 가정값): 클수록 수명이 짧다
ENV_KO = {"normal": "일반", "rough": "험지", "salt": "염분", "cold": "혹한"}
UNITS = ["U1", "U2", "U3", "U4", "U5", "U6"]
UNIT_ENV = {"U1": [.7, .1, .1, .1], "U2": [.2, .6, .1, .1], "U3": [.2, .1, .6, .1], "U4": [.3, .1, .1, .5], "U5": [.5, .3, .1, .1], "U6": [.4, .1, .4, .1]}
ETYPES = ["truck", "generator", "trailer", "radio"]
CYCLE = 8000.0                                                                    # 규정 3단계 정비 주기(운용시간 h, 가정값)
KSHAPE = 12.0                                                                     # 수명 분포 와이블 형상(마모형 고장, 클수록 수명이 모여 있다)
INSP_NOISE = 0.025                                                                # 정비 점검 마모 비율 측정 오차(가정값)


def make_fleet(n=900, seed=0, env_w=None, shift=1.0):
    """장비 n대. env_w로 숨은 환경 가중치를 바꿔 운영 분포 변화를 모의할 수 있다. shift>1이면 가동률이 높아진다."""
    rng = np.random.default_rng(seed)
    w = env_w or ENV_W
    unit = rng.choice(UNITS, n)
    env = np.array([rng.choice(ENVS, p=UNIT_ENV[u]) for u in unit])
    et = rng.choice(ETYPES, n, p=[.4, .2, .2, .2])
    rate = rng.lognormal(np.log(3.0 * shift), 0.25, n)                            # 일 평균 운용시간(h/일)
    h_since = rng.uniform(300, 11500, n)                                          # 마지막 3단계 정비 이후 운용시간
    n_ovh = rng.integers(0, 3, n)
    hours = h_since + n_ovh * rng.uniform(5000, 8000, n)                          # 누적 운용시간
    km = hours * rng.normal(17, 3, n) * np.where(env == "rough", 0.8, 1.0)         # 누적 기동거리(km)
    age_y = np.clip(hours / (rate * 365) * rng.uniform(0.9, 1.15, n), 0.5, 25)
    unpl = rng.poisson(0.35 * h_since / 1000 * np.array([w[e] for e in env]) / 1.3)  # 비계획 정비 건수(환경이 가혹할수록 많다)
    n_maint = rng.poisson(0.6 * h_since / 1000 + 1)                                # 계획 정비 건수
    scale = 9600 / np.array([w[e] for e in env]) * 0.985 ** unpl * np.exp(rng.normal(0, 0.04, n))
    t_fail = scale * rng.weibull(KSHAPE, n)                                       # 3단계 정비 후 고장까지 운용시간(숨은 정답)
    event = (t_fail <= h_since).astype(int)
    dur = np.where(event == 1, t_fail, h_since)
    df = pd.DataFrame({"eq_id": [f"EQ{seed:02d}{i:04d}" for i in range(n)], "unit": unit, "env": env, "etype": et, "rate": rate, "hours": hours, "km": km, "age_y": age_y, "n_ovh": n_ovh,
                       "h_since": h_since, "unpl": unpl, "n_maint": n_maint, "t_fail": t_fail, "event": event, "dur": dur})
    df["insp"] = np.clip(dur / t_fail + rng.normal(0, INSP_NOISE, n), 0, 1.3)       # 마지막 정비 점검에서 측정한 마모 비율(소모 수명/총 수명, 오차 포함)
    df["rul_h"] = np.where(event == 0, t_fail - h_since, np.nan)                  # 생존 장비의 남은 운용시간(정답)
    df["rul_d"] = df["rul_h"] / df["rate"]                                        # 남은 일수(정답)
    return df


def mape(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return float(np.mean(np.abs(y - p) / np.abs(y)) * 100)


def mae(y, p):
    return float(np.mean(np.abs(np.asarray(y, float) - np.asarray(p, float))))


def rmse(y, p):
    return float(np.sqrt(np.mean((np.asarray(y, float) - np.asarray(p, float)) ** 2)))
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 노후화 파생 피처와 학습 표본 만들기. 환경 가중치 W0는 도입 시점의 전문가 추정값이며(실제 가중치와 다름) M9에서 재보정한다.
# ---------------------------------------------------------------------------
W0 = {"normal": 1.00, "rough": 1.15, "salt": 1.10, "cold": 1.05}
FEATS = ["h_since", "hours", "km", "age_y", "rate", "n_maint", "unpl", "unpl_per_kh", "km_per_h", "n_ovh", "k_rough", "k_salt", "k_cold", "k_truck", "k_gen", "k_trailer",
         "aging_idx", "lin_rul_d", "hs_frac", "insp", "insp_eta_h"]


def add_features(df, w=None):
    d = df.copy()
    w = w or W0
    d["unpl_per_kh"] = d["unpl"] / (d["h_since"] / 1000 + 0.5)
    d["km_per_h"] = d["km"] / d["hours"]
    for e in ("rough", "salt", "cold"):
        d["k_" + e] = (d["env"] == e).astype(int)
    d["k_truck"], d["k_gen"], d["k_trailer"] = (d["etype"] == "truck").astype(int), (d["etype"] == "generator").astype(int), (d["etype"] == "trailer").astype(int)
    d["aging_idx"] = d["h_since"] * d["env"].map(w) / CYCLE                      # 환경 가중 노후 지수(1이면 3단계 정비 주기에 도달)
    d["lin_rul_d"] = (CYCLE - d["h_since"]) / d["rate"]                           # 선형 감가상각 잔여 일수(Baseline)
    d["hs_frac"] = d["h_since"] / CYCLE
    d["insp_eta_h"] = d["h_since"] / np.maximum(d["insp"], 0.05)                  # 점검 마모 비율로 환산한 총 수명 추정(h)
    return d


def snapshots(df, k=4, seed=0):
    """고장 이력 장비의 과거 시점 표본: 고장 전 임의 시점의 점검값·운용시간과 그때의 남은 일수. (생존 장비의 미래는 알 수 없으므로 고장 이력만 쓴다)"""
    rng = np.random.default_rng(seed)
    f = df[df["event"] == 1]
    out = []
    for _ in range(k):
        s = f.copy()
        h = s["t_fail"] * rng.uniform(0.2, 0.98, len(s))
        ratio = h / s["h_since"]
        s["hours"] = s["hours"] - (s["h_since"] - h)
        s["km"] = s["km"] * ratio.clip(upper=1)
        s["unpl"] = np.floor(s["unpl"] * ratio)
        s["n_maint"] = np.floor(s["n_maint"] * ratio)
        s["insp"] = np.clip(h / s["t_fail"] + rng.normal(0, INSP_NOISE, len(s)), 0, 1.3)
        s["h_since"] = h
        s["rul_d"] = (s["t_fail"] - h) / s["rate"]
        s["event"] = 0
        out.append(s)
    return pd.concat(out, ignore_index=True)
# ---------------------------------------------------------------------------

# 1) 데이터 사전 (필드, 구분, 자료형, 허용 범위/값, 설명)
DICT = [
    ("eq_id", "식별", "str", r"^EQ\d{6}$", "장비 식별코드(가상)"), ("unit", "식별", "str", "U1~U6", "가상 조직 코드"), ("etype", "식별", "str", "truck|generator|trailer|radio", "장비 구분(가상)"),
    ("env", "환경", "str", "normal|rough|salt|cold", "주 운용 환경(일반/험지/염분/혹한)"), ("rate", "운용", "float", "0.5~20", "일 평균 운용시간(h/일)"),
    ("hours", "운용", "float", "0~60000", "누적 운용시간(h)"), ("km", "운용", "float", "0~", "누적 기동거리(km)"), ("age_y", "운용", "float", "0.5~25", "사용 연수(년)"),
    ("n_ovh", "정비", "int", "0~5", "3단계 정비 이력 횟수"), ("h_since", "정비", "float", "0~hours", "마지막 3단계 정비 이후 운용시간(h)"), ("unpl", "정비", "int", "0~", "비계획 정비 건수(긴급 포함)"),
    ("n_maint", "정비", "int", "0~", "계획 정비 건수"), ("insp", "정비", "float", "0~1.3", "정비 점검 마모 비율(소모 수명/총 수명)"),
    ("t_fail", "라벨", "float", "0~", "고장까지 운용시간 - 모의 정답(실제 운용에는 없음)"), ("event", "라벨", "int", "0|1", "고장 여부(1=고장 이력, 0=생존)"),
    ("dur", "라벨", "float", "0~", "관측 운용시간(고장 시점 또는 중도절단)"), ("rul_h", "라벨", "float", "0~", "남은 운용시간 - 모의 정답"), ("rul_d", "라벨", "float", "0~", "남은 일수 - 모의 정답"),
    ("unpl_per_kh", "파생", "float", "0~", "1000h당 비계획 정비율"), ("km_per_h", "파생", "float", "5~40", "운용시간당 기동거리"), ("k_rough", "파생", "int", "0|1", "험지 더미"),
    ("k_salt", "파생", "int", "0|1", "염분 더미"), ("k_cold", "파생", "int", "0|1", "혹한 더미"), ("k_truck", "파생", "int", "0|1", "차량 더미"), ("k_gen", "파생", "int", "0|1", "발전기 더미"),
    ("k_trailer", "파생", "int", "0|1", "트레일러 더미"), ("aging_idx", "파생", "float", "0~2", "환경 가중 노후 지수(1이면 주기 도달)"), ("lin_rul_d", "파생", "float", "-", "선형 감가상각 잔여 일수"),
    ("hs_frac", "파생", "float", "0~2", "3단계 정비 주기 대비 경과 비율"), ("insp_eta_h", "파생", "float", "0~", "점검 마모로 환산한 총 수명 추정(h)")]
dd = pd.DataFrame(DICT, columns=["필드", "구분", "형", "허용값", "설명"])
print(f"[1] 데이터 사전 {len(dd)}개 필드 " + str(dd["구분"].value_counts().to_dict()))
LOT_SCHEMA = [("lot_id", "str", "시효성 부품 키트 로트 번호"), ("qty", "int", "재고 수량(개)"), ("expiry_d", "int", "유효기한까지 남은 일수"), ("margin", "int", "정비일 기준 최소 유효기간 여유 14일(규칙)")]
print("    시효성 부품 키트 로트 스키마:", ", ".join(f"{a}({b})" for a, b, _ in LOT_SCHEMA), "- 정비 예정일에 유효기간이 부족한 키트는 쓸 수 없다")

# 2) 실제 생성 데이터와 대조
df = make_fleet(300, seed=1)
feat = add_features(df)
miss = sorted(set(feat.columns) - set(dd["필드"]))
extra = sorted(set(dd["필드"]) - set(feat.columns))
fe = dd[~dd["구분"].isin(["라벨", "식별"])]
print(f"[2] 데이터 사전 대조({len(feat)}행): 사전 누락 컬럼 {miss or '없음'}, 데이터에 없는 필드 {extra or '없음'}")
print(f"    예측 피처 후보(식별·라벨 제외) {len(fe)}개 -> 목표(20개 이상) {'달성' if len(fe) >= 20 else '미달'} / 3단계 정비 규정 주기 {CYCLE:.0f}h(가정)")

# 3) 허용값 검증기와 오류 주입
RULES = {"eq_id": lambda s: s.astype(str).str.match(r"^EQ\d{6}$"), "unit": lambda s: s.isin(UNITS), "env": lambda s: s.isin(ENVS), "rate": lambda s: s.between(0.5, 20),
         "hours": lambda s: s.between(0, 60000), "h_since": lambda s: s >= 0, "insp": lambda s: s.between(0, 1.3), "age_y": lambda s: s.between(0.5, 25)}


def validate(d):
    bad = {}
    for c, f in RULES.items():
        n = int((~f(d[c])).sum() + d[c].isna().sum())
        if n: bad[c] = n
    n = int((d["h_since"] > d["hours"] + 1e-6).sum())
    if n: bad["h_since>hours(모순)"] = n
    n = int(d["eq_id"].duplicated().sum())
    if n: bad["eq_id 중복"] = n
    n = int((d["km"] / d["hours"].clip(lower=1) > 60).sum())
    if n: bad["km 단위 의심"] = n
    return bad


print(f"\n[3] 정상 샘플 {len(df)}건 검증 오류 {sum(validate(df).values())}건")
inj = {"환경 표기 오류": ("env", 0, "험지"), "운용시간 음수": ("hours", 1, -120.0), "미등록 조직": ("unit", 2, "U9"), "점검 마모 비율 범위 초과": ("insp", 3, 2.5),
       "3단계 정비 후 시간이 누적보다 큼": ("h_since", 4, 99999.0), "km 단위 오류(m)": ("km", 5, 1.2e7)}
det = 0
for name, (col, i, val) in inj.items():
    d2 = copy.deepcopy(df)
    d2.loc[i, col] = val
    bad = validate(d2)
    ok = bool(bad)
    det += ok
    print(f"    - {name}: {'검출' if ok else '미검출'} {bad}")
print(f"    주입 오류 {len(inj)}종 중 {det}종 검출")

# 4) 장비 수명관리 업무 프로세스 맵
proc = [("정비 소요·고장 이력 접수", "정비계획관", "정비 요청, 고장 보고", "고장 이력 표", 30), ("운용시간·기동거리 집계", "운용 담당", "일일 운용 보고", "hours, km, rate", 25),
        ("정비 이력·점검 입력", "정비 담당", "정비·점검 기록", "n_maint, unpl, insp", 25), ("환경 가중치 적용", "분석 담당", "운용 환경 구분", "aging_idx", 15), ("잔여 수명 예측", "분석 담당", "피처 테이블", "RUL(일), 고장 확률", 40),
        ("정비센터 능력·예산 대조", "정비계획관", "월별 슬롯, 예산, 키트 재고", "정비 일정 후보", 35), ("정비 일정 확정·도태 건의", "물자 책임자", "추천안, 사유", "승인 일정", 30), ("정비 실행·결과 입력", "정비센터", "승인 일정", "정비 완료 기록", 20),
        ("예측 오차 환류(AAR)", "분석 담당", "예측 대 실적", "재보정 보고", 30)]
pm = pd.DataFrame(proc, columns=["단계", "담당", "입력", "산출", "현행(분)"])
pm.index = range(1, len(pm) + 1)
print(f"\n[4] 업무 프로세스 맵 {len(pm)}단계, 현행 합계 {pm['현행(분)'].sum()}분 (가장 긴 단계: {pm.loc[pm['현행(분)'].idxmax(), '단계']})")
print(pm.to_string())
print("\n프로세스 맵 작성 완료(9단계), 피처 목록 20개 이상 -> 목표", "달성" if len(pm) >= 5 and len(fe) >= 20 else "미달")
print("모든 조직·장비·수치는 교육용 가상 자료이며 실제 조직·장비와 무관하다.")
