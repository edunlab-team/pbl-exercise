from pathlib import Path
import sys
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from learning_support import check_baseline
@pytest.mark.parametrize("mission",range(1,11))
def test_baseline_execution_evidence(mission):
    check_baseline(mission)
