"""ADM01 교육용 실행 도구. 개인자료·실제 부대자료·네트워크 연결을 사용하지 않는다."""
from pathlib import Path
from functools import lru_cache
import copy, csv, hashlib, html, io, json, math, queue, re, threading, time, sys, traceback
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
VERSION = 'ADM01-2.0'
UNITS=[f'B{i:02}' for i in range(1,5)]
ROLES=[f'J{i:02}' for i in range(1,7)]
FIELDS=['week','unit','role','authorized','current','leave','sick','training','detached','overtime_h','night_ratio','shift_h','inflow','outflow','source_id']
KEY=['week','unit','role']
ABSENT=['leave','sick','training','detached']
HORIZON=13
ORIGINS=[52,65,78,91]

def native(x):
    if isinstance(x,(np.integer,)): return int(x)
    if isinstance(x,(np.floating,)): return float(x) if np.isfinite(x) else None
    if isinstance(x,np.ndarray): return [native(v) for v in x.tolist()]
    if isinstance(x,dict): return {str(k):native(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [native(v) for v in x]
    if isinstance(x,(Path,)): return str(x)
    if isinstance(x,pd.DataFrame): return json.loads(x.to_json(orient='records',force_ascii=False))
    if x is pd.NA: return None
    return x

def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(native(value),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    return path

def fingerprint(df):
    return hashlib.sha256(df.to_csv(index=False).encode()).hexdigest()[:16]

def make_weekly(seed=7,shock=False):
    """실제 유입·유출 인원을 기록한 뒤 현재원을 갱신합니다."""
    rng=np.random.default_rng(seed); rows=[]; labels=[]
    for ui,u in enumerate(UNITS):
        for ji,r in enumerate(ROLES):
            auth=24+ji*3+ui*2; current=auth-int(rng.integers(0,5))
            for w in range(1,105):
                surge=bool(shock and ui<2 and w>=84)
                seasonal=1.8 if w%52 in range(19,26) else 1.0
                out=min(current,int(rng.poisson(.35*seasonal+(1.1 if surge else 0))))
                incoming=int(rng.poisson(.25))+(int(rng.integers(2,5)) if w%13==0 else 0)
                # 예정된 유입과 실제 유입을 구분합니다. 상한을 적용한 차이는 실제 유입량에도 반영합니다.
                inflow=min(incoming,max(auth-current+out,0))
                current=current+inflow-out
                absent=rng.multinomial(current,[.055,.025,.045,.015,.86])[:4]
                avail=current-int(absent.sum())
                workload=auth*40*(.96+.025*ji)
                noise=float(rng.normal(0,1.2))
                ot=max(0,workload/avail-40+noise) if avail>0 else np.nan
                night=float(np.clip(rng.normal(.18+.035*ji,.06),0,.65))
                # 정답 라벨은 점수식을 복사하지 않고 별도의 교육용 사례 규칙으로 생성합니다.
                y=int((ot>=13 and night>=.2) or (auth-current>=7 and ot>=8) or (absent.sum()/max(current,1)>=.24))
                rows.append([w,u,r,auth,current,*map(int,absent),round(ot,2),round(night,3),[8,12,8,8,12,8][ji],inflow,out,f'synth-{seed}-w{w:03}'])
                labels.append([w,u,r,y])
    return pd.DataFrame(rows,columns=FIELDS),pd.DataFrame(labels,columns=KEY+['load_label'])

def derive(df):
    x=df.copy();x['absent']=x[ABSENT].sum(axis=1)
    x['vacancy']=(x.authorized-x.current).clip(lower=0)
    x['surplus']=(x.current-x.authorized).clip(lower=0)
    x['available']=x.current-x.absent
    x['vacancy_rate']=x.vacancy/x.authorized
    x['workload_observed']=x.available.gt(0)&x.overtime_h.notna() if 'overtime_h' in x else x.available.gt(0)
    return x

def default_schema():
    descriptions={
      'week':('주','주말을 기준으로 한 주차'),'unit':('코드','가상 조직'),'role':('코드','가상 행정지원 직무'),
      'authorized':('명','편제에 정한 인원'),'current':('명','기준시점 현재원'),'leave':('명','휴가 부재 인원'),
      'sick':('명','진단정보 없는 환자 부재 집계'),'training':('명','교육 부재 인원'),'detached':('명','현재원에 포함된 파견 부재'),
      'overtime_h':('시간/인/주','해당 주 가용 인원 1인당 초과근무 평균'),'night_ratio':('비율','전체 근무시간 중 야간 비율'),
      'shift_h':('시간','한 번에 연속으로 근무하는 시간'),'inflow':('명/주','지난 주말 이후 실제 유입'),'outflow':('명/주','지난 주말 이후 실제 유출'),
      'source_id':('코드','가상 생성 배치 참조')}
    properties={}
    for k in FIELDS:
        typ='string' if k in ['unit','role','source_id'] else 'number' if k in ['overtime_h','night_ratio','shift_h'] else 'integer'
        rule={'type':typ,'unit':descriptions[k][0],'description':descriptions[k][1],'source':'교육용 생성기 '+VERSION}
        if typ!='string':rule['minimum']=1 if k in ['week','authorized','shift_h'] else 0
        else:rule['minLength']=1
        if k=='week':rule['maximum']=104
        if k=='night_ratio':rule['maximum']=1
        if k=='overtime_h':rule['nullable_when']='현재원과 중복 없는 부재 합계가 같아 가용 인원이 0명일 때만 미측정으로 허용'
        if k=='unit':rule['enum']=UNITS
        if k=='role':rule['enum']=ROLES
        properties[k]=rule
    return {'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object','required':FIELDS,'properties':properties,'additionalProperties':False}

def validate(df,schema=None,check_stock=True):
    """원본 행 위치를 보존하고 오류행과 사유를 반환합니다. 입력은 수정하지 않습니다."""
    schema=schema or default_schema(); errs={i:[] for i in range(len(df))}
    missing=[k for k in FIELDS if k not in df]
    for pos,rec in enumerate(df.to_dict('records')):
        extra=set(rec)-set(FIELDS)
        if extra:errs[pos].append('UNKNOWN_FIELDS:'+','.join(sorted(extra)))
        for k,rule in schema['properties'].items():
            if k not in rec:errs[pos].append(k+':MISSING_COLUMN');continue
            v=rec[k]
            if pd.isna(v):
                zero_available=(k=='overtime_h' and all(isinstance(rec.get(x),(int,float,np.number)) for x in ['current']+ABSENT) and rec['current']==sum(rec[x] for x in ABSENT))
                if not zero_available:errs[pos].append(k+':MISSING_VALUE')
                continue
            numeric=isinstance(v,(int,float,np.number)) and not isinstance(v,(bool,np.bool_))
            valid_type=isinstance(v,str) if rule['type']=='string' else numeric and (rule['type']!='integer' or float(v).is_integer())
            if not valid_type:errs[pos].append(k+':TYPE');continue
            if numeric and not np.isfinite(v):errs[pos].append(k+':NONFINITE');continue
            if 'enum' in rule and v not in rule['enum']:errs[pos].append(k+':ENUM')
            if isinstance(v,str) and not v.strip():errs[pos].append(k+':EMPTY')
            if 'minimum' in rule and v<rule['minimum']:errs[pos].append(k+':MIN')
            if 'maximum' in rule and v>rule['maximum']:errs[pos].append(k+':MAX')
        if not errs[pos] and sum(rec[k] for k in ABSENT)>rec['current']:errs[pos].append('ABSENT_EXCEEDS_CURRENT')
    if not missing:
        dup=df.duplicated(KEY,keep=False)
        for pos in np.flatnonzero(dup):errs[int(pos)].append('DUPLICATE_KEY')
        if check_stock:
            work=df.copy();work['_pos']=np.arange(len(df))
            for _,g in work.sort_values(KEY).groupby(['unit','role']):
                previous=None
                for rec in g.to_dict('records'):
                    pos=rec['_pos']
                    if errs[pos]:previous=None;continue
                    if previous is not None and rec['week']==previous['week']+1:
                        if rec['current']!=previous['current']+rec['inflow']-rec['outflow']:errs[pos].append('STOCK_MISMATCH')
                    previous=rec
    bad=np.array([bool(errs[i]) for i in range(len(df))]);clean=df.iloc[np.flatnonzero(~bad)].copy()
    quarantine=df.iloc[np.flatnonzero(bad)].copy();quarantine['row_position']=np.flatnonzero(bad)
    quarantine['errors']=[';'.join(errs[i]) for i in np.flatnonzero(bad)]
    return clean,quarantine

def schema_cases(df):
    cases={};base=df.head(1).copy()
    for name,col,value in [('TYPE','authorized','서른'),('ENUM','role','J99'),('NEGATIVE','current',-1),('RATIO','night_ratio',1.2),('MISSING_VALUE','night_ratio',np.nan),('ABSENT','leave',999)]:
        x=base.copy().astype(object);x.loc[x.index[0],col]=value;cases[name]=x
    cases['MISSING_COLUMN']=base.drop(columns='night_ratio')
    cases['DUPLICATE_KEY']=pd.concat([base,base],ignore_index=True)
    return cases

CLOCK=re.compile(r'(\d{1,2}):(\d{2})\s*~\s*(익일\s*)?(\d{1,2}):(\d{2})')
KOCLOCK=re.compile(r'(오전|오후)\s*(\d{1,2})시\s*~\s*(익일\s*)?(오전|오후)\s*(\d{1,2})시')
DURATION=re.compile(r'(\d+(?:\.\d+)?)\s*시간(?:\s*(\d+)\s*분)?')
HOURS=re.compile(r'(\d+(?:\.\d+)?)\s*h\b')
REASONS={'휴가':['휴가','연가'],'환자':['환자','진료','병가'],'교육':['교육','입교'],'파견':['파견'],'전출':['전출','전역']}

def parse_hours(text):
    m=CLOCK.search(text)
    if m:
        a,am,nxt,b,bm=m.groups();a,am,b,bm=map(int,[a,am,b,bm])
        if a>23 or b>23 or am>59 or bm>59:raise ValueError('시각 범위 오류')
        diff=b*60+bm-a*60-am
        if nxt:diff+=1440
        elif diff<0:diff+=1440 # 문제에서 정한 한 번의 자정 통과 규칙
        elif diff==0:raise ValueError('같은 시각의 기간 미확인')
        return diff/60
    m=KOCLOCK.search(text)
    if m:
        ap,a,nxt,bp,b=m.groups();a=int(a);b=int(b)
        if not 1<=a<=12 or not 1<=b<=12:raise ValueError('오전 오후 시각 범위 오류')
        diff=(b%12+(12 if bp=='오후' else 0))-(a%12+(12 if ap=='오후' else 0))
        if nxt:diff+=24
        elif diff<0:diff+=24
        elif diff==0:raise ValueError('같은 시각의 기간 미확인')
        return float(diff)
    for regex in [DURATION,HOURS]:
        m=regex.search(text)
        if m:
            minute=int(m[2]) if regex is DURATION and m[2] else 0
            if minute>=60:raise ValueError('분 범위 오류')
            return float(m[1])+minute/60
    raise ValueError('시간 표현이 완전하지 않음')

def parse_line(text):
    unit=re.search(r'\bB0[1-4]\b',text);role=re.search(r'\bJ0[1-6]\b',text);context=re.search(r'평시|야간|훈련주간',text)
    if not (unit and role and context):raise ValueError('조직 직무 상황 누락')
    tail=text.split('사유=',1)[-1] if '사유=' in text else ''
    matched=[k for k,words in REASONS.items() if any(w in tail for w in words)]
    reason=matched[0] if len(matched)==1 else '미확인'
    return dict(unit=unit[0],role=role[0],context=context[0],hours=parse_hours(text),reason=reason)

def make_logs(seed=12):
    rng=np.random.default_rng(seed);raw=[];gold=[]
    # 일정한 사례 수를 고정한다. 내용과 정답은 서로 다른 표에 저장한다.
    broken=set(range(0,6000,60));anomalous=set(range(1,6000,80))
    for i in range(6000):
        u=UNITS[i%4];r=ROLES[i%6];ctx=['평시','야간','훈련주간'][i%3];reason=list(REASONS)[i%5]
        h=round(float(np.clip(rng.normal({'평시':9,'야간':11,'훈련주간':15}[ctx],1.1),4,20))*2)/2
        if i in anomalous:h=99.0 if (i//80)%2 else .5
        form=i%5
        if form==0:t=f'{int(h)}시간 {int(round((h%1)*60))}분'
        elif form==1:t=f'{h:g}h'
        elif form==2:
            a=22;b=int(a*60+h*60);t=f'22:00~'+('익일 ' if b>=1440 else '')+f'{b//60%24:02}:{b%60:02}'
            if h>=24:t=f'총 {h:g}시간'
        elif form==3:
            # 오전·오후 시각은 정수 시간으로 생성하며 정답도 같은 기간으로 저장합니다.
            h=float(int(h));end=14+int(h)
            if h>=24:t=f'총 {h:g}시간'
            else:t='오후 2시~'+('익일 ' if end>=24 else '')+('오후 ' if end%24>=12 else '오전 ')+f'{end%12 or 12}시'
        else:t=f'총 {h:g}시간'
        original=f'{u} {r} [{ctx}] 근무 {t} 사유={reason}'
        parseable=i not in broken
        if not parseable:original=f'{u} {r} [{ctx}] 근무 [잘린 기록]'
        rid=f'L{i:05}';raw.append([rid,original,None])
        gold.append([rid,parseable,h if parseable else None,reason if parseable else None,i in anomalous,False])
    for i in range(60):
        rid=f'R{i:05}';raw.append([rid,raw[i][1],raw[i][0]])
        gold.append([rid,*gold[i][1:5],True])
    return pd.DataFrame(raw,columns=['line_id','text','duplicate_of']),pd.DataFrame(gold,columns=['line_id','parseable','truth_hours','truth_reason','is_anomaly','is_duplicate'])

def preprocess(raw):
    rows=[]
    for item in raw.to_dict('records'):
        rec=dict(item);rec['status']='DUPLICATE' if pd.notna(item.get('duplicate_of')) else 'PARSED'
        try:rec.update(parse_line(item['text']));rec['error']=None
        except ValueError as exc:
            rec.update(hours=np.nan,reason='미확인',unit=None,role=None,context=None,error=str(exc))
            if rec['status']!='DUPLICATE':rec['status']='PARSE_FAILED'
        rows.append(rec)
    return pd.DataFrame(rows)

def binary_metrics(truth,pred):
    y=np.asarray(truth,dtype=bool);p=np.asarray(pred,dtype=bool)
    tp=int((y&p).sum());fp=int((~y&p).sum());fn=int((y&~p).sum());tn=int((~y&~p).sum())
    div=lambda a,b:float(a/b) if b else None
    return dict(n=len(y),tp=tp,fp=fp,fn=fn,tn=tn,accuracy=div(tp+tn,len(y)),precision=div(tp,tp+fp),recall=div(tp,tp+fn),f1=div(2*tp,2*tp+fp+fn),fpr=div(fp,fp+tn),fdr=div(fp,tp+fp))

def features_load(df):
    d=derive(df)
    return np.column_stack([np.clip(d.vacancy_rate/.25,0,1),np.clip(d.overtime_h/20,0,1),np.clip(d.night_ratio/.4,0,1)])

def load_score(df,weights=(.3,.6,.1)):
    if len(weights)!=3 or min(weights)<0 or not np.isclose(sum(weights),1):raise ValueError('가중치 3개의 합은 1이어야 함')
    return features_load(df)@np.asarray(weights)*100

def get_cell(df,u,r,origin):
    g=df[(df.unit==u)&(df.role==r)&(df.week<=origin)].sort_values('week').copy()
    if g.empty:raise ValueError('해당 시점에 자료가 없음')
    return g

def season(week):return 1.0 if week%52 in range(19,26) else 0.0

def ridge_features(v,i,o,next_week,v2=True):
    x=[v[-1],v[-1]-v[-2],v[-1]-v[-4]]
    if v2:x += [np.mean(o[-8:])-np.mean(i[-8:]),float(next_week%13==0),season(next_week)]
    return x

def fit_ridge(df,origin,v2=True):
    X=[];y=[]
    for _,g in df[df.week<=origin].sort_values('week').groupby(['unit','role']):
        v=(g.authorized-g.current).clip(lower=0).to_numpy()/g.authorized.to_numpy();i=g.inflow.to_numpy()/g.authorized.to_numpy();o=g.outflow.to_numpy()/g.authorized.to_numpy()
        weeks=g.week.to_numpy()
        for t in range(12,len(g)):
            if weeks[t]-weeks[t-4]!=4:continue
            X.append(ridge_features(v[:t],i[:t],o[:t],int(weeks[t]),v2));y.append(v[t]-v[t-1])
    if not X:raise ValueError('학습용 연속 주차 부족')
    return Ridge(alpha=1).fit(X,y)

def ridge_predict(model,g,origin,v2=True):
    a=float(g.authorized.iloc[-1]);v=list(((g.authorized-g.current).clip(lower=0)/g.authorized).to_numpy());i=list(g.inflow/a);o=list(g.outflow/a);out=[]
    for h in range(1,14):
        d=float(model.predict([ridge_features(v,i,o,origin+h,v2)])[0]);v.append(float(np.clip(v[-1]+d,0,1)));out.append(v[-1]*a)
        i.append(float(np.mean(i[-8:])));o.append(float(np.mean(o[-8:])))
    return np.array(out)

def mc_paths(g,origin,n_paths=300,seed=0,lam=0.0,extra_out=0.0):
    """예측시점까지의 실적만으로 13주 경로를 만듭니다. 확정된 일정과 구분합니다."""
    if not 0<=lam<=1 or extra_out<0:raise ValueError('예측 설정 범위 오류')
    g=g[g.week<=origin].sort_values('week');rng=np.random.default_rng(seed)
    if g.empty:raise ValueError('예측시점 이전 자료 없음')
    a=int(g.authorized.iloc[-1]);current=np.full(n_paths,int(g.current.iloc[-1]),dtype=int)
    seasonal=g.week.map(season).to_numpy().astype(bool)
    out_mean=float(g.outflow.mean());base=float(g.loc[~seasonal,'outflow'].mean()) if (~seasonal).any() else out_mean
    seasonal_out=float(g.loc[seasonal,'outflow'].mean()) if seasonal.any() else base*1.8
    recent=float(g.tail(8).outflow.mean());ordinary=g.week%13!=0
    incoming=float(g.loc[ordinary,'inflow'].mean()) if ordinary.any() else float(g.inflow.mean())
    batch=max(0,float(g.loc[~ordinary,'inflow'].mean())-incoming) if (~ordinary).any() else 0
    arr=np.zeros((n_paths,13)); flows=[]
    for h in range(1,14):
        mu=(1-lam)*(seasonal_out if season(origin+h) else base)+lam*recent+extra_out
        out=np.minimum(current,rng.poisson(max(mu,0),n_paths))
        proposed=rng.poisson(max(incoming,0),n_paths)+(rng.poisson(batch,n_paths) if (origin+h)%13==0 else 0)
        inflow=np.minimum(proposed,np.maximum(a-current+out,0))
        current=current+inflow-out
        arr[:,h-1]=np.maximum(a-current,0)
        flows.append((out.mean(),inflow.mean()))
    return arr,dict(origin=origin,paths=n_paths,seed=seed,lam=lam,extra_out=extra_out,available_through=int(g.week.max()),flow_means=flows)

def forecast_table(df,origin=91,seed=0,lam=0.0):
    rows=[];series=[];paths_by={}
    for idx,(u,r) in enumerate([(u,r) for u in UNITS for r in ROLES]):
        g=get_cell(df,u,r,origin);paths,ass=mc_paths(g,origin,seed=seed+idx,lam=lam);paths_by[(u,r)]=paths
        peaks=paths.max(axis=1);a=int(g.authorized.iloc[-1]);now=derive(g).iloc[-1]
        rows.append(dict(unit=u,role=r,origin=origin,authorized=a,current=int(now.current),vacancy=int(now.vacancy),available=int(now.available),overtime_h=float(now.overtime_h),night_ratio=float(now.night_ratio),p_need=float((peaks/a>=.15).mean()),peak_mean=float(peaks.mean()),need_median=int(np.ceil(np.median(peaks))),need_p90=int(np.ceil(np.percentile(peaks,90))),spread=float(np.percentile(peaks,90)-np.percentile(peaks,10)),data_ratio=float(g[g.week>origin-13].week.nunique()/13)))
        for h in range(13):
            q=np.percentile(paths[:,h],[10,50,90]);series.append(dict(unit=u,role=r,week=origin+h+1,origin=origin,q10=q[0],q50=q[1],q90=q[2]))
    return pd.DataFrame(rows),pd.DataFrame(series),paths_by

def assess_risk(table,comparison=None):
    t=table.copy();t['risk_prob']=50*t.p_need;t['risk_peak']=30*np.clip(t.peak_mean/t.authorized/.3,0,1);t['risk_load']=20*np.clip(t.overtime_h/20,0,1)
    t['risk']=t[['risk_prob','risk_peak','risk_load']].sum(axis=1)
    t['agreement']=1-np.minimum(np.abs(t.peak_mean-(comparison if comparison is not None else t.vacancy))/t.authorized/.2,1)
    t['confidence_score']=.4*(1-np.minimum(t.spread/t.authorized/.35,1))+.3*t.agreement+.3*t.data_ratio
    t['confidence']=np.select([t.confidence_score>=.7,t.confidence_score>=.45],['High','Med'],default='Low')
    t['grade']=np.select([t.risk>=70,t.risk>=40],['높음','주의'],default='낮음')
    t.loc[t.overtime_h.isna(),['risk','confidence_score']]=np.nan
    t.loc[t.overtime_h.isna(),'confidence']='Low'
    t.loc[t.overtime_h.isna(),'grade']='미확인'
    t['review_status']=np.where(t.risk.isna()|((t.risk>=40)&(t.confidence=='Low')),'근거 추가 확인','인사관 검토 대기')
    return t

def payload(title,why,tables=None,metrics=None,note=''):
    return dict(title=title,why=why,tables=tables or {},metrics=native(metrics or {}),note=note)

class Audit:
    def __init__(self):self.events=[]
    def add(self,event,**body):
        previous=self.events[-1]['hash'] if self.events else 'GENESIS'
        x=dict(seq=len(self.events),event=event,**native(body),previous=previous)
        x['hash']=hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest();self.events.append(x)
        return x
    def verify(self,anchor=None):
        prev='GENESIS'
        for i,event in enumerate(self.events):
            body={k:v for k,v in event.items() if k!='hash'}
            if event['seq']!=i or event['previous']!=prev or hashlib.sha256(json.dumps(body,sort_keys=True,ensure_ascii=False).encode()).hexdigest()!=event['hash']:return False
            prev=event['hash']
        return anchor is None or prev==anchor

class Workflow:
    """모의 역할에 따라 허용되는 상태 전이를 검사하는 교육용 코드입니다."""
    roles={'clerk':'clerk','reviewer':'reviewer','commander':'commander','executor':'executor','system':'system'}
    permissions={'submit':'clerk','review':'reviewer','adjust':'reviewer','approve':'commander','reject':'commander','hold':'commander','execute':'executor','revise':'clerk'}
    def __init__(self,resources):
        self.resources=resources.copy();self.cases={};self.audit=Audit();self.calls=0;self.executed=set()
    def propose(self,rid,role,need,qty):
        if rid in self.cases or role not in ROLES or isinstance(qty,bool) or not isinstance(qty,int) or qty<0 or qty>need:raise ValueError('잘못된 제안')
        self.cases[rid]=dict(request_id=rid,role=role,need=int(need),qty=int(qty),original=int(qty),version=1,state='DRAFT',submitter=None,reviewer=None,reason='')
    def act(self,actor,rid,action,reason='',qty=None,version=None,event_id=None):
        self.calls+=1;c=self.cases.get(rid);before=copy.deepcopy(c)
        def deny(why):self.audit.add('DENIED',actor=actor,rid=rid,action=action,reason=why);return False,why
        if actor not in self.roles or self.permissions.get(action)!=self.roles[actor]:return deny('권한 없음')
        if c is None:return deny('요청 없음')
        if version is not None and version!=c['version']:return deny('검토한 버전과 다름')
        if not reason.strip():return deny('사유 누락')
        transitions={'submit':('DRAFT','SUBMITTED'),'review':('SUBMITTED','REVIEWED'),'approve':('REVIEWED','APPROVED'),'reject':('REVIEWED','REJECTED'),'hold':('REVIEWED','HOLD'),'execute':('APPROVED','EXECUTED')}
        if action=='adjust':
            if c['state']!='REVIEWED':return deny('검토 단계 아님')
            if isinstance(qty,bool) or not isinstance(qty,int) or qty<0 or qty>c['need']:return deny('수량 범위 오류')
            if abs(qty-c['original'])>max(1,math.ceil(.5*c['original'])):return deny('조정 한도 초과')
            if qty>self.resources[c['role']]:return deny('자원 부족')
            c['qty']=qty;c['version']+=1;c['state']='SUBMITTED';c['reviewer']=None
        elif action=='revise':
            if c['state'] not in ['REJECTED','HOLD']:return deny('수정 가능한 상태 아님')
            c['version']+=1;c['state']='DRAFT';c['reviewer']=None
        else:
            expected,nxt=transitions[action]
            if c['state']!=expected:return deny('단계 순서 오류')
            if action=='submit':c['submitter']=actor
            if action=='review':
                if actor==c['submitter']:return deny('작성자와 검토자 분리')
                c['reviewer']=actor
            if action=='approve':
                if actor in [c['submitter'],c['reviewer']]:return deny('승인자 분리')
                if c['qty']>self.resources[c['role']]:return deny('중복 예약 또는 자원 부족')
                self.resources[c['role']]-=c['qty']
            if action=='execute':
                if not event_id or event_id in self.executed:return deny('집행 이벤트 누락 또는 중복')
                self.executed.add(event_id)
            c['state']=nxt
        c['reason']=reason
        self.audit.add('ACTION',actor=actor,rid=rid,action=action,before=before,after=copy.deepcopy(c),reason=reason,event_id=event_id)
        return True,c['state']

class ForecastService:
    def __init__(self,df,model_version='mc-2'):
        self.df=df.copy();self.data_version=fingerprint(df);self.model_version=model_version;self.cache={};self.fallback_cache={};self.lock=threading.Lock();self.heavy_calls=0
    def key(self,unit,role,origin,lam):return (self.data_version,self.model_version,unit,role,int(origin),float(lam))
    def invalidate(self,df=None,model_version=None):
        if df is not None:self.df=df.copy();self.data_version=fingerprint(df)
        if model_version is not None:self.model_version=model_version
        self.cache.clear();self.fallback_cache.clear()
    def predict(self,unit,role,origin=91,lam=0,optimized=True,fail=False):
        if unit not in UNITS or role not in ROLES:raise KeyError('잘못된 조직 또는 직무')
        if fail:raise RuntimeError('주입한 모델 오류')
        k=self.key(unit,role,origin,lam)
        if optimized:
            with self.lock:
                if k in self.cache:return dict(self.cache[k],cache_hit=True)
        g=get_cell(self.df,unit,role,origin)
        paths,_=mc_paths(g,origin,seed=0,lam=lam);self.heavy_calls+=1
        ans=dict(origin=origin,data_through=int(g.week.max()),need=int(np.ceil(np.median(paths.max(axis=1)))),mode='NORMAL',cache_hit=False)
        if optimized:
            with self.lock:self.cache[k]=ans.copy()
        return ans
    def fallback(self,unit,role,origin):
        if unit not in UNITS or role not in ROLES:raise KeyError('잘못된 조직 또는 직무')
        key=self.key(unit,role,origin,0)
        if key in self.fallback_cache:return self.fallback_cache[key].copy()
        g=get_cell(self.df,unit,role,origin);v=int(max(g.authorized.iloc[-1]-g.current.iloc[-1],0))
        ans=dict(origin=origin,data_through=int(g.week.max()),need=v,mode='DEGRADED',method='현재 결원 유지 규칙')
        self.fallback_cache[key]=ans.copy();return ans

def stress_run(service,rate,duration=1,optimized=True,workers=4,qmax=32):
    if rate<=0 or duration<=0:raise ValueError('도착률과 시험시간은 양수')
    q=queue.Queue(qmax);results=[];lock=threading.Lock();start=time.perf_counter();n=int(rate*duration)
    def respond(item,full=False):
        idx,u,r,origin,due,arrived=item;begin=time.perf_counter();error='';ans=None
        try:
            if full:ans=service.fallback(u,r,origin);status='DEGRADED_QUEUE'
            else:
                try:ans=service.predict(u,r,origin,optimized=optimized,fail=idx%97==7);status='NORMAL'
                except RuntimeError:ans=service.fallback(u,r,origin);status='DEGRADED_MODEL'
        except KeyError as exc:status='QUARANTINED';error=str(exc)
        except Exception as exc:status='FAILED';error=repr(exc)
        end=time.perf_counter()
        with lock:results.append(dict(request_id=idx,scheduled=due-start,arrived=arrived-start,started=begin-start,ended=end-start,status=status,latency_ms=(end-arrived)*1000,queue_ms=(begin-arrived)*1000,schedule_lag_ms=(arrived-due)*1000,error=error,response=ans))
    def worker():
        while True:
            item=q.get()
            try:
                if item is None:return
                respond(item)
            finally:q.task_done()
    threads=[threading.Thread(target=worker,daemon=True) for _ in range(workers)]
    for t in threads:t.start()
    for idx in range(n):
        due=start+idx/rate;left=due-time.perf_counter()
        if left>0:time.sleep(left)
        item=(idx,UNITS[idx%4],ROLES[idx%6] if idx%101 else 'J99',78 if idx%2 else 91,due,time.perf_counter())
        try:q.put_nowait(item)
        except queue.Full:respond(item,full=True)
    enqueue_end=time.perf_counter();q.join()
    for _ in threads:q.put(None)
    for t in threads:t.join()
    trace=pd.DataFrame(results).sort_values('request_id');elapsed=time.perf_counter()-start
    counts=trace.status.value_counts().to_dict();lost=n-trace.request_id.nunique();duplicate=len(trace)-trace.request_id.nunique()
    produced_rate=n/max(enqueue_end-start,1e-9)
    summary=dict(target_rate=rate,duration=duration,optimized=optimized,generated=n,actual_rate=produced_rate,elapsed=elapsed,completed=len(trace),lost=int(lost),duplicates=int(duplicate),failed=int(counts.get('FAILED',0)),p95_ms=float(trace.latency_ms.quantile(.95)),schedule_lag_p95_ms=float(trace.schedule_lag_ms.quantile(.95)),states=counts,full_duration=duration>=60,rate_met=produced_rate>=.95*rate)
    return trace,summary

CSS='''*{box-sizing:border-box}body{margin:0;background:#f4f6f8;color:#182635;font:15px system-ui,sans-serif}main{display:grid;grid-template-columns:150px 1fr;min-height:100vh}nav{padding:20px 12px;background:#19354c;color:white}nav button{display:block;width:100%;margin:10px 0;padding:12px;border:1px solid #7e9aad;background:transparent;color:white;cursor:pointer;text-align:left}nav button.active{background:#f0f6fb;color:#19354c}article{padding:26px;min-width:0}table{border-collapse:collapse;width:100%;font-size:13px;background:white}td,th{border:1px solid #cdd8e0;padding:7px;text-align:left}section.step[hidden]{display:none}pre{white-space:pre-wrap;background:#e7edf2;padding:12px}input,select,button{padding:8px;margin:4px}h1{font-size:24px}h2{font-size:20px}.note{line-height:1.7}.night{background:#111c28;color:#e4edf7}.night table,.night pre{background:#203346;color:#e4edf7}svg{max-width:100%}.review{color:#a83514}.night .review{color:#ffc49b}@media(max-width:700px){main{grid-template-columns:105px 1fr}article{padding:12px}}'''
JS='''const nav=[...document.querySelectorAll('nav button')];function choose(n){document.querySelectorAll('section.step').forEach((s,i)=>s.hidden=i!==n);nav.forEach((b,i)=>b.classList.toggle('active',i===n));}nav.forEach((b,i)=>b.onclick=()=>choose(i));choose(0);window.uiEvidence=null;
function dashboardFilter(){let u=document.getElementById('unitFilter')?.value||'';let r=document.getElementById('roleFilter')?.value||'';document.querySelectorAll('#liveRows tr').forEach(tr=>tr.hidden=(u&&tr.dataset.unit!==u)||(r&&tr.dataset.role!==r));}
function drill(u,r){let x=window.dashboardData.find(x=>x.unit===u&&x.role===r);document.getElementById('detail').textContent=JSON.stringify(x,null,2);let series=window.forecastSeries.filter(x=>x.unit===u&&x.role===r);let max=Math.max(1,...series.map(x=>x.q90));let pts=key=>series.map((x,i)=>`${30+i*38},${180-x[key]/max*145}`).join(' ');document.getElementById('chart').innerHTML=`<svg viewBox="0 0 530 210" aria-label="13주 결원 예측"><polyline points="${pts('q10')}" fill="none" stroke="#789"/><polyline points="${pts('q90')}" fill="none" stroke="#789"/><polyline points="${pts('q50')}" fill="none" stroke="#d47632" stroke-dasharray="5 4"/><text x="20" y="205" fill="currentColor">점선: 예측 중앙값 / 위아래 선: 10·90백분위 / 단위 명</text></svg>`;}
async function nextPaint(){await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));}
async function measureUi(){let times={filter:[],drill:[],night:[]};const before=JSON.stringify(window.dashboardData);for(let i=0;i<50;i++){let t=performance.now();document.getElementById('unitFilter').value=i%2?'B01':'';dashboardFilter();await nextPaint();times.filter.push(performance.now()-t);t=performance.now();drill('B01','J01');await nextPaint();times.drill.push(performance.now()-t);t=performance.now();document.body.classList.toggle('night');await nextPaint();times.night.push(performance.now()-t);}let q=x=>[...x].sort((a,b)=>a-b)[Math.ceil(.95*x.length)-1];window.uiEvidence={scope:'사용자 브라우저 두 번의 화면 갱신까지',runs:50,p95_ms:Object.fromEntries(Object.entries(times).map(([k,v])=>[k,q(v)])),raw:times,values_unchanged:before===JSON.stringify(window.dashboardData),userAgent:navigator.userAgent};document.getElementById('uiTiming').textContent=JSON.stringify(window.uiEvidence,null,2);}
function saveEvidence(){let b=new Blob([JSON.stringify({mission:document.title,uiEvidence:window.uiEvidence,notes:document.getElementById('learnerNotes')?.value||'',evidence:window.pythonEvidence},null,2)],{type:'application/json'});let a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=document.title+'_record.json';a.click();URL.revokeObjectURL(a.href);}
'''

def dashboard_html(table,series):
    cols=['unit','role','current','vacancy','available','risk','confidence','need_median','review_status']
    rows=''.join('<tr data-unit="'+html.escape(r['unit'])+'" data-role="'+html.escape(r['role'])+'">'+''.join('<td>'+html.escape(str(round(r[c],2) if isinstance(r[c],float) else r[c]))+'</td>' for c in cols)+f'<td><button onclick="drill(\'{r["unit"]}\',\'{r["role"]}\')">상세 보기</button></td></tr>' for r in table.to_dict('records'))
    lookup={(r['unit'],r['role']):r for r in table.to_dict('records')}
    heat='<h3>전체 24개 조합의 위험 점수</h3><p>점수와 상태를 함께 읽으세요. 자료 공백은 미확인으로 표시합니다.</p><table><thead><tr><th>조직</th>'+''.join('<th>'+r+'</th>' for r in ROLES)+'</tr></thead><tbody>'
    for unit in UNITS:
        heat+='<tr><th>'+unit+'</th>'
        for role in ROLES:
            r=lookup[(unit,role)];value=r['risk'];color='#e7edf2' if pd.isna(value) else '#ffd8cf' if value>=70 else '#ffedbe' if value>=40 else '#e4f0e9'
            label='미확인' if pd.isna(value) else str(round(value,1))+'점 '+str(r['grade'])
            heat+='<td style="background:'+color+';color:#182635">'+label+'</td>'
        heat+='</tr>'
    heat+='</tbody></table><h3>조직과 직무를 골라 상세 확인</h3>'
    data=json.dumps(native(table),ensure_ascii=False).replace('<','\\u003c');forecast=json.dumps(native(series),ensure_ascii=False).replace('<','\\u003c')
    return '<div id="dashboard">'+heat+'<p>이 화면의 수치는 교육용 자료입니다. 제안 인원은 승인이나 실제 충원 결과가 아닙니다.</p><label>조직<select id="unitFilter" onchange="dashboardFilter()"><option value="">전체</option>'+''.join('<option>'+x+'</option>' for x in UNITS)+'</select></label><label>직무<select id="roleFilter" onchange="dashboardFilter()"><option value="">전체</option>'+''.join('<option>'+x+'</option>' for x in ROLES)+'</select></label><button onclick="document.body.classList.toggle(\'night\')">야간 모드</button><table><thead><tr>'+''.join('<th>'+x+'</th>' for x in ['조직','직무','현재원','편제상 결원','근무 가용','위험 점수','근거 신뢰도','제안 소요','검토 상태'])+'<th>상세</th></tr></thead><tbody id="liveRows">'+rows+'</tbody></table><pre id="detail">상세 보기를 누르세요.</pre><div id="chart"></div><button onclick="measureUi()">실제 화면 응답 50회 측정</button><pre id="uiTiming">브라우저에서 측정하지 않았습니다.</pre></div><script>window.dashboardData='+data+';window.forecastSeries='+forecast+';</script>'

def export_report(root,mid,stages):
    if len(stages)!=5 or any(not isinstance(s,dict) or not s.get('title') for s in stages):raise ValueError('실제 단계 결과 5개 필요')
    root=Path(root);out=root/'outputs'/mid;out.mkdir(parents=True,exist_ok=True);sections=[]
    for i,s in enumerate(stages,1):
        blocks=['<h2>STEP %02d %s</h2>'%(i,html.escape(s['title'])),'<p class="note">'+html.escape(s['why'])+'</p>','<pre>'+html.escape(json.dumps(native(s['metrics']),ensure_ascii=False,indent=2))+'</pre>']
        for name,tab in s['tables'].items():
            if not isinstance(tab,pd.DataFrame):raise TypeError('결과 표는 DataFrame이어야 함')
            tab.to_csv(out/f'STEP{i:02}_{re.sub(r"[^A-Za-z0-9_]","_",name)}.csv',index=False,encoding='utf-8-sig')
            blocks+=['<h3>'+html.escape(name)+'</h3>',tab.head(100).to_html(index=False,escape=True),'<p>화면에는 최대 100행을 표시하며 전체 자료는 같은 폴더의 CSV에 저장했습니다.</p>']
        blocks+=['<p class="note">'+html.escape(s.get('note',''))+'</p>',s.get('html','')]
        sections.append('<section class="step"'+(' hidden' if i>1 else '')+'>'+''.join(blocks)+'</section>')
    evidence=dict(version=VERSION,mission=mid,steps=[{k:native(v) for k,v in s.items() if k not in ['tables','html']} for s in stages],automatic_pass=False)
    safe=json.dumps(evidence,ensure_ascii=False).replace('<','\\u003c')
    doc='<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>ADM01_'+mid+'</title><style>'+CSS+'</style></head><body><main><nav><strong>'+mid+'</strong>'+''.join('<button>STEP %02d</button>'%i for i in range(1,6))+'</nav><article><h1>'+mid+' 실제 코드 실행 결과</h1>'+''.join(sections)+'<h2>결과를 읽고 남길 설명</h2><p>가장 중요한 결과, 그 근거가 된 표와 단위, 아직 확인하지 못한 사항, 다음 담당자가 해야 할 일을 적으세요.</p><textarea id="learnerNotes" rows="6" style="width:100%"></textarea><button onclick="saveEvidence()">판단 기록 JSON 저장</button><script>window.pythonEvidence='+safe+';</script><script>'+JS+'</script></article></main></body></html>'
    (out/f'ADM01_{mid}_result.html').write_text(doc,encoding='utf-8');dump(out/f'ADM01_{mid}_code_report.json',evidence)
    return out/f'ADM01_{mid}_result.html'

def init_state(root='ADM01_work',seed=7,stress_seconds=1):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    for sub in ['data','docs','outputs','configs','verification']:(root/sub).mkdir(exist_ok=True)
    weekly,labels=make_weekly(seed);raw,gold=make_logs()
    return dict(root=root,weekly=weekly,load_labels=labels,raw_logs=raw,log_truth=gold,seed=seed,stress_seconds=stress_seconds,cache={})
