"""각 미션의 다섯 단계 정답 구현. 학습자 노트북에서는 이 함수 본문을 직접 작성한다."""
from adm01_runtime import *
import importlib.util, platform

def forecast_bundle(S,origin=91,seed=0,lam=0):
    key=('forecast',origin,seed,lam)
    if key not in S['cache']:S['cache'][key]=forecast_table(S['weekly'],origin,seed,lam)
    return S['cache'][key]

def risk_bundle(S):
    if 'risk' not in S['cache']:
        t,series,paths=forecast_bundle(S);model=fit_ridge(S['weekly'],91)
        comparison=np.array([ridge_predict(model,get_cell(S['weekly'],r.unit,r.role,91),91).max() for r in t.itertuples()])
        S['cache']['risk']=(assess_risk(t,comparison),series,paths)
    return S['cache']['risk']

def m01_s1(S):
    schema=default_schema();S['schema']=schema
    definitions=pd.DataFrame([dict(field=k,**v) for k,v in schema['properties'].items()])
    assert set(schema['required'])==set(FIELDS) and len(FIELDS)==15
    return payload('입력 항목의 뜻과 단위 정하기','한 주의 현재원과 한 주 동안의 전입 인원은 서로 다른 값입니다. 이 차이를 자료 정의에 남깁니다.',{'field_definitions':definitions},{'fields':15,'has_person_identifier':False})

def m01_s2(S):
    clean,bad=validate(S['weekly'],S['schema']);x=derive(clean);S['clean']=clean
    fixture=pd.DataFrame([dict(authorized=30,current=26,leave=3,sick=1,training=2,detached=0),dict(authorized=30,current=32,leave=1,sick=1,training=1,detached=0)])
    answers=derive(fixture)
    assert answers.vacancy.tolist()==[4,0] and answers.available.tolist()==[20,29]
    return payload('결원과 근무 가능한 인원 계산하기','휴가 등으로 오늘 자리에 없는 인원을 편제상 결원에 다시 더하지 않습니다.',{'weekly_derived':x,'quantity_examples':answers},{'normal_rows':len(clean),'normal_errors':len(bad)})

def m01_s3(S):
    x=S['weekly'].sort_values(['unit','role','week']).copy();g=x.groupby(['unit','role'])
    x['previous_current']=g.current.shift();x['previous_week']=g.week.shift()
    mask=x.week-x.previous_week==1
    x['stock_error']=np.where(mask,x.current-x.previous_current-x.inflow+x.outflow,np.nan)
    wrong=x[mask & x.stock_error.ne(0)]
    return payload('전입과 전출 기록으로 현재원 검산하기','지난주 현재원에 실제 전입을 더하고 실제 전출을 빼면 이번 주 현재원이 되어야 합니다.',{'stock_balance':x},{'checked_transitions':int(mask.sum()),'mismatches':len(wrong)},'첫 주에는 이전 주 자료가 없으므로 검산 대상에서 제외합니다.')

def m01_s4(S):
    rows=[]
    for name,case in schema_cases(S['weekly']).items():
        good,bad=validate(case,S['schema'],check_stock=False);rows.append(dict(error_type=name,detected=bool(len(bad)),quarantined=len(bad)))
    test=pd.DataFrame(rows);S['schema_tests']=test
    assert test.detected.all()
    return payload('오류를 넣어 검증기가 찾는지 시험하기','정상 자료가 통과하는 것만으로는 충분하지 않습니다. 틀린 값도 실제로 막는지 확인합니다.',{'injected_error_tests':test},{'detected':int(test.detected.sum()),'total':len(test)})

def m01_s5(S):
    root=S['root'];(root/'data').mkdir(exist_ok=True)
    S['weekly'].to_csv(root/'data/weekly.csv',index=False);S['load_labels'].to_csv(root/'data/load_truth.csv',index=False)
    dump(root/'data/schema.json',S['schema']);record=dict(rows=len(S['weekly']),seed=S['seed'],version=VERSION,fingerprint=fingerprint(S['weekly']),unconfirmed=[])
    dump(root/'data/manifest.json',record)
    return payload('자료와 검사 결과 저장하기','다음 담당자가 같은 자료를 사용했는지 확인할 수 있도록 생성 조건과 파일 지문을 함께 저장합니다.',{'test_summary':S['schema_tests']},record)

def m02_s1(S):
    r=S['raw_logs'];truth=S['log_truth'];assert set(r.line_id)==set(truth.line_id)
    assert 'truth_hours' not in r
    return payload('원문과 정답표 따로 확인하기','파서는 일지 원문만 읽습니다. 정답 시간과 사유는 결과를 검사할 때만 사용합니다.',{'raw_preview':r.head(15)},{'input_rows':len(r),'truth_rows':len(truth),'duplicates':int(r.duplicate_of.notna().sum())})

def m02_s2(S):
    parsed=preprocess(S['raw_logs']);S['parsed']=parsed
    cases=['12시간 30분','8h','22:00~익일 06:00','오후 2시~익일 오전 6시','총 9시간','오전 8시~익일 오전 10시']
    result=pd.DataFrame({'expression':cases,'hours':[parse_hours(x) for x in cases]})
    assert result.hours.tolist()==[12.5,8,8,16,9,26]
    return payload('시간 표현과 부재 사유 해석하기','시각 구간은 시작과 종료의 차이로 계산합니다. 익일은 날짜가 하루 지났다는 뜻이므로 24시간을 더합니다.',{'parser_examples':result,'parsed':parsed},{'failed':int((parsed.status=='PARSE_FAILED').sum())})

def m02_s3(S):
    p=S['parsed'];normal=p[p.status=='PARSED'];quarantine=p[p.status!='PARSED']
    assert p.line_id.nunique()==len(S['raw_logs']) and len(normal)+len(quarantine)==len(p)
    S['parsed_unique']=normal
    return payload('중복 일지와 해석 실패 기록 남기기','실패한 일지도 수신한 자료입니다. 원문을 지우지 말고 중복인지, 해석할 수 없는지 이유를 남깁니다.',{'quarantine':quarantine},{'input':len(p),'parsed_unique':len(normal),'duplicate':int((p.status=='DUPLICATE').sum()),'parse_failed':int((p.status=='PARSE_FAILED').sum()),'accounted':len(normal)+len(quarantine)})

def m02_s4(S):
    p=S['parsed_unique'].copy();gold=S['log_truth'];j=p.merge(gold,on='line_id',validate='one_to_one')
    p['development']=p.line_id.str[1:].astype(int)%2==0
    bounds={}
    for ctx,g in p[p.development].groupby('context'):
        median=float(g.hours.median());mad=float((g.hours-median).abs().median())*1.4826
        width=4*mad if mad>0 else 2.0
        bounds[ctx]=(median-width,median+width)
    test=j[j.line_id.str[1:].astype(int)%2==1].copy();rows=[]
    for name,pred in [('fixed_14',test.hours>14),('fixed_18',test.hours>18),('context_MAD',np.array([not(bounds[c][0]<=h<=bounds[c][1]) for c,h in zip(test.context,test.hours)]))]:
        rows.append(dict(method=name,**binary_metrics(test.is_anomaly,pred)))
    S['outlier_bounds']=bounds;S['outlier_comparison']=pd.DataFrame(rows)
    return payload('상황별 시간 분포로 이상 후보 찾기','훈련주간에는 긴 근무 기록이 더 흔할 수 있습니다. 통계상 드문 기록인지 검토하는 기준이며 적정 근무시간을 정하는 기준은 아닙니다.',{'threshold_comparison':pd.DataFrame(rows),'thresholds':pd.DataFrame([dict(context=k,lower=v[0],upper=v[1]) for k,v in bounds.items()])},{'development_rows':int(p.development.sum()),'test_rows':len(test)})

def m02_s5(S):
    j=S['parsed'].merge(S['log_truth'],on='line_id',validate='one_to_one');valid=j.parseable
    error=valid & ((j.hours-j.truth_hours).abs().gt(1e-9)|j.reason.ne(j.truth_reason)|j.hours.isna())
    timings=[]
    preprocess(S['raw_logs'])
    for _ in range(5):
        start=time.perf_counter();preprocess(S['raw_logs']);timings.append(time.perf_counter()-start)
    speed=len(j)/np.median(timings);S['parsed'].to_csv(S['root']/'data/processed_logs.csv',index=False)
    result=dict(total=len(j),parseable=int(valid.sum()),parse_errors=int(error.sum()),error_rate=float(error.sum()/valid.sum()),parse_failed=int((j.status=='PARSE_FAILED').sum()),throughput_median=float(speed),timing_seconds=timings,throughput_target_met=bool(speed>=1000))
    S['preprocess_metrics']=result
    return payload('오류율과 처리속도 측정하기','해석 가능한 전체 정답 대상에서 오류를 셉니다. 이상 후보를 제외해 오류율이 좋아 보이게 만들지 않습니다.',{'context_comparison':S['outlier_comparison']},result)

def m03_s1(S):
    x=S['weekly'].merge(S['load_labels'],on=KEY,validate='one_to_one');x['split']=np.select([x.week<=39,x.week<=52],['train','validation'],default='test')
    S['load_data']=x
    return payload('학습용 주차와 시험용 주차 나누기','앞 39주로 후보를 만들고 다음 13주로 선택합니다. 뒤 52주는 선택이 끝난 모델을 검사하는 데만 사용합니다.',{'split_counts':x.groupby('split').agg(rows=('week','size'),first_week=('week','min'),last_week=('week','max'),positives=('load_label','sum')).reset_index()},{'label_meaning':'교육용 부하 사례의 표시이며 의학적 피로 진단이 아님'})

def m03_s2(S):
    x=S['load_data'];weights=(.3,.6,.1);S['load_weights_initial']=weights
    scored=derive(x);f=features_load(x)
    for k,i in [('vacancy_contribution',0),('overtime_contribution',1),('night_contribution',2)]:scored[k]=f[:,i]*weights[i]*100
    scored['score']=scored[['vacancy_contribution','overtime_contribution','night_contribution']].sum(axis=1)
    S['load_scored']=scored
    return payload('세 요인이 점수에 기여한 양 계산하기','결원율·초과근무·야간 비율의 단위가 달라 먼저 0~1 범위로 바꿉니다. 각 가중치를 곱한 값을 합쳐 100점 만점으로 표시합니다.',{'contribution_preview':scored.head(30)},{'weights':weights,'normalization_limits':[.25,20,.4],'threshold':55})

def m03_s3(S):
    x=S['load_data'];v=x[x.split=='validation'];rows=[]
    for a in [.1,.3,.5]:
        for b in [.3,.5,.7]:
            c=round(1-a-b,8)
            if c<0:continue
            for threshold in [40,50,55,60,70]:
                metrics=binary_metrics(v.load_label,load_score(v,(a,b,c))>=threshold)
                rows.append(dict(w_vacancy=a,w_overtime=b,w_night=c,threshold=threshold,**metrics))
    grid=pd.DataFrame(rows).sort_values(['f1','recall','accuracy'],ascending=False);best=grid.iloc[0]
    S['load_weights']=(float(best.w_vacancy),float(best.w_overtime),float(best.w_night));S['load_threshold']=float(best.threshold)
    return payload('검증 주차에서 가중치와 기준점 선택하기','높은 점수 자체가 정답은 아닙니다. 부하 사례를 놓치지 않는지와 잘못 경보하는지를 함께 비교해 설정을 고릅니다.',{'candidate_grid':grid},{'selected_weights':S['load_weights'],'selected_threshold':S['load_threshold'],'selected_on_weeks':[40,52]})

def m03_s4(S):
    x=S['load_data'];t=x[x.split=='test'];train=x[x.split=='train'];majority=int(train.load_label.mean()>=.5)
    variants={'majority':np.full(len(t),majority),'simple_rule':(t.overtime_h>=13)&(t.night_ratio>=.2),'initial_score':load_score(t)>=55,'tuned_score':load_score(t,S['load_weights'])>=S['load_threshold']}
    rows=[dict(method=name,**binary_metrics(t.load_label,pred)) for name,pred in variants.items()]
    pred=variants['tuned_score'];errors=t.copy();errors['prediction']=pred;errors['missed']=errors.load_label.eq(1)&~pred
    S['load_test_metrics']=pd.DataFrame(rows)
    return payload('같은 시험 자료에서 네 방법 비교하기','모두 정상으로 답하는 방법과 단순 규칙도 함께 시험합니다. 정확도가 높아도 실제 부하 사례를 자주 놓치면 그 문제를 설명해야 합니다.',{'test_metrics':pd.DataFrame(rows),'missed_cases':errors[errors.missed]},{'test_weeks':[53,104]})

def m03_s5(S):
    x=S['load_data'];recent=x[x.week>=93].copy();recent['score']=load_score(recent,S['load_weights']);rank=recent.groupby(['unit','role']).score.mean().sort_values(ascending=False).reset_index()
    latency=[]
    for _ in range(50):
        st=time.perf_counter();load_score(x.tail(24),S['load_weights']);latency.append((time.perf_counter()-st)*1000)
    S['load_result']=rank
    return payload('최근 12주 점수와 계산시간 설명하기','순위는 어떤 조직과 직무부터 확인할지 정하는 참고자료입니다. 점수로 개인의 건강이나 근무 적합성을 판단하지 않습니다.',{'recent_rank':rank,'test_metrics':S['load_test_metrics']},{'inference_p95_ms':float(np.percentile(latency,95)),'timing_ms':latency,'model_weights':S['load_weights'],'threshold':S['load_threshold']})

def m04_s1(S):
    rows=[dict(origin=o,known_through=o,horizon_start=o+1,horizon_end=o+13,purpose='final_test' if o==91 else 'development') for o in ORIGINS]
    return payload('예측 시점과 보충량의 뜻 정하기','52주 시점의 예측에는 52주까지의 자료만 씁니다. 보충량은 앞으로 가장 부족한 주의 인원수이며 13주 결원을 모두 더한 값이 아닙니다.',{'rolling_plan':pd.DataFrame(rows)},{'detection_vacancy_rate':.15,'staffing_target':'편제 100%','forecast_horizon_weeks':13})

def m04_s2(S):
    rows=[];details=[]
    for origin in ORIGINS:
        m1=fit_ridge(S['weekly'],origin,False);m2=fit_ridge(S['weekly'],origin,True)
        table,series,paths=forecast_bundle(S,origin)
        for _,r in table.iterrows():
            u,role=r.unit,r.role;g=get_cell(S['weekly'],u,role,origin);a=int(r.authorized)
            actual=S['weekly'][(S['weekly'].unit==u)&(S['weekly'].role==role)&(S['weekly'].week.between(origin+1,origin+13))].sort_values('week')
            truth=(actual.authorized-actual.current).clip(lower=0).to_numpy()
            candidates={'naive':np.full(13,max(a-int(g.current.iloc[-1]),0)),'ridge_v1':ridge_predict(m1,g,origin,False),'ridge_v2':ridge_predict(m2,g,origin,True),'stock_flow':paths[(u,role)].mean(axis=0)}
            for name,pred in candidates.items():rows.append(dict(origin=origin,unit=u,role=role,method=name,mae=float(np.abs(pred-truth).mean())))
            details.append(dict(origin=origin,unit=u,role=role,p_need=r.p_need,actual_need=bool((truth/a>=.15).any()),actual_peak=int(truth.max()),pred_peak=int(r.need_median)))
    S['forecast_mae']=pd.DataFrame(rows);S['forecast_details']=pd.DataFrame(details)
    return payload('단순 예측 회귀 모의 예측 만들기','최근값 유지, 회귀식, 유입·유출 모의를 같은 미래 13주에 적용합니다. 회귀 v2에는 최근 유입·유출과 달력 정보를 추가합니다.',{'mae_by_origin':S['forecast_mae'].groupby(['origin','method']).mae.mean().reset_index()},{'methods':4,'origins':ORIGINS,'unit_role_pairs':24,'paths_per_pair':300})

def m04_s3(S):
    x=S['forecast_details'];dev=x[x.origin<91];rows=[]
    for threshold in [.15,.3,.5]:rows.append(dict(threshold=threshold,**binary_metrics(dev.actual_need,dev.p_need>=threshold)))
    grid=pd.DataFrame(rows);valid=grid[grid.recall.fillna(0)>=.85]
    selected=float((valid.sort_values('precision',ascending=False) if len(valid) else grid.sort_values('recall',ascending=False)).iloc[0].threshold)
    t=x[x.origin==91];S['forecast_threshold']=selected;S['forecast_test']=binary_metrics(t.actual_need,t.p_need>=selected)
    return payload('개발 구간에서 경보 기준 고르고 마지막 구간 시험하기','기준을 낮추면 놓치는 사례가 줄 수 있지만 불필요한 경보가 늘 수 있습니다. 기준 선택은 앞 세 구간에서 끝내고 마지막 구간에서는 성능만 확인합니다.',{'threshold_grid':grid,'final_test_pairs':t},dict(selected_threshold=selected,final_test=S['forecast_test']))

def m04_s4(S):
    t,series,paths=forecast_bundle(S);actual=S['weekly'][S['weekly'].week>=92].copy();actual=derive(actual)
    joined=series.merge(actual[KEY+['vacancy']],on=KEY,validate='one_to_one');joined['covered']=joined.vacancy.between(joined.q10,joined.q90);joined['width']=joined.q90-joined.q10
    t=t.merge(S['forecast_details'][S['forecast_details'].origin==91][['unit','role','actual_peak']],on=['unit','role']);t['need_error']=t.need_median-t.actual_peak
    return payload('보충량과 예측 범위 확인하기','300개 경로마다 가장 큰 결원을 먼저 구합니다. 경로별 최대 결원의 중앙값과 90백분위수를 보고하고, 범위가 실제 결과를 얼마나 포함했는지도 확인합니다.',{'need_comparison':t,'interval_coverage':joined},{'coverage':float(joined.covered.mean()),'mean_width_people':float(joined.width.mean()),'need_mae':float(t.need_error.abs().mean())},'10~90백분위 구간은 이 생성 가정 아래의 범위이며 실제 적중률이 항상 80%라는 보장은 없습니다.')

def m04_s5(S):
    forecast_table(S['weekly'],91);timing=[]
    for _ in range(50):
        st=time.perf_counter();forecast_table(S['weekly'],91);timing.append((time.perf_counter()-st)*1000)
    result=dict(scope='24개 조직·직무 전체 / 13주 / 각 300경로 / DataFrame 구성 포함',runs=50,p95_ms=float(np.percentile(timing,95)),raw_ms=timing,target_ms=200,target_met=bool(np.percentile(timing,95)<=200))
    S['forecast_latency']=result
    return payload('24개 조합 전체의 예측시간 측정하기','한 조합의 계산시간을 24배 한 추정치 대신 전체 예측 함수를 실제로 반복 실행합니다.',{},result)

def m05_s1(S):
    risk,_,_=risk_bundle(S);S['risk']=risk
    return payload('위험 점수를 세 요인으로 나누어 계산하기','필요 가능성, 예상 최대 결원, 초과근무 부담을 함께 보되 각각 몇 점을 차지했는지 공개합니다. 위험 점수 80점은 발생확률 80%라는 뜻이 아닙니다.',{'risk_contributions':risk[['unit','role','risk_prob','risk_peak','risk_load','risk']]},{'weights':[.5,.3,.2],'range':[0,100]})

def m05_s2(S):
    r=S['risk'];fixture=r.head(1).copy();fixture['data_ratio']=0;fixture['spread']=fixture.authorized*.5;check=assess_risk(fixture)
    assert check.confidence.iloc[0]=='Low'
    return payload('위험의 크기와 자료의 충분함 따로 표시하기','위험은 커도 자료가 부족할 수 있습니다. 그런 요청을 숨기면 안 됩니다. 신뢰도 Low로 표시하고 사람이 자료를 먼저 확인하게 합니다.',{'risk_and_confidence':r,'missing_data_example':check},{'confidence_definition':'자료 충분도 30%, 경로 폭 40%, 비교모델 일치 30%','not_a_calibrated_probability':True})

def m05_s3(S):
    r=S['risk'];future=derive(S['weekly'][S['weekly'].week>91])
    truth=future.assign(actual_need=future.vacancy_rate>=.15).groupby(['unit','role']).actual_need.any().reset_index()
    joined=r.merge(truth,on=['unit','role']);base=(joined.vacancy/joined.authorized>=.10)|(joined.overtime_h>=15);new=(joined.risk>=50)&joined.confidence.ne('Low')
    rows=[dict(method='simple',**binary_metrics(joined.actual_need,base)),dict(method='confidence_filter',**binary_metrics(joined.actual_need,new))]
    a,b=rows;reduction=None if a['fpr'] in [None,0] else (a['fpr']-b['fpr'])/a['fpr']
    S['alarm_metrics']=rows
    return payload('오경보 감소와 놓친 요청을 함께 비교하기','오경보율은 정상 사례 중 잘못 경보한 비율입니다. 경보 중 틀린 비율은 다른 지표이므로 FPR과 FDR을 따로 적습니다.',{'alarm_tradeoff':pd.DataFrame(rows)},{'fpr_relative_reduction':reduction,'filter_adoption':'보류' if b['recall'] is None or b['recall']<.85 else '사람 검토 필요'})

def m05_s4(S):
    results=[]
    for seed in range(5):
        t,_,_=forecast_bundle(S,seed=seed);r=assess_risk(t);r['seed']=seed;results.append(r)
    allr=pd.concat(results,ignore_index=True);ref=allr[allr.seed==0][['unit','role','grade','confidence']]
    compare=allr[allr.seed!=0].merge(ref,on=['unit','role'],suffixes=('','_ref'));risk_same=float(compare.grade.eq(compare.grade_ref).mean());confidence_same=float(compare.confidence.eq(compare.confidence_ref).mean())
    resources={r:4 for r in ROLES};rows=[]
    for r in S['risk'].sort_values('risk',ascending=False).itertuples():
        qty=min(int(r.need_median),resources[r.role]);resources[r.role]-=qty
        rows.append(dict(unit=r.unit,role=r.role,need=int(r.need_median),proposed=qty,unsupported=int(r.need_median)-qty,confidence=r.confidence,state='DRAFT'))
    S['proposals']=pd.DataFrame(rows)
    return payload('난수 반복과 자원 한도 확인하기','같은 입력에 난수만 바꾼 결과를 비교합니다. 제안량은 직무별 준비된 가상 자원 4명을 넘지 않게 하고 지원하지 못한 인원도 남깁니다.',{'seed_comparisons':compare,'proposals':S['proposals']},{'comparison_pairs':len(compare),'risk_grade_consistency':risk_same,'confidence_grade_consistency':confidence_same})

def m05_s5(S):
    out=S['proposals'].copy();out['review_note']=np.where(out.confidence=='Low','자료 확인 후 재검토','인사관 검토 대기')
    out.to_csv(S['root']/'data/review_candidates.csv',index=False);S['proposals']=out
    return payload('제안량과 미지원 인원을 담당자에게 전달하기','현재원은 아직 바뀌지 않았습니다. 제안, 지원하지 못한 소요, 확인할 근거를 전달하고 사람의 검토를 기다립니다.',{'review_candidates':out},{'proposed':int(out.proposed.sum()),'unsupported':int(out.unsupported.sum()),'actual_reinforcement':0})

def m06_s1(S):
    r,series,_=risk_bundle(S);latest=derive(S['weekly'][S['weekly'].week==91]);S['dashboard']=r;S['dashboard_series']=series
    total=float(latest.vacancy.sum()/latest.authorized.sum())
    return payload('한 시점의 현황과 합계 만들기','전체 결원율은 결원 합계를 편제 합계로 나눕니다. 작은 직무와 큰 직무의 비율을 똑같이 평균 내지 않습니다.',{'current_status':r},{'reference_week':91,'total_vacancy_rate':total,'authorized':int(latest.authorized.sum()),'vacancy':int(latest.vacancy.sum())})

def m06_s2(S):
    r=S['dashboard'].copy();r['display_state']=r.grade
    x=r.head(1).copy();x['display_state']='미확인';x['risk']=np.nan
    return payload('결원 근무부하 자료 공백 구별하기','현재원·결원·근무 가용을 같은 줄에 표시합니다. 값이 없는 예시는 정상 0으로 바꾸지 않고 미확인으로 표시합니다.',{'dashboard_values':r,'missing_example':x},{'row_count':len(r),'missing_is_zero':False})

def m06_s3(S):
    r=S['dashboard'];series=S['dashboard_series'];view=dashboard_html(r,series)
    S['dashboard_html']=view
    p=payload('선택한 조직과 직무의 예측 열기','표에서 상세 보기를 누르면 같은 조직·직무의 13주 예측 범위와 검토 상태를 보여 줍니다.',{'forecast_series':series},{'origin':91,'forecast_weeks':[92,104]});p['html']=view;return p

def m06_s4(S):
    r=S['dashboard'];checks=[]
    for u in UNITS:
        for role in ROLES:
            selected=r[(r.unit==u)&(r.role==role)];checks.append(dict(unit=u,role=role,rows=len(selected),passed=len(selected)==1))
    return payload('필터 드릴다운 야간 모드 동작 확인하기','Python에서는 선택키의 유일성을 검사합니다. 실제 필터와 야간 전환은 STEP 03 화면에서 실행하고 결과를 확인합니다.',{'selection_key_checks':pd.DataFrame(checks)},{'python_data_checks':all(x['passed'] for x in checks),'browser_ui_checked':False},'화면의 색을 바꿔도 수치가 같아야 합니다. 실제 브라우저 검증 전에는 UI 검사를 완료로 표시하지 않습니다.')

def m06_s5(S):
    times=[]
    for _ in range(50):
        st=time.perf_counter();dashboard_html(S['dashboard'],S['dashboard_series']);times.append((time.perf_counter()-st)*1000)
    return payload('화면 생성시간과 실제 화면 응답 분리 측정하기','아래 수치는 Python이 HTML을 만든 시간입니다. 사용자의 실제 화면 응답은 STEP 03의 측정 버튼으로 별도 측정합니다.',{},dict(html_generation_p95_ms=float(np.percentile(times,95)),raw_ms=times,actual_browser_p95_ms=None,browser_status='미측정',target_browser_p95_ms=100))

def workflow_demo(resources=None):
    w=Workflow(resources or {r:8 for r in ROLES});w.propose('Q1','J01',12,5)
    assert w.act('clerk','Q1','submit','검토 요청')[0];assert w.act('reviewer','Q1','review','수량 확인')[0]
    return w

def m07_s1(S):
    w=Workflow({r:8 for r in ROLES});r,_,_=risk_bundle(S)
    for i,row in enumerate(r.sort_values('risk',ascending=False).head(10).itertuples()):w.propose(f'Q{i:02}',row.role,int(row.need_median),min(int(row.need_median),4))
    S['workflow']=w
    return payload('작성 검토 승인 집행 확인 단계 나누기','이 실습의 역할은 모의 권한입니다. 제안이 생겼다는 이유로 승인되거나 현재원이 늘어나지 않게 상태를 구분합니다.',{'initial_requests':pd.DataFrame(w.cases.values())},{'requests':len(w.cases),'states':['DRAFT','SUBMITTED','REVIEWED','APPROVED','REJECTED','HOLD','EXECUTED']})

def m07_s2(S):
    w=S['workflow'];before=w.cases['Q00']['qty'];rid='Q00'
    w.act('clerk',rid,'submit','수량 검토 요청');w.act('reviewer',rid,'review','같은 직무 자원 확인')
    new=max(0,before-1);ok,msg=w.act('reviewer',rid,'adjust','남은 자원과 후순위 요청을 고려',qty=new)
    assert ok
    return payload('조정 사유와 미지원 인원 기록하기','요청 한 건에 인원을 더 주면 다른 요청이 받지 못할 수 있습니다. 수량을 바꾼 이유와 남은 소요를 같이 적습니다.',{'adjusted_requests':pd.DataFrame(w.cases.values())},{'before':before,'after':new,'adjustment_state':msg,'resource_remaining':w.resources})

def m07_s3(S):
    w=S['workflow'];before=S['weekly'].current.sum()
    for i,(rid,c) in enumerate(w.cases.items()):
        if c['state']=='DRAFT':w.act('clerk',rid,'submit','상신')
        if c['state']=='SUBMITTED':w.act('reviewer',rid,'review','자료와 총량 확인')
        action='hold' if c['qty']>w.resources[c['role']] or i==9 else 'approve'
        w.act('commander',rid,action,'자원 확인 후 결정' if action=='approve' else '자원 또는 근거 추가 확인')
    assert S['weekly'].current.sum()==before
    return payload('승인해도 현재원은 그대로 두기','승인은 집행을 허용한 상태입니다. 전입이 실제로 확인되기 전까지 현재원과 실제 유입을 수정하지 않습니다.',{'decisions':pd.DataFrame(w.cases.values())},{'current_unchanged':True,'remaining_resources':w.resources,'executed_requests':0})

def violation_tests():
    rows=[]
    def check(name,fn):
        try:result=fn();denied=not result[0];detail=result[1]
        except Exception as exc:denied=False;detail=repr(exc)
        rows.append(dict(test=name,blocked=denied,detail=detail))
    check('01 작성자의 승인',lambda:workflow_demo().act('clerk','Q1','approve','승인 시도'))
    check('02 시스템 자동 승인',lambda:workflow_demo().act('system','Q1','approve','승인 시도'))
    def before_review():
        w=Workflow({'J01':8});w.propose('Q1','J01',12,5);return w.act('commander','Q1','approve','검토 생략')
    check('03 검토 순서 생략',before_review)
    def same_actor():
        w=workflow_demo();w.roles=w.roles.copy();w.roles['clerk']='commander';return w.act('clerk','Q1','approve','역할 우회')
    check('04 같은 행위자 역할 우회',same_actor)
    check('05 음수 수량',lambda:workflow_demo().act('reviewer','Q1','adjust','수량 변경',qty=-1))
    check('06 소요 초과',lambda:workflow_demo().act('reviewer','Q1','adjust','수량 변경',qty=13))
    check('07 자원 초과',lambda:workflow_demo({'J01':1}).act('reviewer','Q1','adjust','수량 변경',qty=6))
    def duplicate_resource():
        w=workflow_demo({'J01':5});w.act('commander','Q1','approve','승인');w.propose('Q2','J01',5,5);w.act('clerk','Q2','submit','상신');w.act('reviewer','Q2','review','검토');return w.act('commander','Q2','approve','중복 예약')
    check('08 자원 중복 예약',duplicate_resource)
    check('09 조정 한도 초과',lambda:workflow_demo({'J01':20}).act('reviewer','Q1','adjust','조정',qty=10))
    check('10 조정 사유 누락',lambda:workflow_demo().act('reviewer','Q1','adjust','',qty=4))
    check('11 반려 사유 누락',lambda:workflow_demo().act('commander','Q1','reject',''))
    check('12 오래된 버전',lambda:workflow_demo().act('commander','Q1','approve','승인',version=999))
    check('13 미승인 집행',lambda:workflow_demo().act('executor','Q1','execute','집행',event_id='E1'))
    def replay():
        w=workflow_demo({'J01':12});w.act('commander','Q1','approve','승인');w.act('executor','Q1','execute','집행',event_id='E1')
        w.propose('Q2','J01',5,5);w.act('clerk','Q2','submit','상신');w.act('reviewer','Q2','review','검토');w.act('commander','Q2','approve','승인');return w.act('executor','Q2','execute','중복 이벤트',event_id='E1')
    check('14 집행 이벤트 중복',replay)
    return pd.DataFrame(rows)

def queue_times(priority=False):
    items=[dict(id=i,arrival=float(i),risk=[20,80,30,90,50,70,10,85,40,60][i]) for i in range(10)];pending=items.copy();now=0;rows=[]
    while pending:
        ready=[r for r in pending if r['arrival']<=now]
        if not ready:now=min(r['arrival'] for r in pending);continue
        chosen=max(ready,key=lambda r:r['risk']+3*(now-r['arrival'])) if priority else min(ready,key=lambda r:r['arrival'])
        rows.append(dict(**chosen,start=now,wait=now-chosen['arrival']));pending.remove(chosen);now+=2
    return pd.DataFrame(rows)

def m07_s4(S):
    tests=violation_tests();assert tests.blocked.all()
    w=workflow_demo()
    for _ in range(98):w.act('system','Q1','approve','권한 없는 시도')
    actions=[x for x in w.audit.events if x['event'] in ['ACTION','DENIED']];assert w.calls==100 and len(actions)==100
    fifo=queue_times();priority=queue_times(True);fifo['queue']='FIFO';priority['queue']='위험과 대기시간 반영'
    S['workflow_tests']=tests;S['workflow_log']=w.audit
    return payload('권한 위반 14종과 대기시간 시험하기','권한이 없는 명령은 실제로 거절되어야 합니다. 고위험 요청을 먼저 볼 때 다른 요청의 최장 대기도 함께 확인합니다.',{'blocked_cases':tests,'queue_wait':pd.concat([fifo,priority])},{'blocked':int(tests.blocked.sum()),'total':len(tests),'calls':w.calls,'logged':len(actions)})

def m07_s5(S):
    audit=S['workflow_log'];anchor=audit.events[-1]['hash'];before=audit.verify(anchor);copylog=copy.deepcopy(audit);copylog.events[0]['reason']='변조';detected=not copylog.verify(anchor)
    trunc=copy.deepcopy(audit);trunc.events.pop();trunc_detected=not trunc.verify(anchor)
    dump(S['root']/'outputs/M07/audit.json',audit.events)
    return payload('변조 시험과 미집행 요청 인계하기','로그를 바꿨을 때 탐지하는지 검사합니다. 끝의 해시값은 원본 로그와 별도로 보관해야 삭제도 확인할 수 있습니다.',{'handover':pd.DataFrame(S['workflow'].cases.values())},{'original_valid':before,'modification_detected':detected,'tail_deletion_detected':trunc_detected,'actual_execution':0},'로그와 별도 해시값을 모두 바꿀 수 있는 사람까지 막는 보안 체계는 이 실습 범위에 포함하지 않습니다.')

def m08_s1(S):
    S['service']=ForecastService(S['weekly'])
    plan=pd.DataFrame([dict(staffing_scenario=scenario,load_percent=mult*100,target_rate=150*mult,duration_seconds=S['stress_seconds']) for scenario in ['기본','가상 추가 전출'] for mult in [1,2,5]])
    return payload('인력 변화와 조회 부하의 시험 조건 나누기','추가 전출은 인원수에 영향을 주고 조회 증가는 처리시간에 영향을 줍니다. 두 원인을 따로 바꿔 결과를 비교합니다.',{'test_plan':plan},{'baseline_rate':150,'500_percent_load':750,'500_percent_increase':900,'quick_check_only':S['stress_seconds']<60})

def m08_s2(S):
    rows=[]
    for u in UNITS:
        for role in ROLES:
            g=get_cell(S['weekly'],u,role,91);base,_=mc_paths(g,91);shock,_=mc_paths(g,91,extra_out=1 if (u,role)==('B02','J04') else 0)
            rows.append(dict(unit=u,role=role,base_need=int(np.ceil(np.median(base.max(axis=1)))),shock_need=int(np.ceil(np.median(shock.max(axis=1)))),workload_change='별도 근무시간 계획이 필요함'))
    return payload('추가 전출이 특정 직무에 미치는 영향 계산하기','초기 현재원과 난수는 고정하고 B02/J04의 향후 유출 가정만 늘립니다. 다른 직무의 값을 함께 비교해 변화를 확인합니다.',{'shock_comparison':pd.DataFrame(rows)},{'shock_unit':'B02','shock_role':'J04','additional_mean_departure_per_week':1})

def m08_s3(S):
    traces=[];summaries=[]
    for mult in [1,2,5]:
        svc=ForecastService(S['weekly']);trace,summary=stress_run(svc,150*mult,S['stress_seconds'],optimized=False);trace['load_percent']=mult*100;traces.append(trace);summaries.append(summary)
    S['stress_before']=pd.concat(traces,ignore_index=True);S['stress_before_metrics']=summaries
    return payload('실제 예측 요청을 발생시켜 처리하기','정해진 속도로 예측 함수를 호출하고 도착·대기·시작·종료 시각을 기록합니다. 예정 도착률과 실제 도착률이 다른지도 봅니다.',{'before_optimization':pd.DataFrame(summaries)},dict(test_duration=S['stress_seconds'],full_scale_test=S['stress_seconds']>=60))

def m08_s4(S):
    traces=[];summaries=[]
    for mult in [1,2,5]:
        svc=ForecastService(S['weekly']);trace,summary=stress_run(svc,150*mult,S['stress_seconds'],optimized=True);trace['load_percent']=mult*100;traces.append(trace);summaries.append(summary)
    S['stress_after']=pd.concat(traces,ignore_index=True);S['stress_after_metrics']=summaries
    svc=ForecastService(S['weekly']);a=svc.predict('B01','J01',78);b=svc.predict('B01','J01',91);cached=svc.predict('B01','J01',78)
    assert a['data_through']==78 and b['data_through']==91 and cached['origin']==78 and cached['cache_hit']
    svc.invalidate(model_version='mc-new');assert not svc.cache
    return payload('캐시와 오류 대체가 자료 시점을 지키는지 확인하기','캐시는 이전 결과를 다시 쓰는 방법입니다. 자료·모델·주차·가정이 모두 같을 때만 재사용해야 합니다. 오류 시 대체 결과에도 사용한 시점을 표시합니다.',{'after_optimization':pd.DataFrame(summaries)},{'origin_78':a,'origin_91':b,'cached_78':cached,'invalidation_passed':True})

def m08_s5(S):
    tables={'before':S['stress_before'],'after':S['stress_after']}
    results=S['stress_before_metrics']+S['stress_after_metrics'];full=all(x['full_duration'] and x['rate_met'] for x in results)
    lost=sum(x['lost'] for x in results);failed=sum(x['failed'] for x in results)
    (S['root']/'outputs/M08').mkdir(parents=True,exist_ok=True)
    for name,t in tables.items():t.to_csv(S['root']/f'outputs/M08/{name}_request_trace.csv',index=False)
    answer=dict(full_test=full,unaccounted_requests=lost,failed_requests=failed,technical_status='달성' if full and lost==0 and failed==0 else '짧은 기능 시험만 완료' if not full else '미달',all_summaries=results)
    S['stress_summary']=answer
    return payload('요청 유실과 복구 상태 판정하기','정상 응답, 모델 오류 대체, 큐 포화 대체, 잘못된 요청 격리를 모두 합쳐 입력 요청수와 대조합니다. 짧은 실행을 60초 시험으로 보고하지 않습니다.',tables,answer)

def evaluate_worlds(worlds,lam,p0):
    rows=[]
    for seed,df in worlds:
        table,_,_=forecast_table(df,91,seed=0,lam=lam)
        for r in table.itertuples():
            future=derive(df[(df.unit==r.unit)&(df.role==r.role)&(df.week>91)])
            truth=int(future.vacancy.max());actual_flag=bool((future.vacancy_rate>=.15).any())
            rows.append(dict(seed=seed,unit=r.unit,role=r.role,shock_group=r.unit in ['B01','B02'],predicted=int(r.need_median),actual=truth,error=int(r.need_median)-truth,p_need=r.p_need,actual_need=actual_flag,predicted_need=bool(r.p_need>=p0)))
    return pd.DataFrame(rows)

def world_metrics(df):
    return dict(within_two_accuracy=float(df.error.abs().le(2).mean()),mae=float(df.error.abs().mean()),bias=float(df.error.mean()),**binary_metrics(df.actual_need,df.predicted_need))

def m09_s1(S):
    worlds=[(seed,make_weekly(seed,shock=True)[0]) for seed in [107,117,127,137,207,217,227,237]]
    S['worlds']=worlds;before=evaluate_worlds(worlds[:4],0,.5);S['aar_development_before']=before
    causes=before.assign(direction=np.where(before.error<0,'과소예측','과대예측 또는 일치')).groupby(['shock_group','direction']).agg(cases=('error','size'),bias=('error','mean')).reset_index()
    return payload('예측 오차와 전출 증가의 관계 확인하기','오차는 예측 보충량에서 실제 최대 결원을 뺀 값입니다. 음수이면 부족을 적게 예측한 것입니다. 원인 가설은 개발용 세계에서 먼저 확인합니다.',{'development_errors':before,'cause_groups':causes},{'development_seeds':[x[0] for x in worlds[:4]],'test_seeds':[x[0] for x in worlds[4:]]})

def m09_s2(S):
    worlds=S['worlds'][:4];rows=[]
    for lam in [0,.5,.8,1.]:
        table=evaluate_worlds(worlds,lam,.5)
        for p0 in [.15,.3,.5]:
            t=table.copy();t['predicted_need']=t.p_need>=p0;rows.append(dict(lam=lam,p0=p0,**world_metrics(t)))
    grid=pd.DataFrame(rows).sort_values(['mae','f1'],ascending=[True,False]);choice=grid.iloc[0]
    S['aar_lam']=float(choice.lam);S['aar_p0']=float(choice.p0)
    return payload('최근 전출 반영 비중을 개발 자료에서 고르기','lam이 0이면 과거 평균만 쓰고 1이면 최근 8주 전출만 반영합니다. 이 비중과 경보 기준은 개발용 네 세계에서 고정합니다.',{'tuning_grid':grid},{'chosen_lam':S['aar_lam'],'chosen_p0':S['aar_p0'],'accuracy_improvement_target_pp':10,'recurrence_target':0})

def m09_s3(S):
    worlds=S['worlds'][4:];before=evaluate_worlds(worlds,0,.5);after=evaluate_worlds(worlds,S['aar_lam'],S['aar_p0'])
    a=world_metrics(before);b=world_metrics(after);S['aar_before']=before;S['aar_after']=after;S['aar_before_metrics']=a;S['aar_after_metrics']=b
    return payload('남겨 둔 네 세계에서 수정 전후 비교하기','같은 96개 조직·직무 사례에서 비교합니다. 정확도 차는 퍼센트포인트로 계산하며 시험 결과를 보고 설정을 다시 고르지 않습니다.',{'test_before':before,'test_after':after},{'before':a,'after':b,'improvement_pp':100*(b['within_two_accuracy']-a['within_two_accuracy'])})

def m09_s4(S):
    a=S['aar_before'];b=S['aar_after'];j=a.merge(b,on=['seed','unit','role'],suffixes=('_before','_after'),validate='one_to_one')
    j['new_error']=j.error_before.abs().le(2)&j.error_after.abs().gt(2);j['recurrence']=j.shock_group_after&j.error_after.abs().gt(2)
    S['aar_regression']=j
    return payload('같은 오류의 재발과 다른 직무의 악화 찾기','급증한 전출을 반영하지 못한 사례에서 오차가 여전히 2명을 넘는지 확인합니다. 원래 맞던 사례가 새로 틀렸는지도 따로 셉니다.',{'regression_cases':j},{'new_errors':int(j.new_error.sum()),'recurrence_cases':int(j.recurrence.sum()),'recurrence_denominator':int(j.shock_group_after.sum())})

def m09_s5(S):
    a=S['aar_before_metrics'];b=S['aar_after_metrics'];j=S['aar_regression'];gain=b['within_two_accuracy']-a['within_two_accuracy']
    accepted=gain>=.10 and not j.recurrence.any() and (b['recall'] or 0)>=.85 and not j.new_error.any()
    config=dict(version=VERSION,lam=S['aar_lam'],p0=S['aar_p0'],status='사람의 최종 검토 필요' if accepted else '채택 보류',gain_pp=100*gain,recurrence=int(j.recurrence.sum()),rollback=dict(lam=0,p0=.5))
    dump(S['root']/'configs/tuned_params.json',config)
    path=S['root']/'configs/tuned_params.yaml';path.write_text('version: '+VERSION+'\nlam: '+str(config['lam'])+'\np0: '+str(config['p0'])+'\nstatus: '+config['status']+'\nrollback:\n  lam: 0\n  p0: 0.5\n',encoding='utf-8')
    S['aar_decision']=config
    return payload('목표에 미달한 수정안은 적용을 보류하기','좋아진 수치가 있어도 재발이나 신규 오류가 남으면 바로 교체하지 않습니다. 이전 설정과 추가 검증 과제를 함께 남깁니다.',{},config)

def pipeline(df,logs=None,use_mc=True):
    clean,quarantine=validate(df);log_results=preprocess(logs) if logs is not None else pd.DataFrame();audit=Audit();audit.add('LOAD',rows=len(df),quarantined=len(quarantine))
    origin=int(clean.week.max());now=derive(clean[clean.week==origin]);now['load_score']=load_score(now)
    if use_mc:
        try:table,series,_=forecast_table(clean,origin);result=assess_risk(table);mode='MODEL'
        except (ValueError,RuntimeError) as exc:use_mc=False;audit.add('MODEL_FALLBACK',reason=str(exc))
    if not use_mc:
        result=now[['unit','role','authorized','current','vacancy','available','overtime_h']].copy();result['need_median']=result.vacancy.astype(int);result['risk']=np.clip(result.vacancy/result.authorized/.3,0,1)*100;result['confidence']='Low';result['review_status']='예측 불가로 현재 결원 확인';series=pd.DataFrame();mode='RULE'
    queue_=result.copy();queue_['state']='DRAFT'
    for r in queue_.itertuples():audit.add('PROPOSAL',unit=r.unit,role=r.role,need=int(r.need_median),state='DRAFT')
    return dict(clean=clean,quarantine=quarantine,logs=log_results,current=now,result=result,series=series,queue=queue_,audit=audit,mode=mode)

def m10_s1(S):
    checks=dict(python_compatible=sys.version_info>=(3,10),numpy_imported=importlib.util.find_spec('numpy') is not None,pandas_imported=importlib.util.find_spec('pandas') is not None,sklearn_imported=importlib.util.find_spec('sklearn') is not None,generated_data_valid=len(validate(S['weekly'])[1])==0)
    result=pipeline(S['weekly'],S['raw_logs']);S['pipeline']=result
    return payload('한 실행 경로에서 모든 계산 연결하기','자료 검사부터 일지 정리, 부하 계산, 예측, 검토 목록까지 같은 입력을 넘깁니다. 아래 점검은 현재 실행환경 검사이며 새 가상환경 설치가 끝났다는 뜻은 아닙니다.',{'pipeline_result':result['result']},{'environment_checks':checks,'python':platform.python_version(),'version':VERSION,'data_fingerprint':fingerprint(S['weekly'])})

def m10_s2(S):
    rows=[]
    for seed in [7,17,27,37]:
        df,_=make_weekly(seed);df.loc[df.index[0],'overtime_h']=-1;df.loc[df.index[-1],'unit']='B99'
        r=pipeline(df,S['raw_logs']);rows.append(dict(seed=seed,input_rows=len(df),clean=len(r['clean']),quarantined=len(r['quarantine']),pairs=len(r['result']),all_draft=bool(r['queue'].state.eq('DRAFT').all()),audit_valid=r['audit'].verify(),passed=len(r['quarantine'])==2 and len(r['result'])==24))
    tests=pd.DataFrame(rows);assert tests.passed.all();S['e2e']=tests
    return payload('다른 자료 네 개에서도 처음부터 끝까지 실행하기','시드마다 손상행 두 개를 넣습니다. 원본과 오류 이유를 보존한 채 정상 자료로 계산이 이어지는지 확인합니다.',{'e2e_results':tests},{'passed':int(tests.passed.sum()),'total':len(tests),'e2e_success_rate':float(tests.passed.mean())})

def m10_s3(S):
    r=S['pipeline'];anchor=r['audit'].events[-1]['hash'];tampered=copy.deepcopy(r['audit']);tampered.events[0]['rows']=999
    fallback=pipeline(S['weekly'],use_mc=False);tests=violation_tests()
    checks=dict(input_schema=len(validate(S['weekly'])[1])==0,log_accounting=len(r['logs'])==len(S['raw_logs']),quantity_balance=bool((r['current'].available==r['current'].current-r['current'].absent).all()),load_score_range=bool(r['current'].load_score.between(0,100).all()),fallback_label=fallback['mode']=='RULE',review_state=bool(r['queue'].state.eq('DRAFT').all()),permission_blocks=bool(tests.blocked.all()),tamper_detected=not tampered.verify(anchor),e2e_all=bool(S['e2e'].passed.all()))
    coverage_path=S['root']/'verification/coverage.json';coverage=json.loads(coverage_path.read_text()) if coverage_path.exists() else {'status':'미측정','reason':'run_checks.py의 실행 행 추적 결과를 별도로 생성해야 합니다.'}
    S['integration_checks']=checks
    return payload('정상 동작뿐 아니라 실패 경로도 검사하기','대체 규칙, 권한 위반, 로그 변조를 실제로 실행합니다. 실행 행 추적 보고서가 없으면 커버리지를 미측정으로 남깁니다.',{'self_checks':pd.DataFrame([dict(check=k,passed=v) for k,v in checks.items()])},{'checks_passed':sum(checks.values()),'checks_total':len(checks),'coverage':coverage})

def m10_s4(S):
    r=S['pipeline'];q=r['queue'];current=r['current']
    chapters={
'01 목적과 범위':'이 도구는 가상 행정지원 인력의 현황과 향후 부족을 살펴보는 학습용 프로그램입니다. 현재원, 일시 부재, 근무 가용을 구분하고 실제 인원 이동은 수행하지 않습니다. 실제 부대 편제나 개인자료를 넣지 않습니다.',
'02 실행 방법':'노트북의 준비 셀을 먼저 실행한 뒤 미션별 다섯 단계를 실행합니다. 학습자 버전의 빈 함수는 오류로 중단됩니다. 압축파일을 풀면 src/main_adm01.py --all 명령으로 정답 구현 전체를 실행할 수 있습니다.',
'03 자료 정의':'weekly.csv는 조직·직무·주차별 집계이며 같은 사람의 주별 현재원을 누적 인원처럼 더하지 않습니다. 휴가·환자·교육·파견 범주는 중복되지 않는 교육용 가정입니다. 원자료와 정답표를 분리하여 저장합니다.',
'04 지표와 화면 읽기':'결원은 편제에서 현재원을 뺀 양수 부분이고 근무 가용은 현재원에서 일시 부재를 뺀 값입니다. 예측 범위와 위험 점수는 서로 다른 뜻입니다. 화면 왼쪽 STEP 메뉴로 계산 과정을 읽고 전체 결과는 CSV로 확인합니다.',
'05 사람 검토와 기록':'작성·검토·승인·집행 확인을 구분합니다. 수동 조정 시 사유와 버전을 기록하고 자원 총량을 검사합니다. 승인만으로 현재원을 바꾸지 않으며 실패한 권한 시도도 감사로그에 남깁니다.',
'06 실패와 복구':'파싱 실패와 손상행은 원문과 사유를 남겨 격리합니다. 모델 오류나 큐 포화 시 경량 규칙 사용을 표시합니다. 캐시는 자료·모델·예측시점·가정이 바뀌면 재사용하지 않습니다. 미처리 요청과 실패 응답을 성공으로 세지 않습니다.',
'07 재검토와 인계':'정확도와 재현율이 목표에 미달하면 수정안을 보류하고 기존 설정을 유지합니다. 자료·모델 버전, 미지원 소요, 승인 대기, 미집행 요청과 후속 담당자를 남깁니다. 교육용 실행 성공은 실제 시스템 배포 승인이 아닙니다.'}
    manual='\n\n'.join('## '+k+'\n'+v for k,v in chapters.items());path=S['root']/'docs/manual.md';path.parent.mkdir(exist_ok=True);path.write_text(manual,encoding='utf-8')
    briefing=dict(reference_week=int(current.week.max()),authorized=int(current.authorized.sum()),current=int(current.current.sum()),vacancy=int(current.vacancy.sum()),available=int(current.available.sum()),proposed_need=int(q.need_median.sum()),review_wait=len(q),executed=0,uncertainty='모델과 자료의 가정을 별도 검토해야 함')
    dump(S['root']/'docs/briefing.json',briefing);S['briefing']=briefing
    return payload('다음 담당자가 읽을 사용 설명서와 보고 작성하기','현재 수량과 제안 소요를 다른 항목으로 보고합니다. 화면이 열린 사실과 승인·집행이 완료된 사실을 섞지 않습니다.',{'briefing':pd.DataFrame([briefing])},{'manual_chapters':len(chapters),'manual_path':str(path),'independent_user_reexecution':'아직 수행하지 않음'})

def m10_s5(S):
    record=dict(version=VERSION,learning_assessment='교관 판정 대기',technical_checks=S['integration_checks'],forecast_target=S.get('forecast_latency',{}),stress=S.get('stress_summary',{'status':'미실행'}),aar=S.get('aar_decision',{'status':'미실행'}),browser_ui='사용자 브라우저 측정 전',unapproved=len(S['pipeline']['queue']),actual_execution=0,operational_deployment='별도 검토 필요')
    dump(S['root']/'outputs/M10/acceptance_record.json',record)
    return payload('미달 목표와 남은 업무를 인수서에 남기기','코드가 실행되었다고 모든 목표가 달성된 것은 아닙니다. 미달·미측정·미승인·미집행을 그대로 적고 다음 검토를 이어가게 합니다.',{},record)

STEPS={f'M{i:02}':[globals()[f'm{i:02}_s{n}'] for n in range(1,6)] for i in range(1,11)}

def run_mission(S,mid):
    # 미션을 따로 실행해도 필요한 교육용 입력과 이전 계산을 준비한다.
    dependencies={'M03':['M01'],'M04':['M01'],'M05':['M04'],'M06':[],'M07':[],'M08':[],'M09':[],'M10':[]}
    stages=[]
    for i,fn in enumerate(STEPS[mid],1):
        stage=fn(S);stages.append(stage)
    report=export_report(S['root'],mid,stages);return stages,report
