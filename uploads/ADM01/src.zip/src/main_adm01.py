"""실행 예: python src/main_adm01.py --all --root ADM01_work"""
import argparse,time
from adm01_tasks import init_state,run_mission,STEPS,dump
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--all',action='store_true');parser.add_argument('--mission',choices=list(STEPS));parser.add_argument('--root',default='ADM01_work');parser.add_argument('--stress-seconds',type=float,default=1)
    args=parser.parse_args();state=init_state(args.root,stress_seconds=args.stress_seconds);selected=list(STEPS) if args.all or not args.mission else [args.mission];report=[]
    for mid in selected:
        st=time.perf_counter();stages,path=run_mission(state,mid);report.append(dict(mission=mid,steps=len(stages),seconds=time.perf_counter()-st,report=str(path)));print(mid,path,flush=True)
    dump(state['root']/'verification/execution.json',report)
